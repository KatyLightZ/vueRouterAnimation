<template>
  <div class="page-m">
home-
404
  </div>
</template>
<script>
export default {
  name: "aA"
}
</script>