<template>
  <div class="page-m">
    <div class="row-flex  ">
      <div class="row-flex-label white">搜索</div>
      <div class="row-f1">
        <div class="row-flex">
          <input class="form-input glass" v-model="queryString"/>
          <div class="form-input-suf">
            <button class="button love" @click="$router.push({ path: '/search/'+queryString })">query</button>
          </div>
        </div>
      </div>
    </div>
    不同尺寸
    <kl-textarea v-model="queryString"/>
    <pre>fjsdkl,sdfjklsf
    sdfjkl
    </pre>
    <input   class="form-input warn  linear to-info"  placeholder="font-white"/>
    <input class="form-input warn  linear to-info"  placeholder="font-white"/>
    <textarea draggable="false" rows="4"  style="resize:none;"  class="form-input form-textarea warn  linear to-info" placeholder="font-white"></textarea>
    <input class="form-input success pill glass" placeholder="font-white"/>
    <input class="form-input primary pill glass" placeholder="font-white"/>
    <input class="form-input info pill glass" placeholder="font-white"/>
    <input class="form-input error pill glass" placeholder="font-white"/>
    <input class="form-input secondary pill glass" placeholder="font-white"/>
    <input class="form-input love pill glass" placeholder="font-white"/>
    <input class="form-input plain-border pill error  " placeholder="font-white"/>
    <input class="form-input warn pill fade-out to-love glass"/>
    <input class="form-input fade-out pill glass" placeholder="font-white"/>
    <input class="form-input success pill fade-out to-success  glass" placeholder="font-white"/>
    <input class="form-input primary pill fade-out  to-warn glass" placeholder="font-white"/>
    <input class="form-input info fade-out  to-error glass" placeholder="font-white"/>
    <input class="form-input error fade-out to-love glass" placeholder="font-white"/>
    <input class="form-input secondary fade-out to-primary  glass" placeholder="font-white"/>
    <input class="form-input love to-info fade-out  glass" placeholder="font-white"/>
    <div class="row-flex">
      <div class="row-align-middle">
        <button class="button primary mini cir auto  hollow">s</button>
      </div>
      <input class="form-input back-active error   glass-fake      "/>
      <div class="form-input-back glass error"></div>
    </div>
    <div class="row-flex">
      <div class="row-align-middle">
        <button class="button primary mini cir auto  hollow">s</button>
      </div>
      <input class="form-input back-active glass-fake "/>
      <div class="form-input-back glass linear fade-out"></div>
    </div>
    <div class="row-flex">
      <div class="row-align-middle">
        <button class="button primary mini   auto hollow">glass-fake</button>
      </div>
      <input class="form-input back-active glass-fake glass-fake warn" placeholder="glass-fake"/>
      <div class="form-input-back glass linear warn fade-out"></div>
    </div>
    <div class="row-flex">
      <div class="row-align-middle">
        <button class="button love mini cir auto hollow">s</button>
      </div>
      <input class="form-input back-active glass-fake warn "/>
      <div class="form-input-back glass linear warn to-love "></div>
    </div>
    <div class="row-flex">
      <div class="row-align-middle">
        <button class="button love mini   auto hollow">linear-fake</button>
      </div>
      <input class="form-input back-active font-white selection-info warn "  placeholder="font-white"/>
      <div class="form-input-back   linear warn to-love "></div>
    </div>
    <input class="form-input warn linear to-love glass"/>
    <input class="form-input success linear to-success  glass"/>
    <input class="form-input primary linear  to-warn glass"/>
    <input class="form-input info linear  to-error glass"/>
    <input class="form-input error linear to-love glass"/>
    <input class="form-input secondary linear to-primary  glass"/>
    <input class="form-input love to-info linear mini glass"/>
    <input class="form-input plain-border   to-love error  "/>
    plain-fake
    <div style="padding: 20px"> plain-fake
      <div class="row-flex   ">
        <input class="form-input back-active color-font  plain-fake warn" placeholder="plain-fake"/>
        <div class="form-input-back warn plain-border"></div>
      </div>
      <div class="row-flex   ">
        <input class="form-input back-active color-font  plain-fake warn" placeholder="plain-fake"/>
        <div class="form-input-back warn plain "></div>
      </div>
      <input class="form-input back-active color-font  plain-border warn" placeholder="plain-fake"/>
      <input class="form-input back-active color-font  plain warn" placeholder="plain-fake"/>

    </div>
    <div style="padding: 20px">hollow
      <div class="row-flex   ">
        <input class="form-input back-active color-font glass-fake warn"/>
        <div class="form-input-back warn hollow    "></div>
      </div>
      <input class="form-input   hollow   warn"/>
    </div>
    <div class="row-flex  large">
      <div class="row-align-middle">
        <button class="button love   auto large cir">S</button>
      </div>
      <input class="form-input back-active glass-fake warn color-font"/>
      <div class="form-input-back warn plain-back pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto large cir">x</button>
      </div>
    </div>
    <div class="row-flex  big ">
      <div class="row-align-middle">
        <button class="button love   auto   cir">S</button>
      </div>
      <input class="form-input back-active warn"/>
      <div class="form-input-back glass pill"></div>
    </div>

    large:
    <div class="row-flex inset large">
      <div class="row-align-middle">
        <button class="button love   auto bigger cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back glass pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    huge:
    <div class="row-flex inset huge">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back glass pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    bigger:
    <div class="row-flex inset bigger">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back glass pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    big:
    <div class="row-flex inset big">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back glass pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    normal:
    <div class="row-flex inset">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back glass pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    small:
    <div class="row-flex inset small">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back glass pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    mini
    <div class="row-flex inset mini">
      <div class="row-align-middle">
        <button class="button love   auto mini cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back glass pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    <input class="form-input glass "/>
    <input class="form-input white  " placeholder="white"/>
    <input class="form-input right" placeholder="right text"/>
    <div class="row-flex">
      <div class="form-input-pre">
        <button class="button success">fds</button>
      </div>
      <input class="form-input"/>
      <div class="form-input-suf">
        <button class="button error">fds</button>
      </div>
    </div>
    <div class="row-flex">
      <button class="button success">aaa</button>
      <input class="form-input"/>
      <button class="button error">vvv</button>
    </div>
    <div class="row-flex  ">
      <div class="row-flex-label white">你的地址</div>
      <div class="row-f1">
        <div class="row-flex">
          <span class="button-span success">prefix</span>
          <div class="row-align-middle"><span class="button-span mini success auto">prefix</span></div>
          <button class="button success">prefix</button>
          <input class="form-input"/>

        </div>
        <div class="form-info row show">
          password missing
        </div>
      </div>
    </div>
    <div class="row-flex  ">
      <div class="row-flex-label white">你的地址</div>
      <div class="row-f1">
        <div class="row-flex">
          <div class="form-input-pre">
            <button class="button success">测试</button>
          </div>
          <input class="form-input"/>
          <div class="form-input-suf">
            <button class="button error">测试</button>
          </div>
        </div>
        <div class="form-info row show">
          password missing
        </div>
      </div>
    </div>
    <div class="row-flex  ">
      <div class="row-flex-label">aaaaaaaaaaaa</div>
      <input class="form-input"/>
      <button class="button error">vvv</button>
    </div>
    <br/>
    <br/>
    <br/>
    <br/>
    <div class="row-flex mini">
      <div class="row-flex-label" style="flex-shrink: 0">mini</div>
      <div class="row-f1 flex">
        <button class="button success mini " style="flex-shrink: 0">测试</button>
        <div class="row-f1" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show primary">
            password missing
          </div>
        </div>
        <button class="button   info mini " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="row-flex small">
      <div class="row-flex-label" style="flex-shrink: 0">mini</div>
      <div class="row-f1 flex">
        <button class="button success small" style="flex-shrink: 0">测试</button>
        <div class="row-f1" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row info show">
            password missing
          </div>
        </div>
        <button class="button error primary small" style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="row-flex  ">
      <div class="row-flex-label" style="flex-shrink: 0">normal</div>
      <div class="row-f1 flex">
        <button class="button success   " style="flex-shrink: 0">测试</button>
        <div class="row-f1" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row normal show">
            password missing
          </div>
        </div>
        <button class="button error   " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="row-flex big">
      <div class="row-flex-label" style="flex-shrink: 0">big</div>
      <div class="row-f1 flex">
        <button class="button success big " style="flex-shrink: 0">测试</button>
        <div class="row-f1" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show warn">
            password missing
          </div>
        </div>
        <button class="button error big " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="row-flex bigger">
      <div class="row-flex-label" style="flex-shrink: 0">bigger</div>
      <div class="row-f1 flex">
        <button class="button success bigger " style="flex-shrink: 0">测试</button>
        <div class="row-f1" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show love">
            password missing
          </div>
        </div>
        <button class="button error bigger " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="row-flex huge">
      <div class="row-flex-label" style="flex-shrink: 0">huge</div>
      <div class="row-f1 flex">
        <button class="button success huge " style="flex-shrink: 0">测试</button>
        <div class="row-f1" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show success">
            password missing
          </div>
        </div>
        <button class="button error huge " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="row-flex large">
      <div class="row-flex-label" style="flex-shrink: 0">large</div>
      <div class="row-f1 flex">
        <button class="button success large " style="flex-shrink: 0">测试</button>
        <div class="row-f1" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show">
            password missing
          </div>
        </div>
        <button class="button error huge " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="row-flex">
      <div class="row-flex-label">a111</div>
      <button class="button success">测试</button>
      <div class="row-f1 ">
        <div class="row-f1 flex">
          <input class="form-input"/>
          <button class="button error">测试</button>
        </div>
        <div class="form-info   show row">
          未来解决方式之一。需要绝对定位到输入里面？
        </div>
      </div>

    </div>
    <div class="">
      <div class="row-flex">
        <div class="row-flex-label">a111</div>
        <button class="button success">测试</button>
        <div class="row-f1" style="display: inline-block">
          <input class="form-input"/>
        </div>
        <button class="button error">测试</button>
      </div>
      <div class="form-info row show">
        未来解决方式之一。需要绝对定位到输入里面？
      </div>
    </div>
    backDiv必须写在后面。通过伪类触发。通常用于组合按钮，row-f1在pill下更加好
    <div class="row-flex">
      <button class="button love pill pill-left tight">sd</button>
      <div class="row-f1">
        <input class="form-input back-active"/>
        <div class="form-input-back glass"></div>
      </div>
      <button class="button error pill pill-right tight">box</button>
    </div>

    <div class="row-flex">
      <div class="row-flex-label">你的地址</div>
      <input class="form-input back-active"/>
      <div class="form-input-back glass"></div>
    </div>
    <div class="form right white transparent white-line">
      form
      <div class="row-flex form-row">
        <div class="row-flex-label">你的地址</div>
        <input class="form-input" placeholder="sdfkl"/>
      </div>

      <div class="row-flex form-row">
        <div class="row-flex-label">sdffs</div>
        <div class="row-f1">
          <div class="row-flex">
            <input class="form-input"/>
            <button class="button error">测试</button>
          </div>
          <div class="form-info row show">
            password missing
          </div>
        </div>
      </div>
      <div class="row-flex form-row  ">
        <div class="row-flex-label">你的地址</div>
        <div class="row-f1">
          <div class="row-flex">
            <input class="form-input"/>
            <div class="form-input-suf">
              <button class="button error">测试</button>
            </div>
          </div>
          <div class="form-info row show">
            password missing
          </div>
        </div>
      </div>
      <div class="row-flex  form-row ">
        <div class="row-flex-label">你的地址</div>
        <div class="row-f1">
          <div class="row-flex">
            <div class="form-input-pre">
              <button class="button success">测试</button>
            </div>
            <div class="row-f1">
              <input class="form-input"/>
              <div class="form-info row show">
                password missing
              </div>
            </div>
            <div class="form-input-suf">
              <button class="button error">测试</button>
            </div>
          </div>
        </div>
      </div>
      <div class="row-flex form-row ">
        <div class="row-flex-label">transparency</div>
        <div class="row-f1">
          <div class="row-flex">
            <div class="form-input-pre">
              <button class="button success">测试</button>
            </div>
            <div class="row-f1">
              <input class="form-input left"/>
              <div class="form-info row transparency">
                password missing
              </div>
            </div>
            <div class="form-input-suf">
              <button class="button error">测试</button>
            </div>
          </div>
        </div>
      </div>
      <div class="row-flex form-row ">
        <div class="row-flex-label">你的地址</div>
        <input class="form-input left" placeholder="sdfkl"/>
      </div>
      <div class="row-flex form-row ">
        <div class="row-flex-label">你的地址</div>
        <div class="row-f1">
          <input class="form-input" placeholder="sdfkl"/>
          <div class="form-info row show">
            password missing
          </div>
        </div>
      </div>
      <div class="row-flex form-row ">
        <div class="row-flex-label">你的地址</div>
        <div class="row-f1">
          <input class="form-input left" placeholder="sdfkl"/>
          <div class="form-info row show">
            password missing
          </div>
        </div>

      </div>
    </div>
  </div>
</template>
<script>
import KlTextarea from "@/components/klTextarea";
export default {
  name: "bB",
  components: {KlTextarea},
  data() {
    return {
      queryString: ''
    }
  }
}
</script>
