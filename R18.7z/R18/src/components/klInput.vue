<template>
  <input data-input="email"
         :value="modelValue"
         @focus="check($event)"
         @input="inputChange($event)"
  />
</template>
<script>
export default {
  name: "klInput",
  props: {
    modelValue: {
      type: String
    }
  },
  emits: ["update:modelValue"],
  methods: {
    inputChange(e){
      this.$emit('update:modelValue', e.target.value);
      if(this.$parent.hideErrorInfo){
        this.$parent.hideErrorInfo()
      }
      e.target.classList.remove('ani');
    },
    check(e) {
      e.target.classList.remove('ani');
    }
  }
}
</script>
<style scoped>
</style>