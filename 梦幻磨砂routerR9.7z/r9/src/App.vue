<template>
<!--  <keep-alive>  </keep-alive>-->
    <transition :name="$route.meta.transition">
      <router-view class="page"
                   :key="$route.meta.mutter"/>
    </transition>
</template>
<script>
export default {
  name: 'App',
  components: {},
  data() {
    return {
      pageKey: "",
      pastParam: {}
    }
  },
  mounted() {
    const resize = () => {
      document.body.style.height = window.innerHeight + "px";
      if (window.innerWidth > 502) {
        document.body.classList.add('glass')
      } else {
        document.body.classList.remove('glass')
      }
    }
    resize();
    window.onresize = () => {
      resize();
    }
  },
}
</script>
<style>
.navbar {
  top: 0;
  left: 0;
  right: 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.68);
  display: flex;
  color: #131313;
  position: absolute;
  z-index: 1;
  height: 40px;
  background-color: rgba(198, 225, 241, 0.18);
  padding: 10px 0;
  backdrop-filter: blur(5px);
}

.tabBar-item {
  flex: 1;
  position: relative;
  text-align: center;
  padding: 20px 0;
  line-height: 18px;
}

.tabBar-item.active {
  font-weight: bolder;

}

.tabBar-item.active::after {
  content: "";
  pointer-events: none;
  z-index: -1;
  background-color: rgba(255, 255, 255, 0.76);
  position: absolute;
  top: 5px;
  border-radius: 5px;
  bottom: 5px;
  right: 2px;

  left: 2px;

}

.tabBar {
  border-top: 1px solid rgba(255, 255, 255, 0.68);
  display: flex;
  color: #131313;
  position: absolute;
  z-index: 1;
  bottom: 0;
  background-color: rgba(198, 225, 241, 0.18);

  backdrop-filter: blur(5px);
  right: 0;
  left: 0;
}

/*outer-cover*/
.outer-cover-enter-active,
.outer-cover-leave-active {
  transition: all .4s ease-out;
}

.outer-cover-enter-to {
  transform: scale(1);
  opacity: 1;
}

.outer-cover-enter-from {
  transform: scale(.4);
  opacity: 0;
}

.outer-cover-leave-to {
  transform: scale(1.4);
  opacity: 0;
}

.outer-cover-leave-from {
  transform: scale(1);
  opacity: 1;
}

/*inner-cover*/
.inner-cover-enter-active,
.inner-cover-leave-active {
  transition: all .4s ease-out;
}

.inner-cover-enter-to {
  transform: scale(1);
  opacity: 1;
}

.inner-cover-enter-from {
  transform: scale(1.4);
  opacity: 0;
}

.inner-cover-leave-to {
  transform: scale(.4);
  opacity: 0;
}

.inner-cover-leave-from {
  transform: scale(1);
  opacity: 1;
}


body.glass {
  width: 500px;
  margin: 0 auto;
  border-left: 1px solid white;
  border-right: 1px solid white;
}

::-webkit-scrollbar {
  width: 0;
  height: 0;
  display: none;
}

.nav-header {
  text-align: center;
  color: white;
  font-size: 24px;
  font-weight: bolder;
  padding: 10px 0;
  background-color: #FFFFFF44;
  border-bottom: 1px solid white;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  z-index: 33;

}

.cube-list-group {
  background-color: #FFFFFF99;
  border-radius: 4px;
  margin: 10px;
  overflow: hidden;
}

.cube-list-item {
  padding: 10px;
  border-bottom: 1px solid rgba(105, 105, 105, 0.4);
  user-select: none;
  display: flex;
  overflow: hidden;
}

.cube-list-item:hover {
  background-image: linear-gradient(90deg, rgba(255, 255, 255, 0.78), transparent);
}

.cube-list-item:last-child {
  border-bottom: none;
}

.title {
  color: white;
  font-size: 24px;
  font-weight: bolder;
}

html {
  overflow: hidden;
}

.back {
  font-size: 20px;
  font-weight: bolder;
}

.page.cover {
  z-index: 999;
}

.page.glass {
  box-shadow: 0 0 10px 5px #01071322;
  background-color: #b4dfe322;
}

body {

  margin: 0 auto;
  overflow: hidden;
  width: 100vw;
  height: 100vh;
  /*这个高度不是固定值*/
  position: relative;
  color: #333;
  background: linear-gradient(#04cbcb, #0d5ca9);
}

.box {
  background-color: rgba(255, 255, 255, 0.71);
  border-radius: 10px;
  padding: 10px;
  margin: 10px;
}

.page {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  overflow: hidden;
}

.nav-header-icon {
  position: absolute;
  top: 10px;
  background-color: white;
  width: 30px;
  height: 30px;
  color: #42b983;
  z-index: 88;
}

.nav-header-icon.left {
  left: 10px;
}

.nav-header-icon.right {
  right: 10px;
}

.page-m {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  padding-top: 60px;
  box-sizing: border-box;
  overflow-x: hidden;
  overflow-y: scroll;
  padding-bottom: 80px;
}


.trigger-enter-active,
.trigger-leave-active {
  /*transition: transform .4s ease-out;*/
  transition: 0s display .2s linear;
}

.trigger-enter-to {
  transform: translateY(0);
}

.trigger-enter-from {
  transform: translateY(100%);
}

.trigger-leave-to {
  transform: translateY(100%);
}

.trigger-leave-from {
  transform: translateY(0);
}

.slide-left-enter-active,
.slide-left-leave-active {
  transition: transform .4s ease-out;
}

.slide-left-enter-to {
  transform: translateX(0);
}

.slide-left-enter-from {
  transform: translateX(-100%);
}

.slide-left-leave-to {
  transform: translateX(100%);
}

.slide-left-leave-from {
  transform: translateX(0);
}

/*slide-left-over*/
.slide-left-over-enter-active, .slide-left-over-leave-active {
  transition: all .4s ease-out;
}

.slide-left-over-enter-to {

}


.slide-left-over-enter-to {
  transform: scale(1);
  opacity: 1;
}

.slide-left-over-enter-from {
  transform: scale(.6);
  opacity: 0;
}


.slide-left-over-leave-to {
  transform: translateX(100%);
}

.slide-left-over-leave-from {
  transform: translateX(0);
}

/*slide-right-over*/
.slide-right-over-enter-active {
  transition: transform .4s ease-out;
}

.slide-right-over-leave-active {
  transition: all .4s ease-out;
}


.slide-right-over-leave-to {
  transform: scale(.6);
  opacity: 0;
}

.slide-right-over-leave-from {
  transform: scale(1);
  opacity: 1;
}


.slide-right-over-leave-to {

}

.slide-right-over-leave-from {
}

.slide-right-over-enter-to {
  transform: translateX(0);

}

.slide-right-over-enter-from {

  transform: translateX(100%);
}


/**/
.slide-right-enter-active,
.slide-right-leave-active {
  transition: transform .4s ease-out;
}

.slide-right-enter-to {
  transform: translateX(0);
}

.slide-right-enter-from {
  transform: translateX(100%);
}

.slide-right-leave-to {
  transform: translateX(-100%);
}

.slide-right-leave-from {
  transform: translateX(0);
}

/**/
.fade-in-enter-active,
.fade-in-leave-active {
  transition: opacity .4s ease-out;
}

.fade-in-enter-to {
  opacity: 1;
}

.fade-in-enter-from {
  opacity: 0;
}

.fade-in-leave-to {
  opacity: 0;
}

.fade-in-leave-from {
  opacity: 1;
}
</style>
