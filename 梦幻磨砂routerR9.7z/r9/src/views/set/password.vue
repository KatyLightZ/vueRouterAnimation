<template>
  <div>
    <div class="back" @click="this.$router.go(-1)">back</div>
    <div class="cube-list-group">
      <div class="cube-list-item">
        account set
      </div>
      <div class="cube-list-item" >
        before
      </div>
      <div class="cube-list-item">
        after
      </div>
      <div class="cube-list-item">
        change your password
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "accountC"
}
</script>

<style scoped>

</style>