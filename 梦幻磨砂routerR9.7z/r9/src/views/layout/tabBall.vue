<template>
  <div class="tab-ball-box">
    <div  :class="['tab-ball-item',show?'active':'','first']" @click="show=!show">{{ show ? 'hide' : 'more' }}</div>
    <div :class="['tab-ball-inner',show?'active':'']">
      <div v-for="item in list "
           :key="item.path" @click="$router.replace({ path: item.path })"
           :class="['tab-ball-item',item.path===$route.fullPath?'active':'']"
      >
        {{ item.name }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "tabBall",
  props: {list: {default: []}},
  data() {
    return {show: true}
  },
}
</script>

<style>
.tab-ball-box {
  color: #131313;
  position: absolute;
  z-index: 1;
  bottom: 0;
  right: 0;
  left: 0;
  overflow: hidden;
  padding-bottom: 20px;
  display: flex;
  height: 60px;
  user-select: none;
  background: linear-gradient( transparent,transparent 10%,  #04162c55);
}



.tab-ball-item.active {
  background-color: rgb(198, 241, 233);
}
.tab-ball-item.first.active{

  background-color: rgba(215, 198, 241  );
}
.tab-ball-item.first {

  background-color: rgb(171, 128, 234);
  position: absolute;
  bottom: 20px;
  z-index: 22;
  width: 60px;
  height: 60px;
  line-height: 60px;
}

.tab-ball-inner {
  transform: translateX(-100%);
  transition: transform .5s ease-in-out;
  padding-left: 70px;
  overflow-x: scroll;
  display: flex;
  padding-right: 100px;
  padding-top: 10px;
}

.tab-ball-inner.active {
  transform: translateX(0%);
  transition: transform .5s ease-in-out;
}

.tab-ball-item {
  width: 50px;
  height: 50px;
  text-align: center;
  line-height: 50px;
  flex-shrink: 0;
  display: inline-block;
  vertical-align: middle;
  background-color: rgba(198, 225, 241 );
  backdrop-filter: blur(5px);
  border-radius: 50%;
  margin-left: 10px;
}
</style>