<template>
  <!-- ref="me" -->
  <transition name="right-top-shine">
    <div class="pup-set" v-show="visible" @click="zli">
      <div class="pup-set-item">
        this is a set
      </div>
      <div class="pup-set-item">
        this is other set
      </div>
      <div class="pup-set-item">
        this is other set
      </div>
      <div class="pup-set-item">
        this is other set
      </div>
    </div>
  </transition>
</template>
<script setup>
import {defineEmits, defineProps, defineExpose, onBeforeUnmount, onMounted, ref} from "vue"
// eslint-disable-next-line no-unused-vars
const props = defineProps({
  visible: {
    type: Boolean,
  },
})
// const me = ref(null);
const me = ref(null)
const emits = defineEmits(['update:show'])
// eslint-disable-next-line no-unused-vars
const zli = () => {
  emits("update:visible", false)
}
// eslint-disable-next-line no-unused-vars
const wz = (e) => {
  // eslint-disable-next-line no-undef
  if (!me.value.contains(e.target) && props.visible) {
    emits("update:visible", false)
  }
}
const setMe = (m) => {
  me.value = m;
}
onBeforeUnmount(() => {
  document.removeEventListener('click', wz)
})
onMounted(() => {
  document.addEventListener('click', wz)
})
defineExpose({setMe})

</script>

<style>
/*right-top-shine*/
.right-top-shine-enter-active,
.right-top-shine-leave-active {
  transition: all .4s ease-out;
}

.right-top-shine-enter-to {
  transform: scale(1);
  opacity: 1;
}

.right-top-shine-enter-from {
  transform: scale(0);
  opacity: 0;
}

.right-top-shine-leave-to {
  transform: scale(0);
  opacity: 0;
}

.right-top-shine-leave-from {
  transform: scale(1);
  opacity: 1;
}

/*right-top-shine*/


.pup-set {
  transform-origin: right top;
  transform-box: fill-box;
  position: absolute;
  width: 200px;
  font-size: 16px;
  border-radius: 10px;
  background-color: rgba(255, 255, 255, 0.45);
  backdrop-filter: blur(4px);
  color: #555;
  top: 100%;
  margin-top: 10px;
  right: 0;
  user-select: none;
}

.pup-set-item:hover {
  cursor: pointer;;
  background-image: linear-gradient(90deg, transparent, white, transparent);
  /*background-image: radial-gradient(  white 0%,transparent 40%,transparent);*/
  /*background-size: 100% 100% ;*/
  /*background-repeat: no-repeat;*/
  /*background-position: center 10px;*/
}

.pup-set-item {
  padding: 10px;
  border-bottom: 1px solid #7e7e7e44;
}

.pup-set-item:last-child {
  border-bottom: none;
}
</style>