<template>
  <div style="" class="tabBar">
    <div v-for="item in list " :key="item.path" @click="$router.push({ path: item.path })"
         :class="['tabBar-item',item.path===$route.fullPath?'active':'']">
      {{ item.name }}
    </div>
  </div>
</template>

<script>
export default {
  name: "tabBar",
  props:{list:{default:[]}},
}
</script>

<style scoped>

</style>