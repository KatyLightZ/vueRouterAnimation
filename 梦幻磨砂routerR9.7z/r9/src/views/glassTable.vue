<template>
  <div :class="['glass-table-cover',!props.visible||'show']"></div>
  <div :class="['glass-table-back',!props.visible||'show']" @click="handlerClick"></div>
  <div :class="['glass-table',!props.visible||'show']">
    <div class="glass-table-close" style="text-align: right">
      <span @click="handlerClick">close me</span>
    </div>
    <div class="glass-info-card">
      <div class="flex-row">
        <div class="glass-info-left">
          <img class="glass-info-avatar" src="https://img2.baidu.com/it/u=1231891383,1640948087&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=560" alt="avatar"/>
        </div>
        <div class="glass-info-right">
          <div class="glass-info-nickname">Alice</div>
          <div class="glass-info-username">@alice999</div>
          <div class="glass-info-desc">Alice is here</div>
        </div>
      </div>

    </div>
    <div class="glass-table-item"   @click="$router.push({ path: '/set' })">my Set</div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Set</div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Set</div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Set</div>
  </div>
</template>
<script setup>
import {defineEmits, defineProps} from "vue"
// eslint-disable-next-line no-unused-vars
const props = defineProps({
  visible: {
    type: Boolean,
  }
})
const emits = defineEmits(['update:visible'])
const handlerClick = () => {
  emits("update:visible", false)
}
</script>
<style>
.flex-row{
  display: flex;
}
.glass-info-right{
  flex: 1;
  overflow: hidden;
  padding: 10px;
}
.glass-info-left{
  padding: 10px;
}
.glass-info-nickname{
  color: #444;
  font-size: 24px;
  font-weight: bold;
}
.glass-info-desc{
  color: #555;
  height: 44px;
  line-height: 22px;
  overflow: hidden;
}

.glass-info-username{
  color: #777;
  font-size: 16px;
  font-weight: lighter;
}
.glass-table-close {
  text-align: right;
  font-size: 20px;

}

.glass-info-avatar {
  background-color: #ffffff99;
  width: 100px;
  height: 100px;
  border-radius: 50%;
  object-fit: cover;

}
.glass-info-card:hover{
  transform:scale(.9);
  transition: transform .4s ease-in-out;
}
.glass-info-card {
  background-color: rgba(255, 255, 255, 0.65);
  padding: 10px;
  margin: 10px;
  border-radius: 10px;
  transition: transform .4s ease-in-out;

}

.glass-table-item {
  color: #606060;
  border-bottom: 1px solid white;
  /*text-shadow: 0 0 2px black;*/
  font-size: 22px;
  padding: 20px 10px;
}

.glass-table-item:hover {
  background-image: linear-gradient(90deg, #FFFFFF99, transparent);
}

.glass-table-back {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  z-index: 88;
  transform: translateX(-100%);
}

.glass-table-cover {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  z-index: 88;
  pointer-events: none;
  background-color: rgba(0, 0, 0, 0.0);
  transition: background-color .3s linear;
}

.glass-table {

  overflow-y: scroll;
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 80%;
  background-color: rgba(255, 255, 255, 0.72);
  border-right: 1px solid rgba(255, 255, 255, 0.23);
  z-index: 99;
  backdrop-filter: blur(2px);
  transition: transform .3s ease-in;
  box-shadow: 0 0 10px 5px rgba(0, 0, 0, 0.15);
  transform: translateX(-130%);
}

.glass-table.show {
  transition: transform .3s ease-in;
  transform: translateX(0);
}

.glass-table-cover.show {
  pointer-events: inherit;
  transition: background-color .6s linear;
  background-color: rgba(0, 0, 0, 0.53);
}

.glass-table-back.show {
  display: block;
  transition: transform 0s linear .3s;
  transform: translateX(0);
}

</style>