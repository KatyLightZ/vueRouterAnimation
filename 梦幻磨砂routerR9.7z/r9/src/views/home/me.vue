<template>
  <div class="page-m">
    <div class="box">avatar account</div>
    <div class="title">i have to do something</div>
    <div class="box">need to do something</div>
    <div class="title">my date</div>
    <div class="box">date</div>
    <swiper-nav/>
    <auto-mini-menu title="更多应用"
                    :list="[
      {
        label:'电脑版'
      },
            {
        label:'电脑版'
      },
            {
        label:'电脑版'
      },
            {
        label:'电脑电脑版电脑版电脑版电脑版电脑版电脑版版'
      },
            {
        label:'电脑版'
      },
            {
        label:'电脑版'
      },
  ]"
    ></auto-mini-menu>
  </div>
</template>
<script>
import AutoMiniMenu from "@/views/cop/autoMiniMenu";
import SwiperNav from "@/views/cop/swiperNav";

export default {
  name: "dD",
  components: {SwiperNav, AutoMiniMenu}
}
</script>