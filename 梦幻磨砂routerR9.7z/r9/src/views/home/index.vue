<template>
  <div class="page-m">
    <div class="title">something not only</div>
    <auto-mini-menu/>
    <button  @click="$router.push({ path: '/login' })"> login</button>
    <div class="box">
      <div @click="$router.push({ path: '/post/i' })">this is a child to new post i</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/asdfdfs' })">asdfdfs</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/fdsf' })">sdf</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/i' })">this is a child to new post i</div>
    </div>
  </div>
</template>
<script>
 import AutoMiniMenu from "@/views/cop/autoMiniMenu";
 export default {
  name: "aA",
  components: {AutoMiniMenu }
}
</script>