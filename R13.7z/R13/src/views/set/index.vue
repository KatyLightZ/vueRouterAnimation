<template>
<div style="padding: 10px">
  <div class="back" @click="this.$router.go(-1)">back</div>
  <div class="cube-list-group">
    <div class="cube-list-item" @click="$router.push({ path: '/set/account' })">
      account set
    </div>
    <div class="cube-list-item">
      account set
    </div>
    <div class="cube-list-item">
      account set
    </div>
    <div class="cube-list-item">
      account set
    </div>
  </div>
  <div class="cube-list-group">
    <div class="cube-list-item">
      account set
    </div>
    <div class="cube-list-item">
      account set
    </div>
  </div>
  <div class="cube-list-group">
    <div class="cube-list-item">
      account set
    </div>
  </div>

  <button  @click="$router.push({ path: '/home/index' })">回到主页</button>
 </div>
</template>
<script>
export default {
  name: "setS"
}
</script>
