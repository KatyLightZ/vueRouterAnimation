<template>
<div>
  <div class="back" @click="this.$router.go(-1)">back</div>
  <div class="cube-list-group">
    <div class="cube-list-item" @click="$router.push({ path: '/set/password' })">
      dont send me msg
    </div>
    <div class="cube-list-item">
      change password
    </div>
    <div class="cube-list-item">
      delete account
    </div>
  </div>
</div>
</template>
<script>
export default {
  name: "accountC"
}
</script>
