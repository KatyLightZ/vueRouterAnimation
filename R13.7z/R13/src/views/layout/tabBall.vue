<template>
  <div class="tab-ball-box">
    <div  :class="['tab-ball-item',show?'active':'','first']" @click="show=!show">{{ show ? 'hide' : 'more' }}</div>
    <div :class="['tab-ball-inner',show?'active':'']">
      <div v-for="item in list "
           :key="item.path" @click="$router.replace({ path: item.path })"
           :class="['tab-ball-item',item.path===$route.fullPath?'active':'']"
      >
        {{ item.name }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "tabBall",
  props: {list: {default: []}},
  data() {
    return {show: true}
  },
}
</script>
