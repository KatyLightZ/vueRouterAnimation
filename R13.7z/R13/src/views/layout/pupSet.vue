<template>
  <!-- ref="me" -->
  <transition name="right-top-shine">
    <div class="pup-set" v-show="visible" @click="zli">
      <div class="pup-set-item">
        this is a set
      </div>
      <div class="pup-set-item">
        this is other set
      </div>
      <div class="pup-set-item">
        this is other set
      </div>
      <div class="pup-set-item">
        this is other set
      </div>
    </div>
  </transition>
</template>
<script setup>
import {defineEmits, defineProps, defineExpose, onBeforeUnmount, onMounted, ref} from "vue"
// eslint-disable-next-line no-unused-vars
const props = defineProps({
  visible: {
    type: Boolean,
  },
})
// const me = ref(null);
const me = ref(null)
const emits = defineEmits(['update:show'])
// eslint-disable-next-line no-unused-vars
const zli = () => {
  emits("update:visible", false)
}
// eslint-disable-next-line no-unused-vars
const wz = (e) => {
  // eslint-disable-next-line no-undef
  if (!me.value.contains(e.target) && props.visible) {
    emits("update:visible", false)
  }
}
const setMe = (m) => {
  me.value = m;
}
onBeforeUnmount(() => {
  document.removeEventListener('click', wz)
})
onMounted(() => {
  document.addEventListener('click', wz)
})
defineExpose({setMe})

</script>
