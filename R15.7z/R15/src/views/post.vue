<template>
  <div class="cover">
     <button class="button bolder warn linear to-info glass" @click="$router.go(-1)" >BACK</button>

    <div class="caption">
      <p>
        postId :{{ $route.params.i }}</p>
    </div>

  </div>
</template>
<script>
export default {
  name: "postA",
  mounted() {
    this.$theme.snowSpeedFast();
  }
}
</script>
