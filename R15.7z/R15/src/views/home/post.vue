<template>
  <div class="page-m">
    <kl-number-box size="mini" v-model="num"/>
    <kl-number-box size="small" v-model="num"/>
    <kl-number-box input-type="glass" v-model="num"/>
    <kl-number-box size="big" v-model="num"/>
    <kl-number-box size="bigger" type="primary" input-type="pill white" role="cir" v-model="num"/>
    <kl-number-box size="huge" v-model="num"/>
    <kl-number-box size="large" v-model="num"/>

  </div>
</template>
<script>
import KlNumberBox from "@/components/klNumberBox";
export default {
  name: "cC",
  components: {KlNumberBox},
  data(){
    return {
      num:0,
    }
  },
}
</script>