<template>
  <transition :name="$route.meta.transition">
    <router-view class="page"
                 :key="$route.meta.mutter"/>
  </transition>
</template>
<script>
export default {
  name: 'App',
  components: {},
  data() {
    return {
      pageKey: "",
      pastParam: {}
    }
  },
  mounted() {

  },

}
</script>
<style>
html {
  overflow: hidden;
}
.back{
  font-size: 20px;
  font-weight: bolder;
}
.postA {
  z-index: 999;
  box-shadow: 0 0 10px 5px #01071322;
  background-color: #b4dfe3;
  padding: 20px;
}
.cur{
  overflow-x: hidden;
  overflow-y: scroll;
}
body {
  box-sizing: border-box;
  margin: 0;
  height: 100vh;
  overflow: hidden;
  width: 100vw;
  position: relative;
  background:linear-gradient(#04cbcb, #0d5ca9);
}
.cur{
  padding: 10px;
}
 .box {
  background-color: rgba(255, 255, 255, 0.71);
  border-radius: 10px;
  padding: 10px;
  margin: 10px;
}

.page {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;

  bottom: 0;
  overflow: hidden;
}

.mask {
  background-color: rgba(0, 0, 0, 0.63);
  opacity: 0;
  pointer-events: none;
  z-index: 66;
}

.cur, .mask {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;

}

.slide-right-over-leave-active .mask {
  transition: all .4s ease-out;
}

.slide-right-over-leave-to .mask {
  opacity: 1;
  pointer-events: inherit;
}

.slide-right-over-leave-from .mask {
  opacity: 0;
}

.slide-left-over-enter-active .mask {
  transition: all .4s ease-out;
}

.slide-left-over-enter-to .mask {
  opacity: 0;
}

.slide-left-over-enter-from .mask {
  opacity: 1;
  pointer-events: inherit;
}

.trigger-enter-active,
.trigger-leave-active {
  /*transition: transform .4s ease-out;*/
  transition: 0s display .2s linear;
}

.trigger-enter-to {
  transform: translateY(0);
}

.trigger-enter-from {
  transform: translateY(100%);
}

.trigger-leave-to {
  transform: translateY(100%);
}

.trigger-leave-from {
  transform: translateY(0);
}

.slide-left-enter-active,
.slide-left-leave-active {
  transition: transform .4s ease-out;
}

.slide-left-enter-to {
  transform: translateX(0);
}

.slide-left-enter-from {
  transform: translateX(-100%);
}

.slide-left-leave-to {
  transform: translateX(100%);
}

.slide-left-leave-from {
  transform: translateX(0);
}

/*slide-left-over*/
.slide-left-over-enter-active, .slide-left-over-leave-active {
  transition: all .4s ease-out;
}

.slide-left-over-enter-to {

}

/* 很鬼畜
.slide-left-over-enter-to{
  transform: scale(1);
  opacity: 1;
}
.slide-left-over-enter-from{
  transform: scale(.8);
  opacity: .2;
}
*/

.slide-left-over-leave-to {
  transform: translateX(100%);
}

.slide-left-over-leave-from {
  transform: translateX(0);
}

/*slide-right-over*/
.slide-right-over-enter-active {
  transition: transform .4s ease-out;
}

.slide-right-over-leave-active {
  transition: all .4s ease-out;
}

/* 很鬼畜
.slide-right-over-leave-to{
  transform: scale(.8);
  opacity: .2;
}
.slide-right-over-leave-from{
  transform: scale(1);
  opacity: 1;
}
*/


.slide-right-over-leave-to {

}

.slide-right-over-leave-from {
}

.slide-right-over-enter-to {
  transform: translateX(0);

}

.slide-right-over-enter-from {

  transform: translateX(100%);
}


/**/
.slide-right-enter-active,
.slide-right-leave-active {
  transition: transform .4s ease-out;
}

.slide-right-enter-to {
  transform: translateX(0);
}

.slide-right-enter-from {
  transform: translateX(100%);
}

.slide-right-leave-to {
  transform: translateX(-100%);
}

.slide-right-leave-from {
  transform: translateX(0);
}

/**/
.fade-in-enter-active,
.fade-in-leave-active {
  transition: opacity .4s ease-out;
}

.fade-in-enter-to {
  opacity: 1;
}

.fade-in-enter-from {
  opacity: 0;
}

.fade-in-leave-to {
  opacity: 0;
}

.fade-in-leave-from {
  opacity: 1;
}
</style>
