<template>
  <div class="postA">
    <div @click="$router.go(-1)" class="back">back</div>
    <input v-model="queryString"/>
    <button @click="$router.replace({ path: '/search/'+queryString })">search</button>
    <div>
      this is a input you can jump more
    </div>
    <div>search result</div>
    <div>search Inner</div>
    <div>looking around</div>
  </div>
</template>
<script>
export default {
  name: "bB",
  data(){
    return{
      queryString:''
    }
  }
}
</script>
