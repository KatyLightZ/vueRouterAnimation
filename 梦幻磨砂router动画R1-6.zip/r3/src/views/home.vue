<template>
  <div>
    <div class="mask"></div>
    <transition :name="$route.meta.transition">
      <router-view style="flex: 1;" :key="$route.fullPath"/>
    </transition>
    <div class="ball" @click="$router.push({ path: '/send' })">add</div>
    <div style="" class="tabBar">
      <div v-for="item in list " :key="item.path" @click="$router.push({ path: item.path })"
           :class="['item',item.path===$route.fullPath?'active':'']">
        {{ item.name }}
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "homeA",
  data() {
    return {
      list: [
        {
          name: "home",
          path: '/home/a',
        },
        {
          name: "search",
          path: '/home/b',
        },
        {
          name: "myInfo",
          path: '/home/c',
        },
      ]
    }
  },
  mounted() {
    console.log('mounted home')
  }
}
</script>
<style>
.ball {
  height: 60px;
  width: 60px;


  position: absolute;
  right: 10px;
  bottom: 120px;
  color: #131313;
  backdrop-filter: blur(5px);
  line-height: 60px;
  vertical-align: middle;
  text-align: center;
  z-index: 2;
  background-color: #FFFFFF55;

}

.tabBar > .item {
  flex: 1;
  text-align: center;
}

.tabBar > .item.active {
  font-weight: bolder;
}

.tabBar {
  border-top: 1px solid rgba(255, 255, 255, 0.68);
  display: flex;
  color: #131313;
  position: absolute;
  z-index: 1;
  bottom: 0;
  background-color: rgba(198, 225, 241, 0.18);
  padding: 20px 0;
  backdrop-filter: blur(5px);
  right: 0;
  left: 0;
}
</style>
