<template>
<div class="cur">
nothing is
</div>
</template>
<script>
export default {
  name: "cC"
}
</script>