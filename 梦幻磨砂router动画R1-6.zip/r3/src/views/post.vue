<template>
  <div class="postA">
    <div @click="$router.go(-1)" class="back">back</div>
    <p>
      postId :{{$route.params.i}}</p>
  </div>
</template>
<script>
export default {
  name: "postA"
}
</script>
