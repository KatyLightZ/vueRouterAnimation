<template>
  <div class="postA">
    <div @click="$router.go(-1)" class="back">back</div>
    send a post

  </div>
</template>
<script>
export default {
  name: "sendA"
}
</script>
