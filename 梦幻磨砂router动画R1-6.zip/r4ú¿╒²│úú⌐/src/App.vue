<template>
  <transition :name="$route.meta.transition">
    <router-view class="page"
                 :key="$route.meta.mutter"/>
  </transition>
</template>
<script>
export default {
  name: 'App',
  components: {},
  data() {
    return {
      pageKey: "",
      pastParam: {}
    }
  },
  mounted() {

  },

}
</script>
<style>
.header{
  text-align: center;
  color: white;
  font-size: 24px;
  font-weight: bolder;
  padding: 10px 0;
  background-color: #FFFFFF44;
  border-bottom: 1px solid white;

}
.title{
  color: white;
  font-size: 24px;
  font-weight: bolder;
}
html {
  overflow: hidden;
}
.back{
  font-size: 20px;
  font-weight: bolder;
}
.searchA {
  z-index: 999;
  box-shadow: 0 0 10px 5px #01071322;
  background-color: #b4dfe322;

}
.postA {
  z-index: 999;

}

.postA .caption,.postA .title{
  background-color: rgba(158, 230, 236, 0.89);
  border-radius: 10px;
  margin: 10px;
  padding: 10px;
}
body {
  box-sizing: border-box;
  margin: 0;
  height: 100vh;
  overflow: hidden;
  width: 100vw;
  position: relative;
  background:linear-gradient(#04cbcb, #0d5ca9);
}

 .box {
  background-color: rgba(255, 255, 255, 0.71);
  border-radius: 10px;
  padding: 10px;
  margin: 10px;

}

.page {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;

  bottom: 0;
  overflow: hidden;
}
.header .icon {
  position: absolute;

  top: 10px;
  background-color: white;
  width: 30px;
  height: 30px;
  z-index: 88;
}
.header .icon.left{
  left: 10px;
}
.header .icon.right{
  right: 10px;
}
.cur  {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
padding-top: 60px;
  box-sizing: border-box;
  overflow-x: hidden;
  overflow-y: scroll;
}



.trigger-enter-active,
.trigger-leave-active {
  /*transition: transform .4s ease-out;*/
  transition: 0s display .2s linear;
}

.trigger-enter-to {
  transform: translateY(0);
}

.trigger-enter-from {
  transform: translateY(100%);
}

.trigger-leave-to {
  transform: translateY(100%);
}

.trigger-leave-from {
  transform: translateY(0);
}

.slide-left-enter-active,
.slide-left-leave-active {
  transition: transform .4s ease-out;
}

.slide-left-enter-to {
  transform: translateX(0);
}

.slide-left-enter-from {
  transform: translateX(-100%);
}

.slide-left-leave-to {
  transform: translateX(100%);
}

.slide-left-leave-from {
  transform: translateX(0);
}

/*slide-left-over*/
.slide-left-over-enter-active, .slide-left-over-leave-active {
  transition: all .4s ease-out;
}

.slide-left-over-enter-to {

}


.slide-left-over-enter-to{
  transform: scale(1);
  opacity: 1;
}
.slide-left-over-enter-from{
  transform: scale(.6);
  opacity:0;
}


.slide-left-over-leave-to {
  transform: translateX(100%);
}

.slide-left-over-leave-from {
  transform: translateX(0);
}

/*slide-right-over*/
.slide-right-over-enter-active {
  transition: transform .4s ease-out;
}

.slide-right-over-leave-active {
  transition: all .4s ease-out;
}


.slide-right-over-leave-to{
  transform: scale(.6);
  opacity: 0;
}
.slide-right-over-leave-from{
  transform: scale(1);
  opacity: 1;
}



.slide-right-over-leave-to {

}

.slide-right-over-leave-from {
}

.slide-right-over-enter-to {
  transform: translateX(0);

}

.slide-right-over-enter-from {

  transform: translateX(100%);
}


/**/
.slide-right-enter-active,
.slide-right-leave-active {
  transition: transform .4s ease-out;
}

.slide-right-enter-to {
  transform: translateX(0);
}

.slide-right-enter-from {
  transform: translateX(100%);
}

.slide-right-leave-to {
  transform: translateX(-100%);
}

.slide-right-leave-from {
  transform: translateX(0);
}

/**/
.fade-in-enter-active,
.fade-in-leave-active {
  transition: opacity .4s ease-out;
}

.fade-in-enter-to {
  opacity: 1;
}

.fade-in-enter-from {
  opacity: 0;
}

.fade-in-leave-to {
  opacity: 0;
}

.fade-in-leave-from {
  opacity: 1;
}
</style>
