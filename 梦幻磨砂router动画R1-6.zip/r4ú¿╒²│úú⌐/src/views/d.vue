<template>
<div class="cur">
   <div class="box">avatar account</div>
  <div class="title">i have to do something</div>
  <div class="box">need to do something</div>
  <div class="title">my date</div>
  <div class="box">date</div>
</div>
</template>
<script>
export default {
  name: "dD"
}
</script>