<template>
  <div :class="['left-table-back',!props.visible||'show']"  @click="handlerClick"></div>
  <div :class="['left-table',!props.visible||'show']">
    <div class="close" @click="handlerClick">close me</div>
    <div>my Avatar</div>
    <div>my Account</div>
    <div>my Set</div>
  </div>
</template>
<script setup>
import { defineEmits ,defineProps  } from "vue"
// eslint-disable-next-line no-unused-vars
const props = defineProps({
  visible: {
    type: Boolean,
  }
})
const emits = defineEmits(['update:visible'])
const handlerClick = () => {
  emits("update:visible", false)
 }
</script>
<style>
.left-table-back{
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  z-index: 88;
  display: none;
}
.left-table {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 80vw;
  background-color: rgba(255, 255, 255, 0.33);
  border-right: 1px solid rgba(255, 255, 255, 0.23);
  z-index: 99;
  backdrop-filter: blur(2px);
  transition: transform .6s ease-in;
  box-shadow: 0 0 10px 5px rgba(0, 0, 0, 0.15);
  transform: translateX(-130%);
}
.left-table.show{
  transition: transform .6s ease-in;
  transform: translateX(0);
}
.left-table-back.show{

  display: block;
}
</style>