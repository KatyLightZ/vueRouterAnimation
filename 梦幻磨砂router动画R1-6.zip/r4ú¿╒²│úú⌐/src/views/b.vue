<template>
  <div class="cur">
     <div class="box">
      <div>search Inner</div>
    </div>
    <div class="box"><input v-model="queryString"/></div>
    <div class="box">
      <button @click="$router.push({ path: '/search/'+queryString })">search</button>
    </div>
    <div class="box">
      <div>
        this is a input you can jump more
      </div>
    </div>
    <div class="box">
      <div>
        your news !!!!!
      </div>
    </div>

  </div>
</template>
<script>
export default {
  name: "bB",
  data() {
    return {
      queryString: ''
    }
  }
}
</script>
