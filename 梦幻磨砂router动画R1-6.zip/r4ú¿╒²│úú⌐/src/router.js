// router.js
// import Vue from "Vue";
// import transitionRouter from "vue-transition-router";
import {createRouter, createWebHistory} from "vue-router";

const routes = [
    {
        path: '/home',
        name: 'home',
        meta: {transition: 3, mutter: "/home"},
        component: () => import("./views/home.vue"),
        children: [
            {path: '/home', redirect: '/home/a'},
            {
                path: "a",
                name: "a",
                meta: {
                    menu: 1,
                    transition: 3,
                    title:'home'
                },
                component: () => import("./views/a.vue"),
            },
            {
                path: "b",
                name: "b",
                meta: {
                    menu: 2,
                    transition: 3,
                    title:'search'
                },
                component: () => import("./views/b.vue"),
            },
            {
                path: "c",
                name: "c",
                meta: {
                    menu: 3,
                    transition: 3,
                    title:'post'
                },
                component: () => import("./views/c.vue"),
            },
            {
                path: "d",
                name: "d",
                meta: {
                    menu: 4,
                    transition: 4,
                    title:'myInfo'
                },
                component: () => import("./views/d.vue"),
            },
        ]

    },
    {path: '/', redirect: '/home/a'},
    {
        path: '/search/:q?',
        meta: {
            child: 1,
            transition: 3, mutter: "/search"
        }
        , component: () => import("./views/search.vue"),
    },
    {
        path: "/post/:i?",
        name: "post",
        meta: {
            child: 1,
            transition: 3, mutter: "/post"
        },
        component: () => import("./views/post.vue"),
    },
    {
        path: "/send",
        name: "send",
        meta: {
            child: 1,
            transition: 3, mutter: "/send"
        },
        component: () => import("./views/send.vue"),
    },
];

let router = createRouter({
    history: createWebHistory(),
    routes: routes
})

// 全局前置守卫：初始化时执行、每次路由切换前执行
router.beforeEach((to, from, next) => {
    console.dir(to, from, next)
    if (from) {
        if (to.meta.menu && from.meta.menu) {
            if (to.meta.menu > from.meta.menu) {
                to.meta.transition = 'slide-right';
            } else {
                to.meta.transition = 'slide-left';
            }
            next();
            return;
        } else if (to.meta.child && from.meta.menu) {
            console.log('slide-right-over')
            to.meta.transition = 'slide-right-over';
            next();
            return;
        } else if (to.meta.menu && from.meta.child) {
            console.log('slide-left-over')
            to.meta.transition = 'slide-left-over';
            next();
            return;
        }
    }
    to.meta.transition = 'none';
    //       to.meta.transition='fade-in';
    next();
    /*// to.meta.isAuth 路由中自定义变量
    if(to.meta.isAuth)
    {   //判断当前路由是否需要进行权限控制
        //localStorage.getItem('权限名称') 获取存储在本地的权限变量
        if(localStorage.getItem('权限名称')==='权限数值'){  //权限控制的具体规则
            next(); //放行
        }else
        {
            alert('暂无权限查看');
        }
    }else
    {
        next(); //放行
    }*/
})

// export default router;
export default router