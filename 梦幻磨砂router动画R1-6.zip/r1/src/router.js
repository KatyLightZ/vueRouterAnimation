
// router.js
// import Vue from "Vue";

// import transitionRouter from "vue-transition-router";
import {createRouter,createWebHistory} from "vue-router";

const routes = [
    {
        path: "/a",
        name: "a",
        meta: {
            menu:1,
            transition:3,
        },
        component: () => import("./views/a.vue"),
    },
    {
        path: "/",
        name: "home",
        meta: {
            menu:1,            transition:3,
        },
    },
    {
        path: "/b",
        name: "b",
        meta: {
            menu:2,
            transition:3,
        },
        component: () => import("./views/b.vue"),
    },
    {
        path: "/c",
        name: "c",
        meta: {
            menu:3,
            transition:3,

        },
        component: () => import("./views/c.vue"),
    },
    {
        path: "/post",
        name: "post",
        meta: {
            child:1,
            transition:3,
        },
        component: () => import("./views/post.vue"),
    },
];

let router=createRouter({
    history:createWebHistory(),
    routes:routes
})

// 全局前置守卫：初始化时执行、每次路由切换前执行
router.beforeEach((to,from,next)=>
{
    if(from){
        if(to.meta.menu&&from.meta.menu){
            if(to.meta.menu>from.meta.menu){
                to.meta.transition='slide-right';
            }else{
                to.meta.transition='slide-left';
            }
            next();
        }else if(to.meta.child&&from.meta.menu){
            to.meta.transition='slide-right-over';
            next();
        }else if(to.meta.menu&&from.meta.child){
            to.meta.transition='slide-left-over';
            next();
        }
    }
    //       to.meta.transition='fade-in';
    next();
    /*// to.meta.isAuth 路由中自定义变量
    if(to.meta.isAuth)
    {   //判断当前路由是否需要进行权限控制
        //localStorage.getItem('权限名称') 获取存储在本地的权限变量
        if(localStorage.getItem('权限名称')==='权限数值'){  //权限控制的具体规则
            next(); //放行
        }else
        {
            alert('暂无权限查看');
        }
    }else
    {
        next(); //放行
    }*/
})

// export default router;
export default router