<template>
<div class="c">cccccccccc</div>

</template>

<script>
export default {
  name: "cC"
}
</script>

<style scoped>

</style>