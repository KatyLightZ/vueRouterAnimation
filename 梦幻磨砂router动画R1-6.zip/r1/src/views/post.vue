<template>
<div class="postA">postA
<p>postApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostA</p></div>
</template>

<script>
export default {
  name: "postA"
}
</script>

<style scoped>
.postA{
  background-color: lightskyblue;
}
</style>