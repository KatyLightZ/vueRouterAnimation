<template>
<div class="b">bbbbbbbbbbbbbbb</div>
</template>

<script>
export default {
  name: "bB"
}
</script>

<style scoped>

</style>