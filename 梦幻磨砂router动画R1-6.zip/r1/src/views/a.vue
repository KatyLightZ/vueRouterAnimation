<template>
<div class="a">aaaaaaaaaaaaaaaaaaaaaaaaa
<div @click="$router.push({ path: '/post' })">this is a child to new post</div>
</div>
</template>

<script>
export default {
  name: "aA"
}
</script>

<style scoped>

</style>