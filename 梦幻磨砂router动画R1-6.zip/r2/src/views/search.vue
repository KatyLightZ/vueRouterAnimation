<template>
  <div class="postA">
    <div @click="$router.go(-1)">back</div>
    <input v-model="queryString"/>
    <div @click="$router.replace({ path: '/search/'+queryString })">search</div>
    <div>
      this is a input you can jump more
    </div>
    <div> search result</div>
    <div>search Inner</div>
    <div>looking around</div>
  </div>
</template>
<script>
export default {
  name: "bB",
  data(){
    return{
      queryString:''
    }
  }
}
</script>
