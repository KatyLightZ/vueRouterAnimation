<template>
<div class="cur">
  dsf
</div>
</template>
<script>
export default {
  name: "cC"
}
</script>