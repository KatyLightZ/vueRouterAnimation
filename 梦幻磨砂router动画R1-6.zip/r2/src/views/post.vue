<template>
  <div class="postA">postA
    <div @click="$router.go(-1)">back</div>
    <p>
      postApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostApostA</p>
  </div>
</template>
<script>
export default {
  name: "postA"
}
</script>
