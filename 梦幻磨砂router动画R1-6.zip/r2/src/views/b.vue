<template>
  <div class="cur">
    <div>search Inner</div>
    <input v-model="queryString"/>
    <div @click="$router.push({ path: '/search/'+queryString })">search</div>
    <div>
      this is a input you can jump more
    </div>
  </div>
</template>
<script>
export default {
  name: "bB",
  data() {
    return {
      queryString: ''
    }
  }
}
</script>
