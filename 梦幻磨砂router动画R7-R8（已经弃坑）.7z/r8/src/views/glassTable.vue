<template>
  <div :class="['glass-table-cover',!props.visible||'show']"></div>
  <div :class="['glass-table-back',!props.visible||'show']" @click="handlerClick"></div>
  <div :class="['glass-table',!props.visible||'show']">
    <div class="glass-table-close" @click="handlerClick">close me</div>
    <div class="glass-table-block">
      <div class="glass-table-img"></div>
      Avatar
      AvatarAvatarAvatarAvatarAvatar
    </div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Set</div>
    <div style="flex: 1"></div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Set</div>
  </div>
</template>
<script setup>
import {defineEmits, defineProps} from "vue"
// eslint-disable-next-line no-unused-vars
const props = defineProps({
  visible: {
    type: Boolean,
  }
})
const emits = defineEmits(['update:visible'])
const handlerClick = () => {
  emits("update:visible", false)
}
</script>
<style>
.glass-table-close {
  text-align: right;
  font-size: 20px;
}

.glass-table-img {
  background-color: #ffffff99;
  width: 100px;
  height: 100px;
  border-radius: 50%;
}

.glass-table-block {
  background-color: rgba(255, 255, 255, 0.65);
  padding: 10px;
  margin: 10px;
  border-radius: 10px;
}

.glass-table-item {
  color: #606060;
  border-bottom: 1px solid white;
  /*text-shadow: 0 0 2px black;*/
  font-size: 22px;
  padding: 20px 10px;
}

.glass-table-item:hover {
  background-image: linear-gradient(90deg, #FFFFFF99, transparent);
}

.glass-table-back {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  z-index: 88;
  transform: translateX(-100%);
}

.glass-table-cover {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  z-index: 88;
  pointer-events: none;
  background-color: rgba(0, 0, 0, 0.0);
  transition: background-color .3s linear ;
}

.glass-table {
  display: flex;
  flex-flow: column;
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 80%;
  background-color: rgba(255, 255, 255, 0.72);
  border-right: 1px solid rgba(255, 255, 255, 0.23);
  z-index: 99;
  backdrop-filter: blur(2px);
  transition: transform .3s ease-in;
  box-shadow: 0 0 10px 5px rgba(0, 0, 0, 0.15);
  transform: translateX(-130%);
}

.glass-table.show {
  transition: transform .3s ease-in;
  transform: translateX(0);
}

.glass-table-cover.show {
  pointer-events: inherit;
  transition: background-color .6s linear ;
  background-color: rgba(0, 0, 0, 0.53);
}

.glass-table-back.show {
  display: block;
  transition: transform 0s linear .3s;
  transform: translateX(0);
}

</style>