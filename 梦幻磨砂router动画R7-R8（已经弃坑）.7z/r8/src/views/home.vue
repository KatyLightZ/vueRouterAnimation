<template>
  <div>
    <glass-table v-model:visible="leftShow"/>
    <div class="nav-header">
      <div class="nav-header-icon left" @click="showT">12</div>
      {{$route.meta.title}}
      <div class="nav-header-icon right"></div>
    </div>
    <transition :name="$route.meta.transition">
      <router-view style="flex: 1;" :key="$route.fullPath"/>
    </transition>
    <div class="menu-ball" @click="$router.push({ path: '/send' })">add</div>
    <div style="" class="tabBar">
      <div v-for="item in list " :key="item.path" @click="$router.push({ path: item.path })"
           :class="['tabBar-item',item.path===$route.fullPath?'active':'']">
        {{ item.name }}
      </div>
    </div>
  </div>
</template>
<script>
import GlassTable from "@/views/glassTable";

export default {
  name: "homeA",
  components: {GlassTable},
  data() {
    return {
      leftShow: false,
      list: [
        {
          name: "home",
          path: '/home/index',
        },
        {
          name: "search",
          path: '/home/search',
        },
        {
          name: "post",
          path: '/home/post',
        },
        {
          name: "myInfo",
          path: '/home/me',
        },
      ]
    }
  },
  methods: {
    showT() {
      this.leftShow = true;
console.log('      this.leftShow = true;')
    }
  },
  mounted() {
    console.log('mounted home')
  }
}
</script>
<style>
.menu-ball {
  height: 60px;
  width: 60px;
  position: absolute;
  right: 10px;
  bottom: 120px;
  color: #131313;

  line-height: 60px;
  vertical-align: middle;
  text-align: center;
  z-index: 2;
  background-color: #FFFFFF55;
}

.navbar {
  top: 0;
  left: 0;
  right: 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.68);
  display: flex;
  color: #131313;
  position: absolute;
  z-index: 1;
  height: 40px;
  background-color: rgba(198, 225, 241, 0.18);
  padding: 10px 0;
  backdrop-filter: blur(5px);
}

.tabBar-item {
  flex: 1;
  position: relative;
  text-align: center;
  padding: 20px 0;
  line-height: 18px;
}

.tabBar-item.active {
  font-weight: bolder;

}

.tabBar-item.active::after {
  content: "";
  pointer-events: none;
  z-index: -1;
  background-color: rgba(255, 255, 255, 0.76);
  position: absolute;
  top: 5px;
  border-radius: 5px;
  bottom: 5px;
  right: 2px;

  left: 2px;

}

.tabBar {
  border-top: 1px solid rgba(255, 255, 255, 0.68);
  display: flex;
  color: #131313;
  position: absolute;
  z-index: 1;
  bottom: 0;
  background-color: rgba(198, 225, 241, 0.18);

  backdrop-filter: blur(5px);
  right: 0;
  left: 0;
}
</style>
