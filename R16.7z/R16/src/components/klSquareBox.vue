<template>

  <div class="square-box l3">
    {{list}}
    <div class="square"  v-for="item in list"  :key="item.src" >
      <div :class="['square-inner',item.text?'text':'']" >
        <template v-if="item.children&&item.children.length>0"  >
          <div class="square" v-for="zit in item.children"  :key="zit.src">
            <div class="square-inner">
              <img alt="" class="square-inner-image"
                   :src="zit.src"/>
            </div>
          </div>
        </template>
        <template v-else>
          <template v-if="item.text">{{item.text}}</template>
          <img v-else alt="" class="square-inner-image"
               :src="item.src"/>
        </template>
      </div>
    </div>
  </div>

</template>

<script>
export default {
  name: "klSquareBox",
  props: {
    list :{
      default:[
        {
          side: 2,
          children: [
            {
              src: "https://img1.baidu.com/it/u=2121915427,2168624551&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1666112400&t=36caa99d55237d803431ecaf4abbce96"
            },
            {
              src: "https://img0.baidu.com/it/u=934498461,73020862&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=700"
            },
            {
              src: "https://img0.baidu.com/it/u=3934080263,2967130006&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=933"
            },

            {
              src: "https://img1.baidu.com/it/u=780952297,1200937487&fm=253&fmt=auto&app=138&f=JPEG?w=224&h=305"
            },
          ],
        },
        {
          src: "https://img1.baidu.com/it/u=2121915427,2168624551&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1666112400&t=36caa99d55237d803431ecaf4abbce96"
        },
        {
          src: "https://img0.baidu.com/it/u=934498461,73020862&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=700"
        },
        {
          src: "https://img0.baidu.com/it/u=3934080263,2967130006&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=933"
        },
        {
          src: "https://img1.baidu.com/it/u=780952297,1200937487&fm=253&fmt=auto&app=138&f=JPEG?w=224&h=305"
        },
        {
          text:"Katy Perry"
        },
        {
          src: "https://img2.baidu.com/it/u=3665616389,614777451&fm=253&fmt=auto&app=138&f=JPEG?w=490&h=600"
        },
        {
          src: "https://img1.baidu.com/it/u=476266673,1542201690&fm=253&fmt=auto&app=138&f=JPEG?w=270&h=185"
        },
        {
          src: "https://img2.baidu.com/it/u=464736753,4100005328&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=519"
        },
        {
          src: "https://img1.baidu.com/it/u=2880576921,3981259860&fm=253&fmt=auto&app=138&f=JPEG?w=371&h=500"
        },
        {
          src: "https://img0.baidu.com/it/u=810480749,3476325787&fm=253&fmt=auto&app=138&f=JPEG?w=427&h=640"
        },
        {
          src: "https://img1.baidu.com/it/u=1561320362,1562554041&fm=253&fmt=auto&app=138&f=JPEG?w=336&h=512"
        },
        {
          src: "https://img2.baidu.com/it/u=1331722341,1941914216&fm=253&fmt=auto&app=138&f=JPEG?w=120&h=160"
        },
      ]
    }

  },
  mounted() {
    console.log(this.list)
  }
}
</script>
