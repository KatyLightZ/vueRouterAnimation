<template>
  <div class="page-m">
    <div class="title">something not only

    </div>
    <button>1</button>
    <button>1</button>
    <button>1</button>
    <button>1</button>
    <button>1</button>
    <button>1</button>

 <kl-button-wave class="full">wave</kl-button-wave>
    <div style="vertical-align: middle;line-height: 36px;">
      <i class="dot warn pulse mini"></i>
      <i class="dot warn pulse small"></i>

    </div>
<!--    <auto-mini-menu v-show="false"/>-->
    <button class="button glass primary" @click="$router.push({ path: '/login' })"> login
      <span class="badge">dsf</span>
    </button>
    <button class="button  glass" @click="$router.push({ path: '/login' })"> login
      <span class="badge-dot bigger"></span>
    </button>

    <div>
      <button class="button  glass" @click="$router.push({ path: '/login' })"> login
        <span class="badge-dot warn"></span>
      </button>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/i' })">this is a child to new post i</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/asdfdfs' })">asdfdfs</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/fdsf' })">sdf</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/i' })">this is a child to new post i</div>
    </div>
  </div>
</template>
<script>
import AutoMiniMenu from "@/views/cop/autoMiniMenu";
import KlButtonWave from "@/components/klButtonWave";

export default {
  name: "aA",
  // eslint-disable-next-line vue/no-unused-components
  components: {KlButtonWave, AutoMiniMenu}
}
</script>