<template>
  <div style="display: flex;overflow: hidden;flex-flow: column;" class="cover">
    <div class="f1"></div>
    <div style="padding:  0 30px;">

      <div style="text-align: center;padding-bottom: 60px;">
        <div style="display: inline-block;position: relative;font-size: 0;">
          <img src="https://img1.baidu.com/it/u=1899294918,3468224768&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=313"
               class="user-avatar large round " alt="">
          <div class="dot right-top pulse large success"></div>
        </div>
      </div>
      <kl-form :rules="rules" :form="form" ref="klf">
        <kl-form-row class="row-flex wide">
          <kl-input class="form-input trans pill glass" data-input="email" v-model="form.email"/>
          <div class="form-info hook" data-info="email">password missing</div>
        </kl-form-row>
        <kl-form-row class="row-flex wide">
          <kl-input class="form-input pill trans  glass right-space" data-input="password" v-model="form.password"/>
          <button class="button success cir " @click="checkYou"></button>
          <div class="form-info hook" data-info="password">password missing</div>
        </kl-form-row>
      </kl-form>

      <div class="row-flex padding-normal ">
        <button class="button linear love to-warn     pill f1 right-space">
          <span style="width: 70%;display: inline-block"  @click="$router.push({ path: '/forget' })" class="text-align-justify">忘记密码</span>
          </button>
        <button @click="$router.push({ path: '/register' })" class="button primary to-info linear   pill  f1">
          <span style="width: 70%;display: inline-block" class="text-align-justify">注册</span>
          </button>
      </div>
      <div>
        <button @click="$router.push({ path: '/home' })" class="button primary to-love linear full  pill   ">
          <span style="width: 70%;display: inline-block" class="text-align-justify">暗门</span>
        </button>
      </div>
    </div>
    <div class="f2"></div>
  </div>
</template>
<script>
import KlForm from "@/components/klForm";
import KlInput from "@/components/klInput";
import KlFormRow from "@/components/klFormRow";

export default {
  name: "loginC",
  components: {KlFormRow, KlInput, KlForm},
  data() {
    return {
      form: {
        email: '',
        password: ''
      },
      rules: {
        'password': [
          {
            type: 'empty',
            msg: "输入password"
          },
          {
            type: 'number',
            msg: "输入数字密码"
          }
        ],
        'email': [
          {
            type: 'empty',
            msg: "输入email"
          }
        ],

      },

    }
  },
  methods: {
    checkYou() {

      this.$refs.klf.vali().then(res => {
        console.log(res, 'res')
      }).catch(e => {
        console.log(e, '错误')
      })
    }
  },
  mounted() {
    this.$theme.snowSpeedPause();
  }
}
</script>
