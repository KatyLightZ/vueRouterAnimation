<template>
  <div :class="['glass-table-cover',!props.visible||'show']"></div>
  <div :class="['glass-table-back',!props.visible||'show']" @click="handlerClick"></div>
  <div :class="['glass-table',!props.visible||'show']">
    <div class="glass-table-close" style="text-align: right">
      <span @click="handlerClick">close me</span>
    </div>
    <div class="glass-info-card">
      <div class="row-flex">
        <div class="col-auto col-padding">
          <img class="user-avatar big round" src="https://img2.baidu.com/it/u=1231891383,1640948087&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=560" alt="avatar"/>
        </div>
        <div class="col-1 col-padding">
          <div class="user-nickname-large">Alice</div>
          <div class="user-attache">@alice999</div>
          <div class="user-desc">Alice is here</div>
        </div>
      </div>
    </div>
    <div class="glass-table-item"   @click="$router.push({ path: '/set' })">my Set</div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Set</div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Set</div>
    <div class="glass-table-item">my Avatar</div>
    <div class="glass-table-item">my Account</div>
    <div class="glass-table-item">my Set</div>
  </div>
</template>
<script setup>
import {defineEmits, defineProps} from "vue"
// eslint-disable-next-line no-unused-vars
const props = defineProps({
  visible: {
    type: Boolean,
  }
})
const emits = defineEmits(['update:visible'])
const handlerClick = () => {
  emits("update:visible", false)
}
</script>
