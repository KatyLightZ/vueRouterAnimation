<template>
  <div class="cover">
    <button class="button bolder warn linear to-info glass" @click="$router.go(-1)">BACK</button>
    table
    太过于臃肿，
<!--    <table style="width: 70%">-->
<!--      <tbody>-->
<!--      <tr>-->
<!--        <td>`</td>-->
<!--        <td>`</td>-->
<!--        <td>`</td>-->
<!--      </tr>-->
<!--      <tr>-->
<!--        <td>`</td>-->
<!--        <td>`</td>-->
<!--        <td>`</td>-->
<!--      </tr>-->
<!--      <tr>-->
<!--        <td>`</td>-->
<!--        <td>`</td>-->
<!--        <td>`</td>-->
<!--      </tr>-->
<!--      <tr>-->
<!--        <td>`</td>-->
<!--        <td>`</td>-->
<!--        <td>`</td>-->
<!--      </tr>-->
<!--      </tbody>-->
<!--    </table>-->
    <div class="caption">
      <p>
        postId :{{ $route.params.i }}</p>
    </div>
    <kl-square-box/>
  </div>
</template>
<script>
import klSquareBox from "@/components/klSquareBox";
export default {
  name: "postA",
  components: {klSquareBox},
  data(){
    return {
      list:[
        {
          children:[
            {
              src:""
            },
            {
              src:""
            },
            {
              src:""
            },

            {
              src:""
            },
            {
              src:""
            },
            {
              src:""
            },

          ],
        },
        {
          label:""
        }
        ,
        {
          src:""
        }
      ]

    }
  },
  mounted() {
    this.$theme.snowSpeedFast();
  }
}
</script>
<!--<style scoped>-->


<!--tbody, table, tr {-->
<!--  width: 100%;-->
<!--  border-collapse: collapse;-->
<!--}-->

<!--tbody {-->


<!--}-->

<!--td {-->
<!--  padding-bottom: 33.33333333333%;-->
<!--  border: 1px solid crimson;-->
<!--  position: relative;-->
<!--}-->

<!--</style>-->
