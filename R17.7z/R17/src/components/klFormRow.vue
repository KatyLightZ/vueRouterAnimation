<template>
  <div class="form-row wide" ref="row">
    <slot></slot>
  </div>
</template>

<script>
import {getCurrentInstance} from "vue";

export default {
  name: "klFormRow",
  props: {

    prop: {
      type: String,
    },

  },
  setup() {
    const {proxy} = getCurrentInstance();
    const hideErrorInfo = () => {

      let c = proxy.$refs.row.querySelector('.form-info');
      console.log(c)
      c.classList.remove('show');
    }
    const showError = (e) => {
      console.log(e)
    }
    console.log('setup')
    return {showError, hideErrorInfo}
  }
}


</script>

<style scoped>

</style>