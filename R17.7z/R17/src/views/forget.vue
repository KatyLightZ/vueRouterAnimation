<template>
  <div style="display: flex" class="glass-block photic">

    <div style="margin: auto;width: 100%" >
      <div style="text-align: center;padding :40px 0 60px 0;" class="glass-block linear primary to-error fade">
        <div style="display: inline-block;position: relative;font-size: 0;">
          <img src="https://img1.baidu.com/it/u=1899294918,3468224768&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=313"
               class="user-avatar big round " alt="">
          <div class="dot right-top pulse large warn linear to-love"></div>
        </div>
      </div>
      <div class="form white white-line right" >
        <div class="row-flex form-row">
          <div class="row-flex-label text-align-justify">邮箱</div>
          <input class="form-input glass-selection error "/>
          <div class="form-input-back glass linear info to-error "></div>
        </div>
        <div class="row-flex form-row">
          <div class="row-flex-label  text-align-justify">验证码</div>
          <input class="form-input glass-selection  love "/>
          <div class="form-input-back glass linear love  to-warn "></div>
        </div>
      </div>
      <div class="row-flex">
        <button class="button glass linear warn to-info round f1" @click="$router.push({ path: '/login' })">发送邮箱</button>
      </div>
      <div>真实环境不可能显示的内容</div>
      <div class="button-exclude">
        <button class="button glass  " > 评论
          <span class="badge linear love to-info glass ">11</span>
        </button>
        <button class="button glass  " > 评论
          <span class="badge   love  glass ">11</span>
        </button>
        <button class="button glass  " > 评论pulse
          <span class="dot linear right-top  glass  love to-info large"> </span>
        </button>
        <button class="button glass  " > 评论
          <span class="badge-dot linear   glass love to-info large"> </span>
        </button>
        <button class="button glass  " > 评论
          <span class="badge linear love to-info">11</span>
        </button>
      </div>

    </div>

  </div>
</template>
<script>


export default {
  name: "findC",

  data() {
    return {
      form: {
        email: '',
        password: ''
      },
      rules: {
        'password': [
          {
            type: 'empty',
            msg: "输入password"
          },
          {
            type: 'number',
            msg: "输入数字密码"
          }
        ],
        'email': [
          {
            type: 'empty',
            msg: "输入email"
          }
        ],

      },

    }
  },
  methods: {
    checkYou() {

      this.$refs.klf.vali().then(res => {
        console.log(res, 'res')
      }).catch(e => {
        console.log(e, '错误')
      })
    }
  },
  mounted() {
    this.$theme.snowSpeedPause();
  }
}
</script>
<style scoped>
.form .row-flex-label{
  width: 80px;

  user-select: none;
}

</style>
