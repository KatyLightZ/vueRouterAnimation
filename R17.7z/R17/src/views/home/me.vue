<template>
  <div class="page-m">
    <div>
      <div class="row-flex">
        <div class="row-flex-label white">按钮内容</div>
        <input class="form-input glass pill" v-model="text"/>
      </div>
      <div class="row-flex block  ">
        <div class="row-flex-label white">基本样式</div>
        <button
            :style="{
          opacity:index===buttonHollow?1:.5
            }"
            :class="['button small',item]" v-for="(item,index) in buttonHollowArr" :key="index"
            @click="buttonHollow=index">{{ item }}
        </button>
      </div>
<!--      buttonLin-->

      <div class="row-flex block white">
        <div class="row-flex-label white">颜色类型</div>
        <button :style="{
          opacity:index===buttonType?1:.5
            }" :class="['button small  ',item]" v-for="(item,index) in buttonTypeArr" :key="index"
                @click="buttonType=index">{{ item }}
        </button>
      </div>
      <div class="row-flex block white">
        <div class="row-flex-label white">渐变类型</div>
        <button
            :style="{
          opacity:index===buttonTypeL?1:.5
            }"
            :class="['button small linear', buttonTypeArr[buttonType],item]" v-for="(item,index) in buttonTypeLArr"
            :key="index"
            @click="buttonTypeL=index">{{ item }}
        </button>
      </div>
      <div class="row-flex block white">
        <div class="row-flex-label white">渐变角度</div>
        <button
            :style="{
          opacity:index===buttonLin?1:.5
            }"
            :class="['button small linear', item, buttonTypeLArr[buttonTypeL],
           buttonTypeArr[buttonType],
            ]" v-for="(item,index) in buttonLinArr"
            :key="index"
            @click="buttonLin=index">{{ item }}
        </button>
      </div>
      <div class="row-flex block white">
        <div class="row-flex-label white">形状类型</div>
        <button
            :style="{
          opacity:index===buttonRole?1:.5
            }"
            :class="['button small  ',item]" v-for="(item,index) in buttonRoleArr" :key="index"
            @click="buttonRole=index">{{ item }}
        </button>
      </div>


      <div class="row-flex block white">
        <div class="row-flex-label white">hollow边框类型</div>
        <button :style="{
          opacity:index===buttonWidth?1:.5
            }" :class="['button small hollow ',item]" v-for="(item,index) in buttonWidthArr" :key="index"
                @click="buttonWidth=index">{{ item }}
        </button>
      </div>
      <div class="row-flex block white">
        <div class="row-flex-label white">大小类型</div>
        <button :style="{
          opacity:index===buttonSize?1:.5
            }" :class="['button   hollow ',item]" v-for="(item,index) in buttonSizeArr" :key="index"
                @click="buttonSize=index">{{ item }}
        </button>
      </div>

      <div class="row-flex block white">
        <div class="row-flex-label white">字体粗细</div>
        <button :style="{
          opacity:index===buttonWeight?1:.5
            }" :class="['button   ',item]" v-for="(item,index) in buttonWeightArr" :key="index"
                @click="buttonWeight=index">{{ item }}
        </button>
      </div>
      <div class="row-flex block white">
        <div class="row-flex-label white">大致类型</div>
        <button :style="{
          opacity:index===buttonS?1:.5
            }" :class="[' ',item]" v-for="(item,index) in buttonSArr" :key="index" @click="buttonS=index">{{
            item
          }}
        </button>
      </div>
      <div class="row-flex block white">
        <div class="row-flex-label white">布局类型 flex</div>
        <button :style="{
          opacity:index===buttonFull?1:.5
            }" :class="['button',item]" v-for="(item,index) in buttonFullArr" :key="index" @click="buttonFull=index">{{
            item
          }}
        </button>
      </div>
      <div class="row-flex block white">
        <div class="row-flex-label white">动画类型</div>
        <button :style="{
          opacity:index===buttonAni?1:.5
            }" :class="['button',item]" v-for="(item,index) in buttonAniArr" :key="index" @click="buttonAni=index">{{
            item
          }}
        </button>
      </div>


    </div>
    <div>
      <div>show you</div>
      <div :style="{
        display:buttonFull>1?'flex':''
      }">
        <button :class="[

          buttonHollowArr[buttonHollow],buttonSArr[buttonS],
          buttonRoleArr[buttonRole],
          buttonWeightArr[buttonWeight],
          buttonTypeArr[buttonType],
          buttonWidthArr[buttonWidth],
          buttonSizeArr[buttonSize],
         buttonFullArr[buttonFull],
         buttonTypeLArr[buttonTypeL],
      ]">{{ text }}
        </button>

        <button :class="[
'linear',
'pill-right',
'ani',
          buttonHollowArr[buttonHollow],buttonSArr[buttonS],
          buttonRoleArr[buttonRole],
          buttonTypeArr[buttonType],
          buttonWidthArr[buttonWidth],
          buttonLinArr[buttonLin],
          buttonSizeArr[buttonSize],
         buttonFullArr[buttonFull],
                  buttonTypeLArr[buttonTypeL],
                  buttonAniArr[buttonAni],
      ]">{{ text }}
        </button>
        <button :class="[
'linear',
'unable',
'pill-right',

          buttonHollowArr[buttonHollow],buttonSArr[buttonS],
          buttonRoleArr[buttonRole],
          buttonTypeArr[buttonType],
          buttonWidthArr[buttonWidth],
          buttonSizeArr[buttonSize],
         buttonFullArr[buttonFull],
                  buttonTypeLArr[buttonTypeL],
                  buttonAniArr[buttonAni],
      ]">{{ text }}
        </button>

      </div>

    </div>
    <div class="box">avatar account</div>
    <div class="title">i have to do something</div>
    <div class="box">need to do something</div>
    <div class="title">my date</div>
    <div class="box">date</div>
    <swiper-nav/>
<!--    <auto-mini-menu title="更多应用"-->
<!--                    :list="[-->
<!--      {-->
<!--        label:'电脑版'-->
<!--      },-->
<!--            {-->
<!--        label:'电脑版'-->
<!--      },-->
<!--            {-->
<!--        label:'电脑版'-->
<!--      },-->
<!--            {-->
<!--        label:'电脑版'-->
<!--      },-->
<!--            {-->
<!--        label:'电脑版'-->
<!--      },-->
<!--            {-->
<!--        label:'电脑版'-->
<!--      },-->
<!--  ]"-->
<!--    ></auto-mini-menu>-->
  </div>
</template>
<script>
import AutoMiniMenu from "@/views/cop/autoMiniMenu";
import SwiperNav from "@/views/cop/swiperNav";

export default {
  name: "dD",
  // eslint-disable-next-line vue/no-unused-components
  components: {SwiperNav, AutoMiniMenu},
  data() {
    //  <!--linear-skew linear-vertical ''-->
    return {
      buttonTypeArr: ['normal','secondary', 'info', 'love', 'error', 'warn', 'success', 'primary'],
      buttonAniArr: ['normal', 'toggle', 'scale-small', 'swing-transverse-small', 'error-shake'],
      buttonTypeLArr: ['normal','to-secondary' , 'to-info', 'to-love', 'to-error', 'to-warn', 'to-success', 'to-primary'],
      buttonSizeArr: ['mini', 'small', 'normal', 'big', 'bigger', 'huge', 'large'],
      buttonRoleArr: ['normal', 'cube', 'cir', 'round', 'pill'],
      buttonHollowArr: ['normal','plain', 'hollow', 'glass'],
      buttonWidthArr: ['thin', 'normal', 'stronger'],
      buttonSArr: ['button', 'button-text','text-colorful'],
      buttonFullArr: ['normal', 'full', 'f1', 'f2', 'f3', 'f4', 'f5'],
      buttonWeightArr: ['lighter' , 'normal', 'bold', 'bolder'],
      buttonLinArr: ['linear-skew' , 'linear-vertical','normal'],
      buttonType: 0,
      buttonAni: 0,
      buttonTypeL: 0,
      buttonSize: 0,
      buttonRole: 0,
      buttonHollow: 0,
      buttonWidth: 0,
      buttonS: 0,
      buttonLin: 0,
      buttonFull: 0,
      buttonWeight: 0,
      text: '0',
    }
  },

}
</script>