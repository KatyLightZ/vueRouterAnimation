<template>
  <div class="page-m">
    <div class="card   ">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        </div>
        <div class="card-cover-title primary">
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title 1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1</div>
        </div>
      </div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .

      </div>
    </div>
    <div class="card   ">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        </div>
        <div class="card-cover-title love">
          <div class="card-cover-media-button"></div>
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title 1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1</div>
        </div>
      </div>
    </div>
    <div class="card   ">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        </div>
        <div class="card-cover-title love linear to-info">
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title 1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1</div>
        </div>
      </div>
    </div>
    <div class="card  ">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        </div>
        <div class="card-cover-title  ">
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title 1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1</div>
        </div>
      </div>
    </div>
    <div class="card   ">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        </div>
        <div class="card-cover-title love linear to-info top">
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title 1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1</div>
        </div>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
      </div>
      <div class="card-title">title 1 title 1 title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title
        1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1
      </div>
    </div>
    <div class="card    ">
      <div class="row-flex row-space-bottom">
        <img class="user-avatar small cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-align-middle row-flex row-space-left">
          <span class="middle-auto">Cascada</span>
        </div>
      </div>
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        </div>
        <div class="card-cover-media-button"></div>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
      <div class="card-footer-menu">
        <div class="card-footer-menu-item">add</div>
        <div class="card-footer-menu-item">add</div>
        <div class="card-footer-menu-item">add</div>
        <div class="card-footer-menu-item">add</div>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image  " alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image  " alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <div class="card-cover-image-mask">+2</div>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">此处设计最多4张图片，超过的无需js隐藏，但是为了性能优化建议js隐藏。dark black mask info more
        picture numbers need js to use
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card">
      <div class="card-title"> Cascada - Everytime We Touch
      </div>
      <pre class="card-desc long">
Cascada - Everytime We Touch
I still hear your voice when you sleep next to me
I still feel your touch in my dreams my dreams
Forgive me my weakness
But I don't know why
Without you it's hard to survive
        'Cause everytime we touch
        I get this feeling
        And every time we kiss
        I swear I can fly
        Can't you feel my heart beat fast
        I want this to last
        Need you by my side
        'Cause everytime we touch
        I feel the static
        And everytime we kiss
        I reach for the sky
        Can't you hear my heart beat so

        I can't let you go

        Want you in my life

        Your arms are my castle

        Your heart is my sky

        They wipe away tears that I cry I cry

        The good and the bad times

        We've been through them all

        You make me rise when I fall
      </pre>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card">
      <div class="row-flex row-space-bottom ">
        <img class="user-avatar small cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-align-middle row-flex row-space-left">
          <span class="middle-auto">Cascada</span>
        </div>
      </div>
      <div class="card-goods">
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
      </div>
      <div class="card-info row-space-top">这只是一个测试~this is just a test~</div>
    </div>
    <div class="card       ">
      <div class="row-flex   ">
        <img class="user-avatar    " alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-align-middle row-flex row-space-left">
          <span class="middle-auto">Cascada</span>
        </div>
      </div>
    </div>
    <div class="card   ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
      </div>
      <div class="row-flex  row-space-top ">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar    " alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
      <div class="row-flex  row-space-top ">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar    " alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
      <div class="row-flex  row-space-top ">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar    " alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card">
      <div class="row-flex   ">
        <img class="user-avatar small cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-align-middle row-flex row-space-left">
          <span class="middle-auto">Cascada</span>
        </div>
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-left">
          <button class="button cir auto small love">+</button>
        </div>
      </div>
    </div>
    <div class="card-row">
      <div class="card">
        <div class="row-flex   ">
          <img class="user-avatar small cir" alt=""
               src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
          <div class="row-align-middle row-flex row-space-left">
            <span class="middle-auto">Cascada</span>
          </div>
          <div class="row-f1"></div>
        </div>
      </div>
      <div class="card-button row-align-middle">
        <button class="button auto cir error space">D</button>
        <button class="button auto cir warn space">P</button>
        <button class="button auto cir secondary space">C</button>
      </div>
    </div>
    <div class="card">
      row-flex 需要扩展，否则 后面的名字过长会导致样式崩坏
    </div>
    <div class="card">
      <div class="card-info  "> row-flex 需要扩展，否则 后面的名字过长会导致样式崩坏
      </div>
    </div>
    <div class="blank card  ">
      添加好友：
    </div>
    <div class="card-box">
      <div class="card inline">
        <div class="row-flex   ">
          <img class="user-avatar small cir" alt=""
               src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
          <div class="row-align-middle row-flex row-space-left">
            <span class="middle-auto">Cascada</span>
          </div>
          <div class="row-f1"></div>
          <div class="row-align-middle row-flex row-space-left">
            <button class="button cir auto small love">+</button>
          </div>
        </div>
      </div>
      <div class="card inline">
        <div class="row-flex   ">
          <img class="user-avatar small cir" alt=""
               src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
          <div class="row-align-middle row-flex row-space-left">
            <span class="middle-auto">Cascada</span>
          </div>
          <div class="row-f1"></div>
          <div class="row-align-middle row-flex row-space-left">
            <button class="button cir auto small love">+</button>
          </div>
        </div>
      </div>
      <div class="card inline">
        <div class="row-flex   ">
          <img class="user-avatar small cir" alt=""
               src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
          <div class="row-align-middle row-flex row-space-left">
            <span class="middle-auto">Cascada</span>
          </div>
          <div class="row-f1"></div>
          <div class="row-align-middle row-flex row-space-left">
            <button class="button cir auto small love">+</button>
          </div>
        </div>
      </div>
    </div>
    <div class="blank card  ">
      添加好友：
    </div>
    <div class="card-box horizontal  ">
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>


    </div>
    <div class="card-box horizontal tight ">
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>


    </div>
    <div class="card-box horizontal  ">
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>


    </div>

    <kl-number-box size="mini" v-model="num"/>
    <kl-number-box size="small" v-model="num"/>
    <kl-number-box input-type="glass" v-model="num"/>
    <kl-number-box size="big" v-model="num"/>
    <kl-number-box size="bigger" type="primary" input-type="pill white" role="cir" v-model="num"/>
    <kl-number-box size="huge" v-model="num"/>
    <kl-number-box size="large" v-model="num"/>

  </div>
</template>
<script>
import KlNumberBox from "@/components/klNumberBox";

export default {
  name: "cC",
  components: {KlNumberBox},
  data() {
    return {
      num: 0,
    }
  },
}
</script>