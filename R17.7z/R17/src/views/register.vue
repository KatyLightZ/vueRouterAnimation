<template>
  <div style="display: flex;">
    <div style="background-color: rgba(255,255,255,0.37);border-radius: 10px;width: 70%;padding: 20px;margin:   auto;height:auto;">
      <div class="form  relax     ">
        <div class="row-flex form-row">
          <div class="row-flex-label text-align-justify">用户名</div>
          <div class="row-f1">
            <input class="form-input pill trans-back back-active plain-fake primary"/>
            <div class="form-input-back pill linear to-primary love glass"></div>
          </div>
        </div>
        <div class="row-flex form-row">
          <div class="row-flex-label text-align-justify">密码</div>
          <div class="row-f1">
            <input type="password" class="form-input pill trans-back back-active plain-fake warn"/>
            <div class="form-input-back pill  linear to-primary info  glass"></div>
          </div>
        </div>
        <div class="row-flex form-row">
          <div class="row-flex-label text-align-justify">邮箱</div>
          <div class="row-f1 row-flex">
            <input class="form-input   trans-back back-active plain-fake love pill "  style="padding-right: 10px"/>
            <div class="form-input-back pill linear to-love info glass"></div>
            <div class='row-flex'>
              <button class="button auto glass linear warn to-error pill pill-right tight" >验证</button>
            </div>
          </div>
        </div>
        <div class="row-flex form-row">
          <div class="row-flex-label text-align-justify">验证码</div>
          <div class="row-f1 row-flex">
            <input class="form-input pill  trans-back back-active plain-fake love " style="padding-right: 10px"/>
            <div class="form-input-back pill linear to-love info glass"></div>
           <div class='row-flex'>
             <div class="input-span auto mini pill pill-right" style="margin-right: 10px">1122</div>
           </div>
          </div>

        </div>
      </div>
      <div>
        <button class="button glass linear love  pill full to-info" @click="$router.push({ path: '/login' })">
        <span style="width: 40%;display: inline-block" class="text-align-justify">注册</span>
        </button>
      </div>
    </div>

    <!--      <div class="row-flex form-row">
            <div class="row-align-middle">
              <button class="button-text auto">用户名</button>
            </div>
            <input class="form-input   back-active plain-fake primary"/>
            <div class="form-input-back pill glass"></div>
          </div>-->
  </div>
</template>
<script>
export default {
  name: "loginC"
}
</script>
<style scoped>
.form .row-flex-label{
  width: 56px;

user-select: none;
}

</style>
