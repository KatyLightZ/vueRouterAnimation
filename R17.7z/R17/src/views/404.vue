<template>
  <div class="page">
404 MAX
    <div  @click="$router.push({ path: '/home/index' })">    返回首页</div>
  </div>
</template>
<script>
export default {
  name: "aA"
}
</script>