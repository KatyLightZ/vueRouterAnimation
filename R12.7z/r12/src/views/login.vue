<template>
  <div style="display: flex;overflow: hidden;flex-flow: column;" class="cover">
    <div class="f1"></div>
    <div style="padding:  0 30px;">

      <div style="text-align: center;padding-bottom: 60px;">
        <div style="display: inline-block;position: relative;">
          <img src="https://img1.baidu.com/it/u=1899294918,3468224768&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=313"
               class="user-avatar large round " alt="">
          <div class="dot right-top pulse large success"></div>
        </div>
      </div>
      <kl-form :rules="rules" :form="form" ref="klf">
        <kl-form-row class="form-row wide">
          <kl-input class="form-input pill glass" data-input="email" v-model="form.email"/>
          <div class="form-info hook" data-info="email">password missing</div>
        </kl-form-row>
        <kl-form-row class="form-row wide">
          <kl-input class="form-input pill  glass right-space" data-input="password" v-model="form.password"/>
          <button class="button success cir " @click="checkYou"></button>
          <div class="form-info hook" data-info="password">password missing</div>
        </kl-form-row>
      </kl-form>
      <div class="flex-row  ">
        <button class="button love toWarn linear   pill f1 right-space">忘记密码</button>
        <button @click="$router.push({ path: '/register' })" class="button primary toInfo linear   pill  f1">注册
        </button>
      </div>
      <div>
        <button @click="$router.push({ path: '/home' })" class="button primary toLove linear full  pill   ">暗门
        </button>
      </div>
    </div>
    <div class="f2"></div>
  </div>
</template>
<script>
import KlForm from "@/components/klForm";
import KlInput from "@/components/klInput";
import KlFormRow from "@/components/klFormRow";

export default {
  name: "loginC",
  components: {KlFormRow, KlInput, KlForm},
  data() {
    return {
      form: {
        email: '',
        password: ''
      },
      rules: {
        'password': [
          {
            type: 'empty',
            msg: "输入password"
          },
          {
            type: 'number',
            msg: "输入数字密码"
          }
        ],
        'email': [
          {
            type: 'empty',
            msg: "输入email"
          }
        ],

      },

    }
  },
  methods: {
    checkYou() {

      this.$refs.klf.vali().then(res => {
        console.log(res, 'res')
      }).catch(e => {
        console.log(e, '错误')
      })
    }
  },
  mounted() {
    this.$theme.snowSpeedPause();
  }
}
</script>
