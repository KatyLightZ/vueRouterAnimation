export default {
    meme: {
        label: 'meme',
        do: () => {
            console.log('meme')
        }
    },
    addPost: {
        label: 'addPost',
        do: () => {
            console.log('addPost')
        }
    },
    sendMsg: {
        label: 'sendMsg',
        do: () => {
            console.log('sendMsg')
        }
    },
}