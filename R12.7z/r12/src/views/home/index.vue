<template>
  <div class="page-m">
    <div class="title">something not only

    </div>


    <div style="vertical-align: middle;line-height: 36px;">
      <i class="dot warn pulse mini"></i>
      <i class="dot warn pulse small"></i>

    </div>
    <auto-mini-menu v-show="false"/>
    <button class="button" @click="$router.push({ path: '/login' })"> login
      <span class="badge">dsf</span>
    </button>
    <button class="button" @click="$router.push({ path: '/login' })"> login
      <span class="badge-dot bigger"></span>
    </button>

    <div>
      <button class="button" @click="$router.push({ path: '/login' })"> login
        <span class="badge-dot warn"></span>
      </button>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/i' })">this is a child to new post i</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/asdfdfs' })">asdfdfs</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/fdsf' })">sdf</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/i' })">this is a child to new post i</div>
    </div>
  </div>
</template>
<script>
import AutoMiniMenu from "@/views/cop/autoMiniMenu";

export default {
  name: "aA",
  components: {AutoMiniMenu}
}
</script>