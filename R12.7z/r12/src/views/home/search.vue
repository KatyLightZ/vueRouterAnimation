<template>
  <div class="page-m">

    <div class="form-row  ">
      <div class="form-row-label white">搜索</div>
      <div class="form-f1-box">
        <div class="form-input-box">
          <input class="form-input glass" v-model="queryString"/>
          <div class="form-input-suf">
            <button class="button love" @click="$router.push({ path: '/search/'+queryString })">query</button>
          </div>
        </div>
      </div>
    </div>
    不同尺寸
    <div class="form-input-box   large">
      <div class="row-align-middle">
        <button class="button love   auto large cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto large cir">x</button>
      </div>
    </div>
    large:
    <div class="form-input-box inset large">
      <div class="row-align-middle">
        <button class="button love   auto bigger cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    huge:
    <div class="form-input-box inset huge">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    bigger:
    <div class="form-input-box inset bigger">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    big:
    <div class="form-input-box inset big">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    normal:
    <div class="form-input-box inset">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    small:
    <div class="form-input-box inset small">
      <div class="row-align-middle">
        <button class="button love   auto small cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    mini
    <div class="form-input-box inset mini">
      <div class="row-align-middle">
        <button class="button love   auto mini cir">S</button>
      </div>
      <input class="form-input back-active"/>
      <div class="form-input-back pill"></div>
      <div class="row-align-middle ">
        <button class="button error   auto mini cir">x</button>
      </div>
    </div>
    <input class="form-input glass "/>
    <input class="form-input white  " placeholder="white"/>
    <input class="form-input right" placeholder="right text"/>
    <div class="form-input-box">
      <div class="form-input-pre">
        <button class="button success">fds</button>
      </div>
      <input class="form-input"/>
      <div class="form-input-suf">
        <button class="button error">fds</button>
      </div>
    </div>
    <div class="form-input-box">
      <button class="button success">aaa</button>
      <input class="form-input"/>
      <button class="button error">vvv</button>
    </div>
    <div class="form-row  ">
      <div class="form-row-label white">你的地址</div>
      <div class="form-f1">
        <div class="form-input-box">
          <span class="input-span success">prefix</span>
          <div class="row-align-middle"><span class="input-span mini success auto">prefix</span></div>
          <button class="button success">prefix</button>
          <input class="form-input"/>

        </div>
        <div class="form-info row show">
          password missing
        </div>
      </div>
    </div>
    <div class="form-row  ">
      <div class="form-row-label white">你的地址</div>
      <div class="form-f1">
        <div class="form-input-box">
          <div class="form-input-pre">
            <button class="button success">测试</button>
          </div>
          <input class="form-input"/>
          <div class="form-input-suf">
            <button class="button error">测试</button>
          </div>
        </div>
        <div class="form-info row show">
          password missing
        </div>
      </div>
    </div>
    <div class="form-row  ">
      <div class="form-row-label">aaaaaaaaaaaa</div>
      <input class="form-input"/>
      <button class="button error">vvv</button>
    </div>
    <br/>
    <br/>
    <br/>
    <br/>
    <div class="form-row mini">
      <div class="form-row-label" style="flex-shrink: 0">mini</div>
      <div class="form-f1-box flex">
        <button class="button success mini " style="flex-shrink: 0">测试</button>
        <div class="form-f1-box" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show primary">
            password missing
          </div>
        </div>
        <button class="button   info mini " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="form-row small">
      <div class="form-row-label" style="flex-shrink: 0">mini</div>
      <div class="form-f1-box flex">
        <button class="button success small" style="flex-shrink: 0">测试</button>
        <div class="form-f1-box" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row info show">
            password missing
          </div>
        </div>
        <button class="button error primary small" style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="form-row  ">
      <div class="form-row-label" style="flex-shrink: 0">normal</div>
      <div class="form-f1-box flex">
        <button class="button success   " style="flex-shrink: 0">测试</button>
        <div class="form-f1-box" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row normal show">
            password missing
          </div>
        </div>
        <button class="button error   " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="form-row big">
      <div class="form-row-label" style="flex-shrink: 0">big</div>
      <div class="form-f1-box flex">
        <button class="button success big " style="flex-shrink: 0">测试</button>
        <div class="form-f1-box" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show warn">
            password missing
          </div>
        </div>
        <button class="button error big " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="form-row bigger">
      <div class="form-row-label" style="flex-shrink: 0">bigger</div>
      <div class="form-f1-box flex">
        <button class="button success bigger " style="flex-shrink: 0">测试</button>
        <div class="form-f1-box" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show love">
            password missing
          </div>
        </div>
        <button class="button error bigger " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="form-row huge">
      <div class="form-row-label" style="flex-shrink: 0">huge</div>
      <div class="form-f1-box flex">
        <button class="button success huge " style="flex-shrink: 0">测试</button>
        <div class="form-f1-box" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show success">
            password missing
          </div>
        </div>
        <button class="button error huge " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="form-row large">
      <div class="form-row-label" style="flex-shrink: 0">large</div>
      <div class="form-f1-box flex">
        <button class="button success large " style="flex-shrink: 0">测试</button>
        <div class="form-f1-box" style="min-width: 0">
          <input class="form-input" style="min-width: 0"/>
          <div class="form-info row show">
            password missing
          </div>
        </div>
        <button class="button error huge " style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="form-row">
      <div class="form-row-label">a111</div>
      <button class="button success">测试</button>
      <div class="form-f1-box ">
        <div class="form-f1-box flex">
          <input class="form-input"/>
          <button class="button error">测试</button>
        </div>
        <div class="form-info   show row">
          未来解决方式之一。需要绝对定位到输入里面？
        </div>
      </div>

    </div>
    <div class="">
      <div class="form-row">
        <div class="form-row-label">a111</div>
        <button class="button success">测试</button>
        <div class="form-f1-box" style="display: inline-block">
          <input class="form-input"/>
        </div>
        <button class="button error">测试</button>
      </div>
      <div class="form-info row show">
        未来解决方式之一。需要绝对定位到输入里面？
      </div>
    </div>
    backDiv必须写在后面。通过伪类触发。通常用于组合按钮，form-f1-box在pill下更加好
    <div class="form-input-box">
      <button class="button love pill pill-left tight">sd</button>
      <div class="form-f1-box">
        <input class="form-input back-active"/>
        <div class="form-input-back"></div>
      </div>
      <button class="button error pill pill-right tight">box</button>
    </div>

    <div class="form-row">
      <div class="form-row-label">你的地址</div>
      <input class="form-input back-active"/>
      <div class="form-input-back"></div>
    </div>
    <div class="form right white transparent white-line">
      form
      <div class="form-row">
        <div class="form-row-label">你的地址</div>
        <input class="form-input" placeholder="sdfkl"/>
      </div>

      <div class="form-row">
        <div class="form-row-label">sdffs</div>
        <div class="form-f1-box">
          <div class="form-input-box">
            <input class="form-input"/>
            <button class="button error">测试</button>
          </div>
          <div class="form-info row show">
            password missing
          </div>
        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <div class="form-f1-box">
          <div class="form-input-box">
            <input class="form-input"/>
            <div class="form-input-suf">
              <button class="button error">测试</button>
            </div>
          </div>
          <div class="form-info row show">
            password missing
          </div>
        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <div class="form-f1-box">
          <div class="form-input-box">
            <div class="form-input-pre">
              <button class="button success">测试</button>
            </div>
            <div class="form-f1-box">
              <input class="form-input"/>
              <div class="form-info row show">
                password missing
              </div>
            </div>
            <div class="form-input-suf">
              <button class="button error">测试</button>
            </div>
          </div>
        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">transparency</div>
        <div class="form-f1-box">
          <div class="form-input-box">
            <div class="form-input-pre">
              <button class="button success">测试</button>
            </div>
            <div class="form-f1-box">
              <input class="form-input left"/>
              <div class="form-info row transparency">
                password missing
              </div>
            </div>
            <div class="form-input-suf">
              <button class="button error">测试</button>
            </div>
          </div>
        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <input class="form-input left" placeholder="sdfkl"/>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <div class="form-f1-box">
          <input class="form-input" placeholder="sdfkl"/>
          <div class="form-info row show">
            password missing
          </div>
        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <div class="form-f1-box">
          <input class="form-input left" placeholder="sdfkl"/>
          <div class="form-info row show">
            password missing
          </div>
        </div>

      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "bB",
  data() {
    return {
      queryString: ''
    }
  }
}
</script>
