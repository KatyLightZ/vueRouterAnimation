<template>
  <div class="page-m">
    <span class="tag">tag</span>
    <span class="tag">tag</span>
    <span class="tag">tag</span>
    <span class="tag">tag</span>
渐变色背景会随着窗口拉升导致变小导致画面闪动

  </div>
</template>
<script>
export default {
  name: "cC"
}
</script>