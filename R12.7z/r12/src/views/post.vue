<template>
  <div class="cover">
    <div @click="$router.go(-1)" class="back">back</div>
    <div class="title">title</div>
    <div class="caption">
      <p>
        postId :{{ $route.params.i }}</p>
    </div>
    <div class="form">
      <div class="form-row wide">
        <input class="form-input pill" name="email"/>
        <div class="form-info hook">password missing</div>
      </div>
      <div class="form-row wide auto-margin">
        <input class="form-input pill right-space" name="password"/>
        <button class="button success cir "></button>
        <div class="form-info hook">password missing</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "postA",
  mounted() {
    this.$theme.snowSpeedFast();
  }
}
</script>
