<template>
<div>
  注册：
  <button  @click="$router.push({ path: '/login' })">登录</button>
  <div style="height: 400px;background-color: rgba(255,255,255,0.65)"></div>

</div>
</template>
<script>
export default {
  name: "loginC"
}
</script>
