<template>
  <div ref="mutter">
    <slot></slot>
  </div>
</template>
<script>
export default {
  name: "klForm",
  props: {
    rules: {
      default: {}
    },
    form: {
      default: {}
    },
  },
  mounted() {
    /*
    * 由于本人技能不娴熟只能用refs，slots不能操作内部方法，干脆纯css
    * */
    console.log(this.$refs.mutter)
  },
  methods: {
    vali() {
      let o = this.check();
      let right = true;
      return new Promise((resolve, reject) => {
        Object.keys(o).forEach(item => {
          const dt = this.$refs.mutter.querySelector(`[data-info="${item}"]`)
          const it = this.$refs.mutter.querySelector(`[data-input="${item}"]`)
          if (o[item].length > 0) {
            right = false;
            if (dt) {
              dt.classList.add('show')
              dt.innerText = o[item][0].msg;
            }
            if (it) {
              if (it.classList.contains('error-shake')) {
                it.classList.remove('error-shake')
                it.classList.remove('ani')
                setTimeout(() => {
                  it.classList.add('ani')
                  it.classList.add('error-shake')
                }, 1)
              } else {
                it.classList.add('ani')
                it.classList.add('error-shake')
              }

            }
          } else {
            Reflect.deleteProperty(o,item)
            if (dt) {
              dt.classList.remove('show')
            }
          }
        })
        if (right) {
          resolve(null);
        } else {
          reject(o);
        }
      })
    },
    check() {
      let cl = Object.keys(this.rules);
      let dr = {};
      for (let i = 0; i < cl.length; i++) {
        let key = cl[i];
        let val = this.form[key];
        let rList = this.rules[cl[i]];
        let c;
        let crr = [];
        if (rList && rList.length > 0) {
          for (let ii = 0; ii < rList.length; ii++) {
            switch (rList[ii].type) {
              case 'empty':
                if (val === '' || val === null || val === undefined) {
                  crr.push({
                    msg: rList[ii].msg ? rList[ii].msg : 'cant empty',
                    key: val
                  });

                }
                break;
              case "reg":
                // eslint-disable-next-line no-case-declarations
                c = rList[ii].reg.test(val);
                if (!c) {
                  crr.push({
                    msg: rList[ii].msg ? rList[ii].msg : 'reg cant pass',
                    /*以后我要做扩展分类*/
                    key: val
                  });

                }

                break;
              case 'number':
                c = /^[0-9]*[1-9][0-9]*$/.test(val);
                if (!c) {
                  crr.push({
                    msg: rList[ii].msg ? rList[ii].msg : 'is not number',
                    key: val
                  });

                }
                break;
            }
            if (crr.length > 0) break;
          }
        }
        dr[key] = crr;
      }
      return dr;
    }
  }
}
</script>

<style scoped>

</style>