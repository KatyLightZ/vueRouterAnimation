import {createApp} from 'vue'
import App from './App.vue'
import router from "@/router";

class theme {
    constructor() {
        let ctx;
        let star = [];
        let miniMode = false;
        let galaxyWidth, galaxyHeight
        let galaxy = document.createElement('canvas');
        document.body.appendChild(galaxy);
        this.speed = 1;
        //缩放速度值
        galaxy.classList.add('theme-canvas')
        miniMode = document.documentElement.clientHeight < 600;
        ctx = galaxy.getContext('2d');
        const createStar = () => {
            for (let i = 0; i < 200; i++) {
                star.push({
                    x: Math.floor(Math.random() * galaxyWidth),
                    y: Math.floor(Math.random() * galaxyHeight),
                    s: Math.random() * 6 + 2
                })
            }
        }
        const starS = (star) => {
            ctx.beginPath()
            ctx.arc(star.x, star.y, 3, 0, Math.PI * 2)
            ctx.fill()
            ctx.closePath()
        }
        const starMove = () => {
            for (let i = 0; i < star.length; i++) {
                star[i].y += (star[i].s) * this.speed
                if (star[i].y > galaxyHeight) {
                    star[i].y = 0
                    star[i].x = Math.floor(Math.random() * galaxyWidth)
                    if (miniMode) {
                        star[i].s = Math.random() * 2 + .5
                    } else {
                        star[i].s = Math.random() * 3 + 2
                    }
                }
                starS(star[i])
            }
        }
        const setScreen = () => {
            galaxy.height = document.documentElement.clientHeight
            galaxy.width = document.documentElement.clientWidth
            galaxyHeight = galaxy.height
            galaxyWidth = galaxy.width
            ctx.fillStyle = 'rgba(219,239,246,1)'
        }
        setScreen()
        createStar()
        setInterval(() => {
            ctx.clearRect(0, 0, galaxy.width, galaxy.height)
            starMove()
        }, 20)
        window.onresize = () => {
            setScreen()
        }
        this.love = 999
    }

    snowSpeedFast() {
        this.speed = 3
    }

    snowSpeedNormal() {
        this.speed = 1
    }

    snowSpeedSlow() {
        this.speed = .2
    }

    snowSpeedPause() {
        this.speed = 0.1
    }
}

const app = createApp(App)

app.config.globalProperties.$theme = new theme();
app.use(router)
app.mount('#body');

