<template>
<!--  <keep-alive>  </keep-alive>-->
    <transition :name="$route.meta.transition">
      <router-view class="page"
                   :key="$route.meta.mutter"/>
    </transition>
</template>
<script>
// import { getCurrentInstance } from "vue"


export default {
  name: 'App',
  components: {},
  data() {
    return {
      pageKey: "",
      pastParam: {}
    }
  },
  // setup(){
  //   const { proxy } = getCurrentInstance();
  //   console.log(proxy.$theme)
  //
  // },
  mounted() {
    // const internalInstance = getCurrentInstance();
    // const $theme = internalInstance.appContext.config.globalProperties.$theme;
    this.$theme.snowSpeedNormal();
    const resize = () => {

      const body=document.getElementById('body')
      body.style.height = window.innerHeight + "px";
      if (window.innerWidth > 502) {
        body.classList.add('glass')
        body.style.width=''
      } else {
        body.classList.remove('glass')
        body.style.width = window.innerWidth + "px";
      }
    }
    resize();
    window.onresize = () => {
      resize();
    }
  },
}
</script>
<style lang="scss">
//@import "assets/scss/basic.scss";
@import "assets/scss/ani.scss";
</style>
