import {createApp} from 'vue'
import App from './App.vue'
import router from "@/router";

class theme {
    constructor() {
        let ctx;
        let star = [];
        let miniMode = false;
        let galaxyWidth, galaxyHeight
        let galaxy = document.createElement('canvas');
        document.body.appendChild(galaxy);
        this.speed = 1;
        //缩放速度值
        galaxy.classList.add('theme-canvas')
        miniMode = document.documentElement.clientHeight < 600;
        ctx = galaxy.getContext('2d');
        const createStar = () => {
            for (let i = 0; i < 32; i++) {
                let c=Math.floor(Math.random()*100)+20;
                let k=galaxyWidth+c;
                star.push({
                    x: Math.floor(Math.random() * k)-c/2,
                    y: Math.floor(Math.random() * -galaxyHeight),
                    s:Math.floor( Math.random() * 2) + 2,
                    l:40,
                    r:Math.floor(Math.random()*100)+20
                })
            }
        }
        const starS = (star) => {
            ctx.beginPath()
            // ctx.arc(star.x, star.y, 1, 0, Math.PI * 2)
            // ctx.fill()
            ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2)
            ctx.stroke()
            ctx.fill()
            // ctx.moveTo(star.x,star.y);
            // ctx.lineTo(star.x,star.y-star.l);
            // ctx.stroke();

            ctx.closePath();
        }
        const starMove = () => {
            for (let i = 0; i < star.length; i++) {
                star[i].y += (star[i].s) * this.speed
                if (star[i].y - star[i].r*2 > galaxyHeight ) {
                    star[i].y = 0 - star[i].r*2
                    star[i].x = Math.floor(Math.random() * (galaxyWidth+star[i].r*2) -star[i].r)
                    if (miniMode) {
                        star[i].s = Math.random() * 2 + .5
                    } else {
                        star[i].s = Math.random() * 3 + 2
                    }
                }
                starS(star[i])
            }
        }
        const setScreen = () => {
            galaxy.height = document.documentElement.clientHeight
            galaxy.width = document.documentElement.clientWidth
            galaxyHeight = galaxy.height
            galaxyWidth = galaxy.width
            ctx.fillStyle = 'rgba(219,239,246,0.09)'
            ctx.strokeStyle='rgba(241,245,255,0.4)' ; //设置线条的颜色，如果不设置，默认填充黑色
            ctx.lineWidth = 3;
            ctx.strokeWidth=3;
            // ctx.lineCap="round"; // 此处设置以圆形结束，"butt", "round", "square"可以自己试一试。
        }
        setScreen()
        createStar()
        setInterval(() => {
            ctx.clearRect(0, 0, galaxy.width, galaxy.height)
            starMove()
        }, 20)
        window.onresize = () => {
            setScreen()
        }
        this.love = 999
    }

    snowSpeedFast() {
        this.speed =2
    }

    snowSpeedNormal() {
        this.speed = 1
    }

    snowSpeedSlow() {
        this.speed = .8
    }

    snowSpeedPause() {
        this.speed = 0.1
    }
}

const app = createApp(App)

app.config.globalProperties.$theme = new theme();
app.use(router)
app.mount('#body');

