<template>
<button class="button" >
<!--  @click="clickWave($event)"-->
  <span class="button-wave-box" ref="box">
    <span class="button-wave"></span>
  </span>
  <slot></slot>
  弃坑，不要引入
</button>
</template>

<script>

export default {
  name: "klButtonWave",
  methods:{
    clickWave(e){

      // let cubeWidth=this.$refs.box.clientWidth;
      // let cubeHeight=this.$refs.box.clientHeight;
      let cubeCirSide=Math.sqrt(Math.pow(this.$refs.box.clientWidth,2)+Math.pow(this.$refs.box.clientHeight,2))
      console.log(cubeCirSide)
      let wave=document.createElement('div')
      wave.style.background='#00007744'
      wave.style.position='absolute'
      //e.layerX
      wave.style.left=(0+e.clientX)+"px";
      wave.style.top=(-cubeCirSide/2+e.clientY)+"px";
      wave.style.width=cubeCirSide+"px";
      wave.style.height=cubeCirSide+"px";
      wave.style.scale='0';
      wave.style.transform=`translateX(${e.layerX}px),translateY(${e.layerY}px)`
      let i=0;
      this.$refs.box.appendChild(wave)
      let t=
      setInterval(()=>{
        i++;
        wave.style.scale='0.'+i;
        if(i>100){
          wave.style.scale='1' ;
          clearInterval(t);
        }
      },10)
      /*layerX
:
279
layerY
:
10*/
    }
  },
}
</script>

<style scoped>

</style>