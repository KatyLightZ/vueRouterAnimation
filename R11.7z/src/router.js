// router.js
// import Vue from "Vue";
// import transitionRouter from "vue-transition-router";
import {createRouter, createWebHistory} from "vue-router";
import menuBall from "@/views/enum/set/menuBall";

const routes = [
    {
        path: '/home',
        name: 'home',
        meta: {transition: 3, mutter: "/home"},
        component: () => import("./views/home.vue"),
        children: [
            {path: '/home', redirect: '/home/index'},
            {
                path: "index",
                name: "homeIndex",
                meta: {
                    menu: 1,
                    transition: 3,
                    title: 'home',
                    addBtn: menuBall.meme.label
                },
                component: () => import("./views/home/index.vue"),
            },
            {
                path: "search",
                name: "homeSearch",
                meta: {
                    menu: 2,
                    transition: 3,
                    title: 'search'
                },
                component: () => import("./views/home/search.vue"),
            },
            {
                path: "post",
                name: "homePost",
                meta: {
                    menu: 3,
                    transition: 3,
                    title: 'post',
                    addBtn: menuBall.addPost.label

                },
                component: () => import("./views/home/post.vue"),
            },
            {
                path: "me",
                name: "homeMe",
                meta: {
                    menu: 4,
                    transition: 4,
                    title: 'myInfo',
                    addBtn: menuBall.sendMsg.label
                },
                component: () => import("./views/home/me.vue"),
            },
            // {
            //     path: '/:catchAll(.*)',
            //     name: "home404",
            //     meta: {
            //         menu: 4,
            //         transition: 4,
            //         title:'home404'
            //     },
            //     component: () => import("./views/home/404.vue"),
            // },
        ]
    },
    {path: '/', redirect: '/home/index'},
    {
        path: '/search/:q?',
        name: "search",
        meta: {
            child: 4,
            transition: 3, mutter: "/search"
        }
        , component: () => import("./views/search.vue"),
    },
    {
        path: "/post/:i?",
        name: "post",
        meta: {
            child: 3,
            transition: 3, mutter: "/post"
        },
        component: () => import("./views/post.vue"),
    },
    {
        path: "/send",
        name: "send",
        meta: {
            child: 2,
            transition: 3, mutter: "/send"
        },
        component: () => import("./views/send.vue"),
    }, {
        path: "/set",
        name: "set",
        meta: {
            child: 1,
            transition: 3,
            mutter: "/set"
        },
        component: () => import("./views/set/index.vue"),
    },
    {
        path: "/set/account",
        name: "setAccount",
        meta: {
            child: 11,
            transition: 4,
            title: 'account',
            mutter: "/setAccount"
        },
        component: () => import("./views/set/account.vue"),
    },
    {
        path: "/set/password",
        name: "setPassword",
        meta: {
            child: 21,
            transition: 4,
            title: 'setPassword',
            mutter: "/setPassword"
        },
        component: () => import("./views/set/password.vue"),
    },
    {
        path: "/login",
        name: "login",
        meta: {
            outside: 2,
            transition: 3,
            mutter: "/login"
        },
        component: () => import("./views/login.vue"),
    },
    {
        path: "/register",
        name: "register",
        meta: {
            outside: 3,
            transition: 3,
            mutter: "/register"
        },
        component: () => import("./views/register.vue"),
    },
    {
        path: '/:catchAll(.*)',
        name: "max404",
        meta: {
            child: 1,
            transition: 4,
            title: 'max404'
        },
        component: () => import("./views/404.vue"),
    },
];
let router = createRouter({
    history: createWebHistory(),
    routes: routes
})
// 全局前置守卫：初始化时执行、每次路由切换前执行
router.beforeEach((to, from, next) => {
    /*第一次进来，from是{path: '/', name: undefined, */

    let ani = 'none'
    if (from.name) {
        if (to.meta.menu && from.meta.menu) {
            if (to.meta.menu > from.meta.menu) {
                ani = 'slide-right';
            } else {
                ani = 'slide-left';
            }
        } else if ((to.meta.child && from.meta.menu) || (to.meta.child && from.meta.child && to.meta.child > from.meta.child)) {
            ani = 'slide-right-over';
        } else if ((to.meta.menu && from.meta.child) || (to.meta.child && from.meta.child && to.meta.child < from.meta.child)) {
            ani = 'slide-left-over';
        } else if (to.meta.outside && (from.meta.child || from.meta.menu)) {
            ani = 'inner-cover';
        } else if (from.meta.outside && (to.meta.child || to.meta.menu)) {
            ani = 'outer-cover';
        } else if (from.meta.outside && to.meta.outside) {
            if (from.meta.outside > to.meta.outside) {
                ani = 'outer-cover';
            } else {
                ani = 'inner-cover';
            }
        }
    } else {
        ani = 'none';
    }
    to.meta.transition = ani;
    next();
    /*// to.meta.isAuth 路由中自定义变量
    if(to.meta.isAuth)
    {   //判断当前路由是否需要进行权限控制
        //localStorage.getItem('权限名称') 获取存储在本地的权限变量
        if(localStorage.getItem('权限名称')==='权限数值'){  //权限控制的具体规则
            next(); //放行
        }else
        {
            alert('暂无权限查看');
        }
    }else
    {
        next(); //放行
    }*/
})

// export default router;
export default router