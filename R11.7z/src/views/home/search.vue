<template>
  <div class="page-m">
    <div class="form-row  ">
      <div class="form-row-label white">搜索</div>
      <div class="form-f1">
        <div class="form-input-box">
          <input class="form-input glass" v-model="queryString"/>
          <div class="form-input-suf">
            <button class="button love" @click="$router.push({ path: '/search/'+queryString })">query</button>
          </div>
        </div>
      </div>
    </div>

    <input class="form-input glass "/>
    <input class="form-input white  " placeholder="white"/>
    <input class="form-input right" placeholder="right text"/>
    <div class="form-input-box">
      <div class="form-input-pre">
        <button class="button success">fds</button>
      </div>
      <input class="form-input"/>
      <div class="form-input-suf">
        <button class="button error">fds</button>
      </div>
    </div>
    <div class="form-input-box">
      <button class="button success">aaa</button>
      <input class="form-input"/>
      <button class="button error">vvv</button>
    </div>
    <div class="form-row  ">
      <div class="form-row-label white">你的地址</div>
      <div class="form-f1">
        <div class="form-input-box">
          <div class="form-input-pre">
            <button class="button success">测试</button>
          </div>
          <input class="form-input"/>
          <div class="form-input-suf">
            <button class="button error">测试</button>
          </div>
        </div>
        <div class="form-info row show">
          password missing
        </div>
      </div>
    </div>
    <div class="form-row  ">
      <div class="form-row-label">aaaaaaaaaaaa</div>
      <input class="form-input"/>
      <button class="button error">vvv</button>
    </div>
    <br/>
    <br/>
    <br/>
    <br/>
    <div class="form-row">
      <div class="form-row-label" style="flex-shrink: 0">你的sss地址</div>
      <div class="form-input-box"  style="min-width: 0">
        <button class="button success" style="flex-shrink: 0">测试</button>
        <div class="form-input-f1"  style="min-width: 0">
          <input class="form-input"  style="min-width: 0"/>
          <div class="form-info row show">
            password missing
          </div>
        </div>
        <button class="button error" style="flex-shrink: 0">测试</button>
      </div>
    </div>
    <div class="form-row">
      <div class="form-row-label">a222</div>
      <button class="button success">测试</button>
      <input class="form-input"  style="position: relative"/>
      <div class="form-info   show hook">
        未来解决方式之一。需要绝对定位到输入里面？
      </div>
      <button class="button error">测试</button>
    </div>
    <div class="form-row">
      <div class="form-row-label">a111</div>
      <button class="button success">测试</button>
      <div class="form-input-f1"  >
        <input class="form-input"/>
        <div class="form-info   show row">
          未来解决方式之一。需要绝对定位到输入里面？
        </div>
      </div>
      <button class="button error">测试</button>
    </div>
    <div class="">
      <div class="form-row">
        <div class="form-row-label">a111</div>
        <button class="button success">测试</button>
        <div class="form-input-f1" style="display: inline-block">
          <input class="form-input"/>
        </div>
        <button class="button error">测试</button>
      </div>
      <div class="form-info row show">
        未来解决方式之一。需要绝对定位到输入里面？
      </div>
    </div>

    <div class="form-row">
      <div class="form-row-label">divdiv</div>
      <div class="button success">测试</div>
      <div class="form-input-f1" style="display: inline-block">
        <input class="form-input"/>
        <div class="form-info row show">
          password missing
        </div>
      </div>
      <div class="button error">测试</div>
    </div>
    <div class="form-row">
      <div class="form-row-label">form-input</div>
      <div class="form-input-box">
        <button class="button success">测试</button>
        <input class="form-input"/>
        <button class="button error">测试</button>
      </div>
    </div>
    <br/>
    <br/>
    <br/>
    <br/> <br/>
    <br/>
    <br/>
    <br/>
    <div class="form right white transparent white-line">
      form
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <input class="form-input" placeholder="sdfkl"/>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">sdffs</div>
        <div class="form-f1">
          <div class="form-input-box">
            <input class="form-input"/>
            <button class="button error">测试</button>
          </div>
          <div class="form-info row show">
            password missing
          </div>
        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <div class="form-f1">
          <div class="form-input-box">
            <input class="form-input"/>
            <div class="form-input-suf">
              <button class="button error">测试</button>
            </div>
          </div>
          <div class="form-info row show">
            password missing
          </div>
        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <div class="form-f1">
          <div class="form-input-box">
            <div class="form-input-pre">
              <button class="button success">测试</button>
            </div>
            <div class="form-input-f1">
              <input class="form-input"/>
              <div class="form-info row show">
                password missing
              </div>
            </div>
            <div class="form-input-suf">
              <button class="button error">测试</button>
            </div>
          </div>

        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <div class="form-f1">
          <div class="form-input-box">
            <div class="form-input-pre">
              <button class="button success">测试</button>
            </div>
            <div class="form-input-f1">
              <input class="form-input left"/>
              <div class="form-info row show">
                password missing
              </div>
            </div>
            <div class="form-input-suf">
              <button class="button error">测试</button>
            </div>
          </div>
        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <input class="form-input left" placeholder="sdfkl"/>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <div class="form-f1">
          <input class="form-input" placeholder="sdfkl"/>
          <div class="form-info row show">
            password missing
          </div>
        </div>
      </div>
      <div class="form-row  ">
        <div class="form-row-label">你的地址</div>
        <div class="form-f1">
          <input class="form-input left" placeholder="sdfkl"/>
          <div class="form-info row show">
            password missing
          </div>
        </div>

      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "bB",
  data() {
    return {
      queryString: ''
    }
  }
}
</script>
