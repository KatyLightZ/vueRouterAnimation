<template>
  <div class="textarea-box"  >
    <textarea v-model="text" draggable="false"
              :rows="rows" style="resize:none;"
              class="form-input form-textarea  glass-fake warn  back-active"
              placeholder="font-white"

    ></textarea>
    <div class="form-input-back  linear warn to-info"></div>
    <span :class="[warnLength>0?'text-error':'','form-textarea-info']">{{ sizeLength }}/{{ maxLength }}</span>

  </div>
</template>

<script>
import {computed} from "vue";

export default {
  name: "klTextarea",
  props: {
    modelValue: {
      type: String,
    },
    rows:{
      default: 10
    },
    maxLength: {
      default: 20
    },
  },
  computed: {
    sizeLength() {
      return this.text.length;
    },
    warnLength() {
      return this.sizeLength - this.maxLength;
    },
  },
  emits: ["update:modelValue"],
  setup(props, {emit}) {
    const text = computed({
      get: () => props.modelValue,
      set: (newValue) => {
        emit('update:modelValue', newValue);
      }
    })
    return {text}
  },
}
</script>
