<template>
  <div :class="['kl-number-box',size]">
    <div class="row-flex-static">
      <button :class="['button  ',size,type,role]" @click="formData--">-</button>
      <input
          @input="inputChange($event)"
          :value="modelValue" type="number" :class="['form-input back-active',size]" />
      <div :class="['form-input-back',inputType,size]"></div>
      <button :class="['button  ',size,type,role]"  @click="formData++" >+</button>
    </div>
  </div>
</template>
<script>
import {computed} from "vue";
export default {
  name: "klNumberBox",
  props:{
    modelValue: {
      type: Number
    },
    size:{
      default:''
    },
    role:{
      default:'cube'
    },
    type:{
      default:''
    },
    inputType:{
      default:'white'
    }
  },
  emits: ["update:modelValue"],
  setup(props,{emit}){
    const formData=computed( {
      get: ()=> props.modelValue,
      set :(newValue)=>{
        emit('update:modelValue',newValue)
      }
    })
    return {formData}
  } ,
  // setup(props, { emit }) {
  //   const formData = ref({ ...props.modelValue })
  //   watch(
  //       formData,
  //       (newValue) => {
  //         emit('update:modelValue', newValue)
  //       },
  //       {
  //         deep: true
  //       }
  //   )
  //   return { formData }
  // },

  methods: {
    inputChange(e){
      this.$emit('update:modelValue', e.target.value);
    },

  }
}
</script>

<style scoped>

</style>