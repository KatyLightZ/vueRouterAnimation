<template>
<div style="position: relative;"  v-scroll:config="{
  child:true,
  color:'primary'
}">
  <div class="nav"   ref="mutter">
    <div v-for="(item,index) in list" class="nav-item" :key="index">{{ item }}</div>
  </div>
</div>
</template>
<script>
export default {
  name: "klNav",
  props: {},
  data() {
    return {
      list: [
        'l1111111111111111111111',
        'l1111111111111111111111l1111111111111111111111l1111111111111111111111',
        'l1111111111111111111111',
        'l1111111111111111111111',
        'l1111111111111111111111',
        'l1111111111111111111111',
        'l1111111111111111111111',
        'l1111111111111111111111',
        'l1111111111111111111111',
        'l1111111111111111111111',
        'l1111111111111111111111',
        'l1111111111111111111111',
        'l11111',
        'l11111',
        'l11111',
        'l11111',
        'l11111',
        'l11111',


      ]
    }
  },
  mounted() {
    setTimeout(() => {
     this.list.push('aaa')
    }, 2000)
  },
  methods: {}
}
</script>

<style scoped>

</style>