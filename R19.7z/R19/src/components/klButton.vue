<template>
<button class="button">
  <slot></slot>
</button>
</template>

<script>
export default {
  name: "klButton"
}
</script>

<style scoped>

</style>