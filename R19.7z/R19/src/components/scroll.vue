<template>
  <div class="scroll-track" ref="mutter" @click="moveTo">
    <div class="scroll" ref="kind"
         @mouseleave.stop.prevent="onMoveEnd"
         @mousedown.stop.prevent="onDragScroll"
         @mousemove.stop.prevent="onMoveScroll"
         @mouseup.stop.prevent="onMoveEnd"
         @touchstart.stop.prevent="onDragScroll"
         @touchmove.stop.prevent="onMoveScroll"
         @touchend.stop.prevent="onMoveEnd"
         :style="{
      width:childWidth+'px',
      left:childLeft+'px',
    }"></div>
  </div>
</template>

<script>const kUserAgent = {
  Opera: 'Opera',
  Firefox: 'Firefox',
  Chrome: 'Chrome',
  Safari: 'Safari',
  IE: 'IE',
};

// eslint-disable-next-line no-unused-vars
const getUserAgent = () => {
  const {userAgent} = navigator; // 取得浏览器的userAgent字符串
  if (userAgent.indexOf('Opera') > -1) {
    // 判断是否Opera浏览器
    return kUserAgent.Opera;
  }
  if (userAgent.indexOf('Firefox') > -1) {
    // 判断是否Firefox浏览器
    return kUserAgent.Firefox;
  }
  if (userAgent.indexOf('Chrome') > -1) {
    // 判断是否为谷歌浏览器
    return kUserAgent.Chrome;
  }
  if (userAgent.indexOf('Safari') > -1) {
    // 判断是否Safari浏览器
    return kUserAgent.Safari;
  }
  if (
      userAgent.indexOf('compatible') > -1 &&
      userAgent.indexOf('MSIE') > -1 &&
      userAgent.indexOf('Opera') > -1
  ) {
    // 判断是否IE浏览器
    return kUserAgent.IE;
  }
  return '';
};
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "scroll",
  data() {
    return {
      childWidth: 20,
      childLeft: 0,
      pastX: 0,
      scrollMoveWidth: 0,
      endLeft: 0,
      mouseLeft: 0,
      mutter: null,
      dragMove: false,
    }
  },
  mounted() {
    console.log('我被挂在了！')

  },
  methods: {
    moveTo(e) {
      if (e.target !== this.$refs.kind) {
        let left = Math.floor(e.offsetX - this.childWidth / 2)
        if (left < 0) {
          left = 0
        } else if (left > this.endLeft) {
          left = this.endLeft
        }
        this.mutter.scrollLeft = left / this.endLeft * this.scrollMoveWidth;
        this.childLeft = left
      }
    },
    onMoveEnd() {

      this.dragMove = false;
    },
    onMoveScroll(e) {
      if (this.dragMove) {
        let x;
        if (e.type === 'touchmove') {

          x = e.touches[0].pageX;
        } else {
          x = e.x;
        }
        let rect = this.$refs.mutter.getBoundingClientRect()
        let left = x - rect.left
        if (left < 0) {
          left = 0
        } else if (rect.right - x < 0) {
          left = this.endLeft
        } else {
          left = left - this.mouseLeft
          if (left < 0) {
            left = 0
          } else if (left > this.endLeft) {
            left = this.endLeft
          }
        }
        this.childLeft = left
        this.mutter.scrollLeft = left / this.endLeft * this.scrollMoveWidth;
      }
    },
    onDragScroll(e) {
      this.dragMove = true;
      let rect = this.$refs.kind.getBoundingClientRect()
      if (e.type === 'touchstart') {
        this.mouseLeft = e.touches[0].pageX - rect.left
      } else {
        this.mouseLeft = e.x - rect.left
      }
    },
    setEndLeft(e) {
      this.endLeft = e
    },
    setKindWidth(w) {
      this.childWidth = w;
    },
    setKindLeft(l) {
      this.childLeft = l;
    },
    setScrollMoveWidth(w) {
      this.scrollMoveWidth = w
    },
    setMutter(m) {
      /*unmounted 需要排泄，暂时不规范，之后我改一下传参方法。*/
      this.mutter = m;
      this.mutter.parentElement.addEventListener('wheel', (e) => {
        e = e || window.event
        this.mutter.scrollLeft = this.mutter.scrollLeft + e.deltaY;
        //deltaY
        if (e.preventDefault) {
          e.preventDefault()
        }
        e.returnValue = false
      }, {
        passive: false,
      })
    }
  }
}
</script>

<style scoped>

</style>