import scroll from '@/components/scroll'
import createLoadingLikeDirective from '@/assets/js/create-loading-like-directive'

const loadingDirective = createLoadingLikeDirective(scroll)

export default loadingDirective