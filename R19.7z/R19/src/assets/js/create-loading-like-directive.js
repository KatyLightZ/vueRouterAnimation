import {createApp} from 'vue'
// eslint-disable-next-line no-unused-vars
import {addClass, removeClass} from '@/assets/js/dom'


const relativeCls = 'g-relative'

export default function createLoadingLikeDirective(Comp) {
    return {
        mounted(el, binding) {
            console.dir(el, binding)
            const app = createApp(Comp)
            console.log(app)
            console.log(binding.value)
            const instance = app.mount(document.createElement('div'))
            const name = Comp.name
            if (!el[name]) {
                el[name] = {}
            }
            el[name].instance = instance
            console.log(el[name])
            console.log(binding.arg)
            console.log(this)
            // const title = binding.arg
            // if (typeof title !== 'undefined') {
            //     instance.setTitle(title)
            // }
            append(el, binding)
            console.log('我被挂在了 1212')
        },
        // eslint-disable-next-line no-unused-vars
        updated(el, binding) {
            // eslint-disable-next-line no-unused-vars
            const title = binding.arg
            // eslint-disable-next-line no-unused-vars
            const name = Comp.name
            scrollMoveAutoSet(el)
            // if (typeof title !== 'undefined') {
            //     el[name].instance.setTitle(title)
            // }
            // if (binding.value !== binding.oldValue) {
            //     console.log(binding.value)
            //     binding.value ? append(el) : remove(el)
            // }
        },

        unmounted(el) {
            console.log('delete')
            deleteMove(el);
        }
    }

    function deleteMove(el) {
        if (el.target.moveSet) {
            el.target.removeEventListener('scroll', el.target.moveSet)
        }
    }

    function scrollMoveAutoSet(el) {
        const name = Comp.name
        console.log('scrollMoveAutoSet')

        const clientWidth = el.target.clientWidth;
        const scrollWidth = el.target.scrollWidth;
        const scrollMoveWidth = scrollWidth - clientWidth;
        const scrollBarWidth = clientWidth * clientWidth / scrollWidth;
        const scrollBarMoveWidth = clientWidth - scrollBarWidth;
        console.log(`
            空间宽度${clientWidth};
            内容宽度${scrollWidth};
            可移动宽度${scrollMoveWidth};
            滚动条宽度${scrollBarWidth};
            滚动条可移动宽度${scrollBarMoveWidth};
        `)
        console.log('scrollMoveWidth', scrollMoveWidth)
        const ID = Math.random();
        el[name].instance.setKindWidth(scrollBarWidth);
        el[name].instance.setEndLeft(scrollBarMoveWidth);
        el[name].instance.setScrollMoveWidth(scrollMoveWidth);
        if (el.target.moveSet) {
            el.target.removeEventListener('scroll', el.target.moveSet)
        }
        el.target.moveSet = (e) => {
            let c = e.target.scrollLeft / scrollMoveWidth * scrollBarMoveWidth;
            el[name].instance.setKindLeft(c);
            console.log(ID)
        }
        el.target.addEventListener('scroll', el.target.moveSet)
    }

    function append(el, binding) {
        const name = Comp.name
        const style = getComputedStyle(el)
        console.log(style.position)
        if (['absolute', 'fixed', 'relative', 'sticky'].indexOf(style.position) === -1) {
            el.style.position = 'relative'
        }
        el.appendChild(el[name].instance.$el)


        if (binding.value.child) {
            el.target = el.children[0];
        } else {
            el.target = el;
        }
        el[name].instance.setMutter(el.target);
        scrollMoveAutoSet(el)

    }

    // eslint-disable-next-line no-unused-vars
    function remove(el) {
        const name = Comp.name
        removeClass(el, relativeCls)
        el.removeChild(el[name].instance.$el)
    }
}