<template>
  <div class="page-m" style="padding: 0">
    <div style="height: 100%;width: 100%;background-image: url('https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7');
background-size:cover;
 background-position: center;
background-attachment: fixed;
display: grid;
align-items: center;
place-items: center;
">
      <div class="card blank  ">
        此处如果在最前面，最好是铺满，否则会导致没有滚动的时候是缩放图片
        <div  class="form-info error show">
        </div>
      </div>
    </div>
    <div class="card blank  ">
      卡片胶囊预留方案
    </div>
    <div class="card pill">
<div class="row-flex">
  <img class="user-avatar cir" alt=""
       src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
  <div class=" row-f1   row-space-left">
    <div class="card-title">card-desc</div>
    <div class="card-desc short">card-desc</div>
  </div>
</div>
    </div>
    <div class="card blank  ">
      此处经常是更多推荐的案例
    </div>
    <div class="card-box horizontal tight ">
      <div class="card-cube-5-3 card-cube">
        <img class="full-ab-mask" alt=""
             src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>
      <div class="card-cube-5-3 card-cube">
        <img class="full-ab-mask" alt=""
             src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>
      <div class="card-cube-5-3 card-cube">
        <img class="full-ab-mask" alt=""
             src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>
      <div class="card-cube-5-3 card-cube">
        <img class="full-ab-mask" alt=""
             src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>
      <div class="card-cube-5-3 card-cube">
        <img class="full-ab-mask" alt=""
             src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>

    </div>
    <div class="card blank  ">
      此处经常是更多推荐的案例
    </div>
    <div class="card-list">
      <div class="card">
        <div class="card-title">#你的推荐#</div>
        <div class="card-desc">你的推荐 你的推荐 你的推荐 你的推荐</div>
      </div>
      <div class="card">
        <div class="card-title">#你的推荐#</div>
        <div class="card-desc">你的推荐 你的推荐 你的推荐 你的推荐</div>
      </div>
      <div class="card">
        <div class="card-title">#你的推荐#</div>
        <div class="card-desc">你的推荐 你的推荐 你的推荐 你的推荐</div>
      </div>
      <div class="card">
        <div class="card-title">#你的推荐#</div>
        <div class="card-desc">你的推荐 你的推荐 你的推荐 你的推荐</div>
      </div>
      <div class="card ">
        <div class="card-title">你可能认识</div>
        <div class="card-box tight horizontal">
          <div class="card inline">
            <div class="row-flex">
              <div class="row-space-right">
                <img class="user-avatar small cir" alt=""
                     src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-align-middle row-flex  ">
                <span class="middle-auto">Cascada</span>
              </div>
              <div class="row-align-middle row-flex row-space-left">
                <button class="button cir auto small love">+</button>
              </div>
            </div>
          </div>
          <div class="card inline">
            <div class="row-flex">
              <div class="row-space-right">
                <img class="user-avatar small cir" alt=""
                     src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-align-middle row-flex  ">
                <span class="middle-auto">Cascada</span>
              </div>
              <div class="row-align-middle row-flex row-space-left">
                <button class="button cir auto small love">+</button>
              </div>
            </div>
          </div>
          <div class="card inline">
            <div class="row-flex">
              <div class="row-space-right">
                <img class="user-avatar small cir" alt=""
                     src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-align-middle row-flex  ">
                <span class="middle-auto">Cascada</span>
              </div>
              <div class="row-align-middle row-flex row-space-left">
                <button class="button cir auto small love">+</button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <div class="card blank  ">
      一个较为有趣的效果
    </div>
    <div class="card full">
      <div class="card-cover-box">
        <div>
          <div class="card-cover-image" style="background-image: url('https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7');
background-size:cover;
 background-position: center;
background-attachment: fixed;"></div>
        </div>
        <div class="full-ab-mask  grid-item-center">
          <div style="margin: auto;color: white;font-size: 36px;font-weight: bolder">从你的上一步开始：</div>
        </div>
      </div>
    </div>
    <div class="card blank  ">
      此处适合照片墙，打算用这种grid取代之前用的display inline block 的宫格方法
    </div>
    <div class="card-gird l3">

      <div class="card">
        <div class="card-cube-box">
          <img class="full-ab-mask" alt=""
               src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
      </div>
      <div class="card">
        <div class="card-cube-box">
          <img class="full-ab-mask" alt=""
               src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
      </div>

      <div class="card full">
        <div class="card-cube-box  ">
          <div class="full-ab-mask">
            <div class="card-gird l2 full">
              <div class="card">
                <div class="card-cube-box">
                  <img class="full-ab-mask" alt=""
                       src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
                </div>
              </div>
              <div class="card">
                <div class="card-cube-box">
                  <img class="full-ab-mask" alt=""
                       src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
                </div>
              </div>
              <div class="card">
                <div class="card-cube-box">
                  <img class="full-ab-mask" alt=""
                       src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
                </div>
              </div>
              <div class="card full">
                <div class="card-cube-box  ">
                  <div class="full-ab-mask">
                    <div class="card-gird l2 full">
                      <div class="card">
                        <div class="card-cube-box">
                          <img class="full-ab-mask" alt=""
                               src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
                        </div>
                      </div>
                      <div class="card">
                        <div class="card-cube-box">
                          <img class="full-ab-mask" alt=""
                               src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
                        </div>
                      </div>
                      <div class="card">
                        <div class="card-cube-box">
                          <img class="full-ab-mask" alt=""
                               src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
                        </div>
                      </div>
                      <div class="card">
                        <div class="card-cube-box">
                          <img class="full-ab-mask" alt=""
                               src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card ">
        <div class="card-cube-box">
          <img class="full-ab-mask" alt=""
               src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div class="card-title">card title</div>
        <div class="card-info">card title</div>
        <div class="row-flex">
          <div class=" row-align-middle">
            <span class="middle-auto">sale +111</span>
          </div>
          <div class="row-f1"></div>
          <div class="row-align-middle">
            <button class="button auto cir love small">+</button>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-cube-box">
          <img class="full-ab-mask" alt=""
               src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div class="card-title">card title</div>
        <div class="card-info">card title</div>
        <div class="row-flex">
          <div class=" row-align-middle">
            <span class="middle-auto">sale +111</span>
          </div>
          <div class="row-f1"></div>
          <div class="row-align-middle">
            <button class="button auto cir love small">+</button>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-title">st test test test test test test test te</div>
        <div class="card-desc more-must">
          test test test test test test test test test test test test test test test test test test test test test test
          test test test test test test test test test test
          test test test test test test test test test test test test test test test test test test test test test test
          test test test test test test test test test test
        </div>
        <div class="card-info">author</div>
      </div>
    </div>

    <div class="card full">
      <div class="card-cover-box">
        <div>
          <div class="card-cover-image" style="background-image: url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCAC9AR4DASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAABQYDBAcCAQAI/8QAQBAAAgEDAwEGBAQEAwgCAwEAAQIDAAQRBRIhMQYTIkFRYRRxgZEjMkKhBxWxwVJicjNDgpLR4fDxJFMlVLJz/8QAGwEAAgMBAQEAAAAAAAAAAAAAAwQAAQIFBgf/xAApEQACAgEEAQQCAwADAAAAAAAAAQIRAwQSITFBBRMiUTJhI3GxFIHw/9oADAMBAAIRAxEAPwBmGckZ9aynthbbdSmmXOGwW+fStYA5+tZ52qWN727hPUxhl+dJN7WmN4FbaFrQLoWl/by8cMB9+K14XEc8SFjw6Ajn2rEIWMcoz1Df0rRYtZtbXTbV5WO7aAAvXOM1WThna08fcxqvAE7UpsmRQcb2Jx7Uy/w+JC3y5/w4pRdrrX9VtkVTmeeOCJfTccZp70fT/wCQ67NppbPe2sUwPrkkf2oceKC6uN4Z32/8Q4jNdDPqa+FdDyps8seDPqa659a84qOSQIDmoUeyzd2hOegzSR2j1WZY3jRxubPTk49aO394ArDeBweM0kX8ltLI259xJPsKBKdukYlL6Ey5E8srM2SScmoe4b3pkeCBsiNMsfQf3qlJaXPlH+xoqmuiKQKWIg5xU7TSBNoUD51b7iVPzxn7VFIqEHjBq7sm4HbC7596ZNLlt4QN/B9aBFQpyKsRSeRNSS3KiSTa4HEyrNHgEMvqOooTOogcneDkjK+dVILqSI+B+PSmrsx2bbtHML69QrpNvLtYcq19Kh5iU/4B+s+fQeZAFBpgo8uj3QOysuvql5JvtdP3Y74D8S42nB+HB4x5bjx6ZxWm6Zpun6VAtrYQ91Hku3iZnkc9XdnOSauIiRIioqqqKqoqABVUcAKBxgeVepgFj9yetHUVEZUaOydoJJ6etDZNSaObuiOTkqUO5QB/iPl9qvsUwWfaEHOW/wC9Urq3in4KFeQQ4GG49POpO/BuNeSxDeQyZBYblXLZIGAOpPkB8zUy3FtJkJNG2ODsYMAfTI4pcNhtkjB8canJUhmG9TkHbgj70bgOVCq7ZA/KXOVH+hlH9KzDJJ8MkopdFe/0PRdUliubmBWuoVKRXETlJUU/pypwR7EGqMmj3UCFVkE8YyAcbZAv+YDg/Sj2DxwD7kYP3FdZ6A8H0P8AaryYo5FySM3DoxHthoJBa5jB55PnSF3W0YPUda/SetaHFqdtOsRjiuXXguCYnPpIBzz6jnz8qwbWNJvdOvZYJ4WjJZymeQQpwQDgdPP/AL1jFGWP4vomSSlyCra3eVsD1ozDpmV8RqrARbjJFey6nMCQhwKJK30B3fRcGlsrgpRFNMkePkE8c0GttRm3KS5OPU8UyWusxgAORgjnpQZ70Ycn5FW9spLSUsAeDke1d/zu6CKm44XGPpxRTX7q0njLREbvPFKBbk0WMVkVyQXHJpH6CA5NZ52qwmrKccGJc/eqa9pe0gbd3wI64xxmh2pane6hcxy3GAwwvFBfyOnDTZMT3MEXsfdXD4Bwx3Ci+nXEN3bNZykbwPAT/aotWs3KQzx+Ndg3Y8vnQaGR4nVlJBByCK3SyQ/Y1p870+XnpjpoDnStYsbmeMsLeRnAxw2VK5U/WjcmuC87VG+K7IysVsi56IgxyfnmgGn6xb3Sxw3aovdrhWzjJ8yDUJbEklzG4Ajfcp9cc0o3KPB6mOPBqIub720bPGwZVI8xXdCtBunvNMtJ3yC6DrRCWUIDk9KfTtWfPckdknH6PXkCg80ra7rkdkjBXG8jgVxruvLZxuEbx4PmKzO81Ce/md5CTk9PKsNuXCBF691+6mLeM8+/Ffafb3eoycNyeSWPAFB3t3OCKs29/c6cpKcNjir20vj2S0OkFhbWQBmcNgckkAVcivtDJCExn7H+tZpda5qF0T3kjY88GoFvZBg7jn5mh/8AHk+WyVZsaafpN6uUCZI8sUqa72emhZ3gTjnGBQPSu0d1auoLkr86a07U206hZlJPqMEYrOycHwZfAjSwzx5DoeKq5bJxmm+9awvTuiGCfbGaGnTQT5cmjRnxyV7iXDK2iafc6xqdjp0Qb8eQGZlJXu4F5kfd8unzr9CWlvb2dvbWtvGscFvEkUSJwFRBgAUidg9HjtI73UXX8WdhbQ8DwxIckj5n+lPLP0A9OfkK0peQyVqyVpMnHrwP+9dxndyegz18/eqq5bPv/wDyOp+tW04UY8/6eQqk7ZpqjvGcE84ORXxCnrioZpdgAHU5x9OteJI3HJrW5XRNjas8lhRiSpHPPyPrUaJbz4juEjMiZKnBVwemVPX7GrYyRzmo5YN3Izkcj2IqNeUS/DOlR4eAxdPRz4l+tS8MP7Go4nLDa35x19/eop5mtvGRujPUAeIVq0lZmndFjoPYe/SlntV2dt9XtZp4oyb2NN4EYBacIOMA8bh5Hz6fJkWRJI1kQhkZQy48weajDBHCZ4Yb058vaqbKq+D8034eGeaFsZjkZeOhHkR7HyoczHn50/fxK0SPTtXjvLdFS21NHn2r0SdGxKACehyG/wCL24RjCNhbNa6KoijcqetWPiDjr+9USSDXp3EVqiNEkk8jcFjj3rgc5rkDnmrCKtQgfQjGAKhnTpnqTVqMKgAHJrh13N6n+lc1vng9xjxbofIKaUtu4WKYju5Iyh3eRNK+sae+n3k0ePwyxaJvIqeaLhZV2gEgE5GDjBq3dJHqtoIJcLcxD8Nj1NSE9kr8Cms0u6NwXQpRSMvnRPTbe91S7gsoAxMrL3hGcBAeSagt9G1Se8js44SZXbbn9IHqa2Ds32ctNBtgxAe7kUGWU9cnyFNNRl0cd6meKG0NWkEdjZ29uvAhjCfUCget6xFaI+W8XOBx6Vd1TUI7WJ2ZgMA4zWVazqMl3NIxfCkmo1fBym/sr6pqMl3IxZiQSaGKWU5FctMi+5qIzM35RRVGii6Ljb1rppEnUg4z5UMYSV2m8etXRODmaBlJIHGar8ijVvEkmBJ5+tfXWmsx/DXJ68VN6XDJaBCOUYGj9pLavENxAYY86ESadexjJibHyNQjvouoYfSo6l0y+xnjuURuGBFTreZZAuSSwAAGSSTgAClVLhwetNfYqzbVdds94DW1gDfXG7oSnEa/VsH6ViUaVsF7W5mx6TA1pp9jbt+dIFMnAGHIyRx6VcQko7HPiYgfIVCXxGSPNeOPWp4hnu48ZwoLfXmgp80ObaRIBhUH6pCFHsKtLySB0U7R9KrAjfJKfyxKdvuQPKpmbu7eRjxsjY/8WM0VccmXyVXKySsf0r4Rn29qsR+VUInzj0zRCMZAoWP5Ow01tVE4/wCldVyo/tXdNoVZDICpDjy6146pNGyMMq4qVgCMVWRijlD0zkf0NYlwbXPIM026eC9utJuGJdV7+0ckfixZ5H+oef3onMm5SQfFG29D7eYpf7TE2L6Zq6dbK8t+9IHWB22uCfTBNMZI3gg5VkyPQ4IIP2NL47VwfgPliuJryKvbzSBq/Zy7kiXN3poOoWxGNzCNfxU9eVyfmorAVlfBX6V+nbrf8DqaRrukFndCNem5u6YKM1+bJYkBJC7c84GePvzR4u+xSTplErzk1Kuzbg4zXkq4NSWyIxw3NbbKIHHpXAZqv3EaIvlQ8YyatOyxmguYZlAiYBsflPXNdgMGG8YoHPb3VjO0citHIh5zkfarCajMQFk5x0PnSUsXmJ63D6gn8cvDGaKEzINuMjnHnVyPSXnQyIxEsfOB54pZ0nUriO/TvDmFshgemK0S1aMqtxERtOCQKHKFcMahqvcg5xX6JOzyW3fneALmNdpJHOPnTFd3CRRu7HAAqr/Kre6tU1LTTi8iG50B4kxy0bD19P8AvSd2m7QgWojRiJGG1x0IPmDW8MXBbWea10VKbyQ6/wAA/aPX++leON/CpYcHik+W4ZyeetRSySSOzMSSSTzXiqTinVGjmnmSTRK2ji2crk4qmsL8cGjVjHbxrmVvLgDqazN8cFFJ4pCfAnFSQW0rHmMmr8s0bZCLtX96pyXfdnCsflyKGm30VQRW1KR5YKvt515EsokzGpyPbNUIbwuwB3EH1NMVpfWNvDuaPLgfSsSuJVUV59RiSNYpUXIHl1oVI9lODjAPPWo9Su0uJWKLgEmqaRux4FbhGuTVI4ltV3Er+1aT/DWx7iy1S+Oe8u7lbZeP93AOcE+pY5/00hx2z5HU+ta92ctjp+jWMG45SESN6d5Ke9bGeerGqyzpUFwq5DA3RRjqQMfUD/rVi3bPxL+h2L9OKqOxVoc9dpf/AJVz8+pFXLb/AGQHGSwLfPGaFF8h5LgkyARD1cxiUj2Eij/z5V7fN/8AH29A7gH5A5/tQ+4uhBqUTPnYTa2anjkylift1q7qGe5hI/TIQfrWnL4yKjH5RIYlRVXOAB1q5HcR48Ks2D1xgfvVGWO7a3c26hpApKoTjccdAax/tL2j7XwXr2c0dzYbdxjSfwb0x1BB2EenNTHa4SCTUXzJm1Tana2/M5KjzKEOR81U7v2qa1v7C9jMtpcQzxglWaJw21h5MByDWK6Tpvb7X9kEN/GgEE05+IH4AEbRhB3kKsPHkleP0t6U1dk7DUIEv3u7V4NY0+Zra8UE/iJ+ZWOOCCOVPII5B9CSlOHLBxhjnwnyaRkGql2SmyVf0MN/+k8Gu7djJCr8+IDApI7TdubXSjcWlrGbm8COxCAOIkUcvIoBwvz/APdzlcePJmMaf9DPrMCX+mXlrkZuraSOJs8CXB2ffyqbTZZJdO0qSTiRrK3MoPUP3QDD71madttOn0Wxtry9vI774a6NwkS7NzO7d0G8OCMbSMetaBpVyp03Tfxe8YWsEbvuDFpTGpOSPP1pe2p21XAWUU8dJhJWG6UZ4YlD8mGK/PWq2c1te38WOIrmZBtBAwHOMCt2u5+6tpH3YLFgpHUEAnP7Ujala6dI8s7smZMvzjqeta37RPNSZljQytxsNRL3iNwcU9ta6a+5Q6An0xQq80iIKXjOSCc/KirKn2B3oW52JUEkmqlX7mFkDDHAqhR4m49Gy9pOzdvqkLyxKFukBKkD82PKsmuIJbeWSGRSrxsVYe4rfWO1ZG8lVmP0GaxHWZhNqV+/GDM+MexxS0XTo6OF701IHxyMpHPI6U6dntZjCfDzHA9SaScZ5HlUsErROrA/OqnG+V2dXS53jeyf4s2LT9SaxlbupkNvPwysRjPkRSn2j0K4nSe+i/EiLNIWXnG45JoTDcyFFw7bTg9ac9Ns9disU7yLvdOu1JypLtCSOCV64NKLI26rlHczaHHHG5blUjJniKnGOQSD86tWtszNlhha0cfw8mvIprmGVYpcloo5BlGHofMUo31nc2E01pPE0UsXDhvP0IPoaeWS1R4PPjeObj9FKbukASMAt0JrmGJyw68+p4qNdobcx4HrUvxKLwOBUA2FreK3AAIDv7/lFVr2ziYs3hXHkuDUNn8bfymK1jd8YDMvCrzjBP8A0BPtTpadjtfaHvBaqvhLGW/kNnAmFzkghrk/8sdYpplqLEiGwDEMQUjUjMkjLGg/4pCBRMWWjbF77UkQMMqFjmkDc7fCyptP0NNll/DqC4dJdU7Q2jyOFkaCxjjkxxkgPM7HA4520xnsT2XMEO+e6kMTFlmHds/pjBQjHsBW2mzWz7ZncWkdm1JM18/HTagL59Chbr88VO+ndnBHmO9t48HaTcSZc54yI4zn9qcZuxXYcSJJLeX8YmZlVBKIotyjONojHP8AWh11/Dzsve5+C1l4WCo0Y7m2ZGUjO5gNjH3Of6Viv2X7aFyws9Glv7e0S4uJ2kmWMbIXSMkeLBLkH58VoLtttoAPEZplUKOPBu45P0oFo/ZGLQrh70ahFej4Z4oe5jkj/GduXIdiMYwBz60xXqKsumQpkqhti3XnDglsfagZexnCkui2fFdyLg7UQqf2Of6UQt8njqO8bp6Lgf2NDbRhJc6g+chGkA65BLnI/aitqDtQkYPOcepya3iV8knxwLHamb4SGCTOJO9mnTB5Z1GE+maOWN/BqljaOCM3UIliz/8AZHxJGfcHNLHbhkM+n2oA3zomcj9KF3AB+ZB+gqppPx1mGgJZrZ271QrYaCUHIkjPkfX1oMp+3Np+RyGH3cSa7RocPHhYYI4I96rapoej61CIdQtUmVTlGIxIh9VYc1HZXEkqp3p3MBjdjGfmBRZSDinsbUlwIZYyg+RQj/h72XiZzH8eiMiJ3UV5PHHhSzZIRgD18/78slpYWOnwiC0gSKMKqnaPE20YG9jyfqauZA/aomkBOFGcdaK6QK2z6JQqsoGBk4pG7S9jru+PxelywG5EfctDexRNEyDfjY6IGB8TA5Jzn2p8Tpn1rwFSSMeZrNF3zyZFd9kO1Ovahpi6rZ6ZYafptqlnGdM3Am3hGEQNIWkJ4GMnj68uWk6WumQWdtGGVIopdiuxcqu845PNM8wVVJx5VEYkZoGI6oE49yKDkg5PlhYz2x4Qidptajt7u609DhrO0jdyeveSQvKT9AVrMbzWJpCRvOM8jNSdp9Smn1rtJKSwNxqFxGoPUQxSFFGD7BftS27Fjk1uOLm2LSVhQaky85Oc+tXI9adl2Mcg8Uu18M+VF2IxsQwTGOaJ8YyeaAuu1mHvU8M0owOfrUzxiUhvOqXxNJUbhfyiGyvZM9InA+ZGKxW5id5JH5JZyx+pzWk6tqne6fPHjDScEe1KsNl3oHAPFc/3knZ6KPp2TCnHIuRV5Q4PSusDqOlFdS014cuF8NB1JGVJx86ajJTVoVT2S2TCljKR+Gx4PT2NO/Z/tXfaUYbWcG4sdwAQ/wC0iB/+tvT2NZ5E+0jyowl7aBF3viQDgAZ8Q6bieP60rOMlLdE9Lps2HLh9nPyjZbHtVpt7qsWnwo697Czoz8BmXkrigf8AEfSxLaRalDHmS2JExHnE3mx9qQez+ozjtBpUoU5FwEy3JCv4T14rcrmK2vbaS3nUPHMhRkYZ3AjmjRlKXEuzzXqGDDjmvZ6Z+a447y7njgtopJriVtsUUCNJI5/yqma0bQP4Xzzd1cdoZ2hQlW+BtWBlZeDiaYcD3A+9P+h9m9F0NZF0y1SF5f8Ab3BJe5kBOdveNyB7DH96PKEUAKKZRydtFCw0rTNMhS30+yhtokXaO5UBsf5nPiP3qrrGkRajbSRSxtKrlMh3zjxAE4Y46Zo1k1FM8gjlKfmCNj54OKqUU1TNRbT4FfTNLv8AR2te5WE27RLFPE8aoyMq8NC0Yxz+rPzo0ZnUOdhwQPThicc1fBJRQQCcAny5qOWK3lGHG1mI9OT9eKGse1fFhHO3yQSd3KrRkIVZcbTzkY59P60ldorS702G71C2N1dhldd9wqO1ojrsYjA3YHr15+tOzW8kCuYmIwWZcDcATyeGzSvrd7PcyWumvCpE89s0jITjuBJmQsvsB+4oOTj8gkOeifSo5vgdKjuMPJIglkIACYbG0bBwOMcYrq5w2owM2R+OIlBPGI1d2/tRG3CmZOMKO8frgYUYGP3NC7lf/kW0gyG7jULgtjjLCOJfuSaFPo3Ds702UBL52x4nXJHu5PT70bsmPdQ+56fIZINLUTLHp9wAcF76K1TkglzjOD1/90x2pHdQHI8TOR8ifKrwy8EyryJPbc41/RwTx8Msg54wJApP7UUtURguPKgP8Qpe513RJyPALGMHJ8jPMpH2Jx/2o1pMoZAc5GAfXyrGpj87GtO7xceArBI0b45x86Lx3UeB4h96FFV3q3k3FWzbnYXVGfahKxoVQytjhSx6Ct4XKPCB5tslbLqzGY4Q+EcM3l8hVC51C6sZbgNp95cRna0L2iI4YMB4WLMMEc5z/wBhxa61ZDdDPa6lazRYDxy6fc7FzwNskKvGR7hqvDUdNfKCYbiCQGUo2Pk+DTfa75F1Fxf42ijZdo9PnSZps2hidlaO7ZEkGDjopOfbGauLfRSPGUDBZE3KWUrkZIBweaGyW3ZqOYXEstmsved7ulkjU7vXLGpJ3jk5t2WRVfaGjIZMEc4Ycce1Bc5pcsK8cHLhNFjUdStrO0u7qdwsVtBJNIx8lUcD6nAFS292jXVtbnjdYR3UQ8nBYqxHy4+/vSVrKDULTVtPlmJZobZUjUnPe3E4jgyPmC30FNi2LwzdmQsmXs47iJ2OcvCYVUjk56hT1qQyOfJMmOMVX/ujCe2lhd2XaftDFMuO9vZryDb+UwXLGZCv3wfcGlsqw6itm/iRpL3WoadeouR8AYGwv/1zMwyf+KsxntlRirLtx6im96ujmXzQKVSR0r5vDiiLxwqnhxnHNDny7YAq07LO45UHBFd99gnbg+tQNGy9eteKcE1dIs0zVwBCvuR/WvdOiDKPpUesuAsS+rAVa0xhsX6V5+R9E9Qbcq/RPe6Yk9u67ckg81nGp2UlpM6kHGTgkVsVuquADzxSz2p0dXUyKBkgkECmMGTY+TzGaHuceTNkkIUjzzjJ8lPBqQLIcAMOenGK7a2kQuNvCnxE8ADOMkmr1vBLaqJTGO9kXckkoOYYxyZEV+ATwASM+mM5rpuSfKOdc48MM9ldOu5dUtcoSYyssrMNsiRgZxuY+HPHvz5Vt9qjlIwcbiBnbnA48s+Q8qQeyEDrbxTyKmxvDHGu7xySHqSRzx1J6lj6cPzTx2UKd4wa4mfu0Cj88rc8D0A/p70CDTblILnbdRiXNyoNq9R19TXa1ThYtgnknzxVtTR4ysUlHad1FJyMe/Py9Klrll61p9GEyPd9P7/KuHcFSD0PNSbAKrTeHkY54PyobbSCpJkEl/JaxySGNp40DMyxlRKAP8O4gH6kfOhE13oupS2d1aMpdnKsGDRSoWCnbIh8/P8A91LfRyYfu/05dceufQmlWzZoZAWUxzzS6hrNwPCT8MuLaAHPQNjf9fpSbySdp9DHtxStdjjaSq00oH/68+0+YAbaB+wri4ixHLJjJWBE444MhZs+XkKD2V6o1W0i3DDJNGpJ5bvgHIU+o8P3o7etjTrtwf8AKCf9QU/3q4vdF2VKLi0AJH22mgxtjM15JdMc8fh7ipP2FG7ecBbIZ4JUHHp3hXJwfal+/wALb9niMeFN/PHk5YY9eldw3W1rRd3lH+Y4/PNIQRSym4yGHDdEE/xMi76x0W+QeOMyQMR/hYkgN9Qao9kdaSVIoJGG9QF5PPGOpo32oMV9oMi5CiDUJ7R2P5UMjK8bHPlkj6Z+uRwT3Vhcb0ykkUhVl5GGU4IYdc044+9C/ILFL25U+mfoqNEdVxjyNEIgVArO+y/bG2u0jt7pwk6gLhv1eXFaFDNHIqspBU46e9axNdPsrPFrnwdsC3IJ49KgmeORHiuLdZo2BVxIiOpU8EMGq6oU16yIfIfamab6FFNLsDyWmm3ChPgLMoAEw9tCQFHAGCvSq17dQWwWLckUKmKEHhQC5CKi+5zgUZkRVBI4oE2n3dxqcd5LhoLeBzZQbM//AC23Bp5cgngYCdMcn9XC+RPoaxyT5YBtdE/m19q10txPBf22qW6uzMWtJGsWVkTuv8O3Azn38uXtIxLNHK4YPbK6AAnaWkCluvUcDFUdK0yS1DSuZFlm3SzqxDfjytvkbI9T0ovwBzWsMKVsHqMu50hO7V3kyXMcQgaSCCHLsoyd8h3EY9AAPvWe37aVebtu1ZOf8rA/I1ptw4lnnZ1DB3Ygew4AoHqPZnSNR3Ps7qbyePg/WguXybGZenKUE0+TJruzMZODlfUVxDZNgvjpz06033nZDWbct3W25h9B4X4+fFUkWOzbubqJkJ4YOMEfejrLxwc7LhnidSQo3ZJcLtwRxUSQseTTXf6Mkim4t+VPPFAJY5Ym2lTx7UaE0+EB3Gi6jpjXYXu5NrocgNyp+3NeWkE9tiOVcEY5HIPyNElbk5rvGRx9vWuM4buj6fqMCy/2XbMcA+WK41TxxMjIHU/pzjn/ACkcg19aXMcbrHKAqscLIfygk9G9KZ10K1mKPcStIMBgsR2ocjru61vFhnNUjyeqi9Lk/kMgvIbS3m2osz3Ab8oVHO4/piQDJPvj/rTpp3Za6urOITWXdZIfN4cMWKjxvHySR5Z9KerPStKsM/B2kETH80iqDK3+qRst+9TXEpijJUKZXIjhVjgPI35R/c+wp6OmpfJiD1zTagu/sB2ummylTc4KwRbYUHk78Fz7mqF0Z/54wlk3pHbJJEq8LFv8JUep6kn39qMMHRJi7lmijaSR+jPJwM49zQi+kjGsmJNu62tbeCUj/GcynGP9VDzJRhf7N6ZuWT/ph23JKrk+VXkPH2qja8ovyq8tHxdITy9kgr6vq9o4ucNiqk3Ix5e1W36CqkpGCc0HIGxg+ZzjuwCSw2DJH6vCM/tSdr8UZl1q5IysFtYwoQWzneMYIOMYDce5p0Y8u2Blcsuf8eMAilPX4Yv5ZdTd5zcamsHBwNsETRMOTzgs1KPkbTFAapKlxoku8968EMrFich0drbI8uQo+9aP8X8T2dnuHPL3JDnGODNhj8uayRz3kvZYcDKSQ8nAAFwrgcelahuC9m7yEcnZdOvQcrMqjH14rFbXx5Rv8lz4aKN06z6fospIBgmCSEnkDBjPPTzz9KGRzuZ1VuAkajw+TRTHOfvmpdLKalpVxbb1xcLMtuWJG2cqJEz58A4NDopJJlN14RIyst1GCfwrpcLNG4+eGHqGFLzi6sYg10X9RnhksO2NvIAY1uNOuCMdBPbCNiPqOazWctPulJJuIxick8yovAlz6+T/ACz5nDdqN2Ei1/ceLi2slwDkEgBR/WkTvJFIIOGXoRT2l/EVz1FokWZ42V0cqynIK8EH5069nf4gXFgY7e/y8GQO8GTge4HNITuGOcAHzA6fSo6beKMuxVZ5R4XR+mdM7QaXqMSS21xHIrAfkYEg+hA5ombuDH51zjpmvzdoNlfXl0iWryqzkLmJnU4GMnwmts0Ps2lrBE95c31xMQGKzXUzRDzAC5pdzlGWyLsY9vHKHuPgZEIuSccxg+I+RPpVsKo6ACuE2IgVVChRgAAAAewFcPOiAknAAOeeAAM0wqirYm7k+CYsAKHTX4GNmBCZO5kuGbChjnKxgck+/Qe+MUIvdae5nhsrEblkYCefoNnmqfP1r3W4dQbTIIbHTPjnM/eGMTiAxBB4WRiQOckdaC8u+1E2se2txRjsdR0kw2s8z3tmxf4K8YZn2DDCG6I4LgZ2sOoHrVxTnyHNVbW71TS0jttdt2Gn3EqW8NyXRjESoKd6VPDeXzX0OKKyQtFwdrjqHAHiU9G/60Bq3Z1dPqbWyZWyapX+madqKFLqFG64bHI+o5ogfpXJFVtHeH2L8XZ2K1V1tpmZDx3cp3DHsetAr3s7mUloW5P6RkftTyf715u9eazynwKZPTseTmPArZ967WQrjP0rnFfYHTBwfvS1s97w+yzuRhg+f9aMaVql3aju1Pewr/uXPT//ADY9Pl0pe5HI/wDYr5Lh42DL5HkUWGVwdoT1GijqIOElaNMtbu3u4+8ibpgOjYDxn0cV9MR3sJP5YleVhj18IOfbn70gR6jPbyLc2smyXjqMqwHVJB5imbTtesdWkjtCTBfS2s5eBs7cxsmWjfzBzkeeAeOK6WPNHJw+zxGu9Ky6X+SKuP8An9l5UJVnySPB3hU85wHyePlSQbmRu0Ouh8k/zS4RRkcIixoP2FNdvqAg0ztBN3Z7zTGvleNiOZLdMAfXAI/1VnFjeTz6nqc1xt7w6jKzbT4cPHGwZfY9frS+sX8fBfpa3ZWn9M1K0I7tfkKvqc0HsJA0afIH9qKqeBW8MrjYnqIuMmifivq4zXWaZTFGjiQ+E0Ie5VjMpZRsfu2IOcE8+VE5yAjHpgdaQPiX/nWro0hYC5iCA8qgSFRgDp1zSOqybKHtLi32MlxOiopJxGiSFs8ElRkHNKvaSVI9P7Oo5/EmWW42EjmW4dWLN9WUH5GiGtXEo01oYsGS8ljtVzngznZwB88/SgHaNhd9odMtYmBSytoYZBxjdlp5Dj2LKvT9PtQscrTkzc41SF20te81XQYlOY7OINk9dscQfOPpk/OtAOf5NeZ6xwXMh55ADSS/LPAoBaWSxS69cgFRaWkqErjCd7MkKqPfCsaOXrOmjarsIy0Maflzw0wVh9iaHKVtG0uKF3slPCs97ppz3qGwni3eavFtdSPXlaEWuqfA61dwTqWjkuIre7j4/EXYyLIpPAdcYz5g4qlol8Iu1KHO0XEjWykY8DbgU/8A5C/WvO0cRi127lRSN7xzKMY5U88H3BpjYt1PygW7yvDLPaCBMo9rL3tvdCJkKk5ARdu1gfMcZ/8ADSnclI2KLyfMijkj3GQ0O5tjMxjHRkPOVB4yOKFahbthblGDxy+IkdN3y/qKLp1XDK1FvlIG19XuDV3SbNr7UbC1AJ72ZA3+gHcadbSTYhFNtI17sBocVrZRXUsY76ZExkDITr+561oiIPpQzSrZbe2gjUYCoox6ADFFhgD70phXG59sZzS5peD5sAdCfL3rKu0faaTUdfTQNPl22VtMRqc0bczNFlniDDoq4O71I9BzqmQxA9T9R7ivzrpUHdG9k3l3vblrSOXJ3G2SQPNKD6v4VH+o1rLW1tmcV7qRqehKs07SKONqke2eAKdVUIqr6DH1pZ7MW3dWnxLjlgWzjqSfL28vpTKh3ICfPnpQtNGo2azO5FHWgDpWqZVG2Ws8u10jkU92hk5WQFfKgWg389zFdWVzy1qY3hPUfDyruVQfPb0PsRR/UyvwV+vA3206Ekf402f3pU7PEG917uV/AV4IYCSG/wBkGhcA++0GpN/JBcC4DhGCR0I6g+tckjn3qabayrIByQASPtzVb51TVHXxvcj4hD54rgqc8V8xrlWBJ8jWGMRTQtKQf/Oa6K8H09fMVEp5+Rqwhz58+dKnqpraRkYHsfT19aryjHiHTzq/3eQcDjPI/wClV5E8Jzn3qNExZFZT3lQflQ29mnHdS20rQ3drKk9tKpwUkT0P7GrsnhJU+XT5UOuyQuR09aynTsczYI5MbT6ZzqHbfUZnuDtWNb2zmh1O3DlUnuHt/hTKFxw2AhHOPB/m4j7P3sl6iNKmJIO6ikdR4pQqBQzDpkAAfSl7UFEjE7Rkcbsc/LIot2SYrcXSPkhhEQOpwMg4FO5pKeFs8Ji0z0+sqPXP+Gu6U34KN4ugGT14o6nlQfS4tsSg5weefejSf9KmmXwRydW7yMlGK9r4V1TqOeyCcZRh54rMHRo9W1ln4U3bkc9cAVqUgyprN9X0rUZ9bu1ZZYtPll7zvIDH8RMqopcRBjhRnK7iPXAOOEdXByo6Whmo2mcieSaK61ZxvttKE0VmD/v9XuCLdNoHURA5b3P+XhdtJO/7TN3sjPHaRTXN1IxzuZSVCk/M8fWmzUYxFpRyIreC2ksorSCLPdW8HfpyueSxJyzE5J5+QXstYvdXmoSBV23NxDFICpyIk3S4yR1JZc/P2oUarai8jb+TGS1spIOz1xK6H4i9VryRW68ndGn3INQ3a/8A4i+XCkulsBnJHikAJP3zTLqSRx2Vx5RxQtsHTiNTjp96XC3/AOIglbADx6Usmc8K88RHH1qssdsqB4pWrMa1BLix1O4XJjlgu2eM9MAMJEYfsRTrqcK6lb2epgD8aAM+39Eh5YE/PNSfxB7Pd1b2WswKfDIbG9AHRg2I2P7j7VV0G4VLJ1nDm0upGETKC3cyp4X2joQSM496PldwjJdlYV/JJFF4vg5LW5ORbsI8nGQm4Fct7edR67DbiBO727pptzbf1njJyOOmKbJLS2ntmgJAjePAGd8TqOjRtj9j+1Jl7azWk8cOSyJudVLeA+HGVyffpQ8UrY3lVRddMBSxBVQjzHp707fw10f4u/u9RkX8O2AgiJ85GwzY+Qx96T5wx4CklQXI5xhRuOfan3sbNeW2o2NpoMqyC6s47jVkv98dqbtmkcCAIpIAUKoIH3HFOTdwpnNSqVrwa/DGEUADoBUje1DNI1mHVIZ3WGaCS2aOO4SfYFV3GRskUlGB8iD5jjmrvfIRv3oFK7oyWC7x6rnyrdpID2xW7e60+k6M9tbvtvdVMlnAwODFDtzPN9AdoPq3tSB2c09bya1Qput4gkaqDguxJbYo9TySTwM5qx22uZ9W17O1P5dp8EdrE7zxIJpC3eSsoJLbckA4X9Pvye7LWa3SyQLhIZ7ae3EoVkZ2dcZiQcqgPXPLeeBxSmWTdRQ5iSinJjFbahE/cpabRaQSmDcuVWRlUqSoP6RjC/fz4Ys4VefLjmkuC2ngWRG/2sMwbaDhBMsTRuhHkNwBHz96P2F/DcoYmBS5hI3xSYDFTgFkPQrnzH7VWLJTaZmcLVoj1q6WO2PiP4rpCQvUhiWOPfihPZm2Ntbu8g8d1Nc3bnaVAEjtIAAeeM1xfzfF6/pmlK5DpDdX06AZRUBEcZcHz6kex96JyM0FybVzGqRRIqGMnc278xZCMg9AOaptuW4awxv4LssqwaJwP0uQc+jedVWPl5jOalgaFWjjTdiVXU56+EdaoGaTe4I5DMOfY4ojfB0cONttImY+9cjrXO73GfSvVYVgbUaQslcGu0Y12yZ9ajIIOR09qWao9Raki2jn6186hs8c+YPn8qro1WVIbAP09RUFJx2u0DLqAqNygkeXt7GhkyKysp/Kw/8ADTJIm5WU9DzwKB3ERjZh1HUcViSo6mjzb1tkK13CVd1Ycg/cetTaKyxXyjyZCD5eYNXb6EOm8DxKDn3WhVsxjvbYjjc237jFbTcoNHM1uBYcqf2bbpEm63j5ySoo4nOKWOz0m63hyRwBmmiPoKb0ruCPAa6OzK0SDiuq+FfU6c05boaEXFurSzEgHcQf2owRVK6wmG4wQQfnQ8kb7DYm0+BJ7WSC30lchcG+hcqeQVhV5en0FT9g7cdzcSsTujKAhjuPeMC7Nn5nH/B7UF7Z3HxM2kaagIEt05lbpw34ZYfIE039kVX+TrcKgX4qSSZQOeGZiOfrSuNLcmNZm1Ci5rZzpupkcZtpkVj+nwnJx8s0A1aJhoFwkQHefyW0uYxwPFbPHJgf8o+9MuqRiTTLtCOJIZI/f8TEfX60O1tLaNLSGYDupXntGGOO5MSqx9eOKvKuXIFifSJZ7a21rRZ4wqvDqdmlxD6CVkDA59jg1nOm2gh0VrOQkS215NvDAAhxL1X3wfrTX2M1ARRaj2duZD8XpM8rwBhtZ7V2LgqD6Zzjyz7cVtVt1ttRuCi4S4/F2geFnbhhjp6Ec1jN+KoNp+JgyGMxJlsqg5LA9WPPQ8Uv61cWu/Jt45NiFFk3FSCcn9JI9cUx3Fwncqgzk+oyQRnOQfMUjXSzatqdvptkB3txKI2ZANsa/qY49Bknn+tYwx3OxrUTSj+yfS9F1e+i/ndvZrLYWd0u+Ji5Myxnc7bVG4oOM4B8/SmnRbKOaPUtVuLpYtQ+Md0sopGto1gnZ5JVheD8VUxlgRuXHkc8aDo9hDpljZ2duu2O3iSNR58Dqfc9T86qXuirG0txZW8EqSBhPZygIrBmDObaYDchb9Q5U+Y5zTDtu/AgqpryUpjcW1voem6cTbXerXcF7PvhgmmhSfO1VyNgMaK7BgP9yP8AFSb27mnv9aEXdyw2u9LJbmW2dzHaWmZJGgCg53sW6YLbFHTq5SXsQ1XX76a2iTV9NtZINHSERSXFxBdRIVPcxqJW7sjnxNgM2MVlMshP8ydZYgQ40ywtVYqW2nfLe3B/MT1JLZJZ/SPFGi0+UA2NOmgnpmnSSzw311B3UVzO3wltIhR1hQhVeQnBPAJ/fzrTtHSOAxFRtVbeO5GOBsZjGwx7Zz/6pI0C2uNRn060D5MMCxsV3EQwAlnbDZPiJIX5e1Pl29tZapoKE7UuDLpjLxjZKm+Pd5/mUAfOk7bluHpxW3YvosX1qFubkjhLhe/46bsBW/pn61RM2nwiSa9EYtYWzcPMVCJE4XLkn0z86L3G5tPil8XeQK8R6bjkFOfsKzXtbeP8D8Llyty0a3QEbF8RtuEZIGPIH6VMkUsi/ZnCt2N2WtFs7iLtnryXklwJIbWe6dxLIFcCZI41DHxFMYI5o3NNClxK0QBPetJJg/nc4OSzZJNVohIdG0nXLle6v7zTLXS7kMoJYWssjxsdpzlvDn5VzawtOVKxzuzkEtgKM9ehqZHUtqOz6ZhWx5sj/Qag7191wQVVIZQg9Gfkf1qjLKyyyAeTHOeefOiBWVYEGUjijJdyxyzkDAyT6n2oM7ICSZA5JOcHjPn0rb4VDelipylIsiUkk9PlUqHOcelU1Z+qqPsTU6GY/pHSsjU4UUmTPSoWTFXCoBrlkUg1hoejkooEFeccedSIw4qR0GMVAV2nihsZT3otqwIwen71UvLYOhI544IqeMnpVjaCDnzxmo1wAUninaFKZCCyn7Ut3Q+GuYyeAsqOp9s056jEiEsOucUq6zGvdh/NSP34rON1Ovs6OvXv6N5V3Hk0rsxdKyKnXinaJtwFZN2SuJWFrk8mIE/TArUrQsyISeuKPpZbW4HgPVcSU1kXlWXwa9r4L717t966Z56zmqd+jPbT7c7lQsvzAzV3aK5ZAQR5Yxg9PrWZK1RqMqaZhOrXTS6ysm8squYkZskZBGTgGtS7KAx9m+zykHcbSMNnghjwelZr2psINN1K0t4MlG1iZk34LJHKkR7vPmBnjNaZ2Tjz2e0HLMSsTnLckkTScmlsca4HtQ1LkM3S7o7dNu5XuYFYDptDbuftSZ26vktdQ7ORuyi3aPUJLvc2PA5iQH9j/wCGntow3dZ8nVx8xmso/ituWaKQNkG10+02kAhVklup3ZT5EmNAfYUeUFJV9iUJbZJga01Ca5ukuB+BrVm4jWWPj4kW7FBvU8bsYHuOuQSQ2w6rY6xGsFwrQXCEAFQxC88gj823rjg46c9aytJpWa0kDENJGjE55DAAZBrQtH0jTL6GKa+jkuGZjG4MrRqWAB3/AIWGz/xUlki06OhFxcbfgLXCaDHG8eoBVgcZe5+KtliA5H5SRPn0wM1B2Y0vs38RLeaLHO1vl0a5vFYTzSb+QpfkIOPn1PsbubfT7C2lNrZWyGKBmU7Ax/KTyXyasdn7dFsbY58Uid85AA3O/iJwOPOouHsB3acg1GoAFetmu1THnXhXkc02uhfyC73RdL1Ehru2ilcY2syjcPdWHIpO7R6BBbW7fBG6ku7iaKBYxcHmIklgzyngeRPPHkc1o5Twkg+lDFtYri9Z5ACbcB4yQDhmyMil8kOVtGMWVpO+gb2b0RdFsipKPe3GHuXRW7tCBwq7/FgeWfnxmqXaKZUm0dU8U41rTmL9SGWZc59uSKcGQKjAHAUcfP1pI1PB1bRlIznUoXyc9VkQf3rGb4JRQbTfyScn9DZcKRpuqrGoZh8T3StnDPnwLxz1wKzV9MksLe2OomSfVd7oEhKiGGSYiZmkZ85IzjhD068VpOtSS2ujarNC5WVIZWRx1Vyc7h8qzCKIRz2zlmeaa1EskshLOc5YjLe9TUS2tIf9H0T1Tcm/imO8cinRLie7YSiK9DRiKPAA2ohRQOuOfKqTXbc7SI48DYoyGYEdWwP2z9qmuC0PZnSlhYoLho3k5yx37pCMmgduhmVWZ28JK4znIHPJNYlKqS+jraLSxnCc31uaCEs0lyRvkYooAWMHCDHsPOvAm3oqDPyzXiqq42ipDuOMkf8AKK1/Y5tUfjHojKzk8MPkDXyhwTlmH1NfZUnBUfMZFTKh8nYfPmpRbddn/9k=');
background-size:cover;
 background-position: center;
background-attachment: fixed;"></div>
        </div>
        <div class="full-ab-mask  grid-item-center">
          <div style="margin: auto;color: white;font-size: 36px;font-weight: bolder">从你的上一步开始：</div>
        </div>
      </div>
    </div>

    <div class="card blank  ">
      卡片新闻的不同种样式。
    </div>
    <div class="card  perfect">
      <div class="card-cover-box">
        <img class="full-ab-mask" alt=""
             src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>
      <div class="row-f1 row-space-both">
        <div class="card-title r1">fsdfjskdlfjklsfjsdkljfklsdjklfds</div>
        <div class="card-desc  ">
          .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        </div>
      </div>
    </div>
    <div class="card  perfect">
      <div class="row-f1 row-space-both">
        <div class="card-title r1">fsdfjskdlfjklsfjsdkljfklsdjklfds</div>
        <div class="card-desc  ">
          .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        </div>
      </div>
      <div class="card-cover-box">
        <img class="full-ab-mask" alt=""
             src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>

    </div>
    <div class="card   ">
      <div class="row-flex">
        <div class="card-cube-rectangle">
          <img class="full-ab-mask" alt=""
               src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div class="row-f1 row-space-left">
          <div class="card-title r1">fsdfjskdlfjklsfjsdkljfklsdjklfds</div>
          <div class="card-desc  ">
            .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
          </div>
        </div>
      </div>
    </div>
    <div class="card perfect  ">
      <div class="row-flex">
        <div class="card-cube-rectangle">
          <img class="full-ab-mask" alt=""
               src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div class="row-f1 row-space-both">
          <div class="card-title r1">fsdfjskdlfjklsfjsdkljfklsdjklfds</div>
          <div class="card-desc  ">
            .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
          </div>
        </div>
      </div>
    </div>
    <div class="card   ">
      <div class="row-flex">
        <div class="row-space-right">
          <img class="user-avatar small cir" alt=""
               src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div>
          <div class="card-cover-box">
            <div class="card-cover-image-list">
              <img class="card-cover-image" alt=""
                   src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
            </div>
          </div>
          <div class="card-desc   more">
            .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you

          </div>
          <div>
            <div class="card  full ">
              <div class="row-flex">
                <div class="row-space-right">
                  <img class="user-avatar small cir" alt=""
                       src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
                </div>
                <div class="card-desc more ">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
                  .Nice to meet you
                  .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to
                  meet you
                  .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to
                  meet you
                  .Nice to meet you .Nice to meet you .Nice to meet you .
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>

    </div>
    <div class="card   ">
      <div class="row-flex">
        <div class="row-space-right">
          <img class="user-avatar small cir" alt=""
               src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div class="card-desc more ">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to
          meet you
          .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
          .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
          .Nice to meet you .Nice to meet you .Nice to meet you .
        </div>
      </div>

    </div>
    <div class="card   ">
      <div class="row-flex">
        <div class="row-space-right">
          <img class="user-avatar small cir" alt=""
               src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>

        <div class="row-f1">
          <div class="card-title"> sdfsfkldskldf</div>
          <div class="card-desc more ">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to
            meet you
            .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
            .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
            .Nice to meet you .Nice to meet you .Nice to meet you .
          </div>
        </div>
      </div>

    </div>
    <div class="card   ">
      <div class="row-flex">
        <div class="row-space-right">
          <img class="user-avatar small cir" alt=""
               src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div>
          <div class="card-cover-box">
            <div class="card-cover-image-list">
              <img class="card-cover-image" alt=""
                   src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
            </div>
          </div>
          <div class="card-desc row-space-top">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
            .Nice to meet you
            .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
            .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
            .Nice to meet you .Nice to meet you .Nice to meet you .
          </div>
        </div>
      </div>

    </div>

    <div class="card   ">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div class="card-cover-title primary">
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title
            1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title
            1title 1 title 1
          </div>
        </div>
      </div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
    </div>
    <div class="card perfect transparent">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCAC9AR4DASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAABQYDBAcCAQAI/8QAQBAAAgEDAwEGBAQEAwgCAwEAAQIDAAQRBRIhMQYTIkFRYRRxgZEjMkKhBxWxwVJicjNDgpLR4fDxJFMlVLJz/8QAGwEAAgMBAQEAAAAAAAAAAAAAAwQAAQIFBgf/xAApEQACAgEEAQQCAwADAAAAAAAAAQIRAwQSITFBBRMiUTJhI3GxFIHw/9oADAMBAAIRAxEAPwBmGckZ9aynthbbdSmmXOGwW+fStYA5+tZ52qWN727hPUxhl+dJN7WmN4FbaFrQLoWl/by8cMB9+K14XEc8SFjw6Ajn2rEIWMcoz1Df0rRYtZtbXTbV5WO7aAAvXOM1WThna08fcxqvAE7UpsmRQcb2Jx7Uy/w+JC3y5/w4pRdrrX9VtkVTmeeOCJfTccZp70fT/wCQ67NppbPe2sUwPrkkf2oceKC6uN4Z32/8Q4jNdDPqa+FdDyps8seDPqa659a84qOSQIDmoUeyzd2hOegzSR2j1WZY3jRxubPTk49aO394ArDeBweM0kX8ltLI259xJPsKBKdukYlL6Ey5E8srM2SScmoe4b3pkeCBsiNMsfQf3qlJaXPlH+xoqmuiKQKWIg5xU7TSBNoUD51b7iVPzxn7VFIqEHjBq7sm4HbC7596ZNLlt4QN/B9aBFQpyKsRSeRNSS3KiSTa4HEyrNHgEMvqOooTOogcneDkjK+dVILqSI+B+PSmrsx2bbtHML69QrpNvLtYcq19Kh5iU/4B+s+fQeZAFBpgo8uj3QOysuvql5JvtdP3Y74D8S42nB+HB4x5bjx6ZxWm6Zpun6VAtrYQ91Hku3iZnkc9XdnOSauIiRIioqqqKqoqABVUcAKBxgeVepgFj9yetHUVEZUaOydoJJ6etDZNSaObuiOTkqUO5QB/iPl9qvsUwWfaEHOW/wC9Urq3in4KFeQQ4GG49POpO/BuNeSxDeQyZBYblXLZIGAOpPkB8zUy3FtJkJNG2ODsYMAfTI4pcNhtkjB8canJUhmG9TkHbgj70bgOVCq7ZA/KXOVH+hlH9KzDJJ8MkopdFe/0PRdUliubmBWuoVKRXETlJUU/pypwR7EGqMmj3UCFVkE8YyAcbZAv+YDg/Sj2DxwD7kYP3FdZ6A8H0P8AaryYo5FySM3DoxHthoJBa5jB55PnSF3W0YPUda/SetaHFqdtOsRjiuXXguCYnPpIBzz6jnz8qwbWNJvdOvZYJ4WjJZymeQQpwQDgdPP/AL1jFGWP4vomSSlyCra3eVsD1ozDpmV8RqrARbjJFey6nMCQhwKJK30B3fRcGlsrgpRFNMkePkE8c0GttRm3KS5OPU8UyWusxgAORgjnpQZ70Ycn5FW9spLSUsAeDke1d/zu6CKm44XGPpxRTX7q0njLREbvPFKBbk0WMVkVyQXHJpH6CA5NZ52qwmrKccGJc/eqa9pe0gbd3wI64xxmh2pane6hcxy3GAwwvFBfyOnDTZMT3MEXsfdXD4Bwx3Ci+nXEN3bNZykbwPAT/aotWs3KQzx+Ndg3Y8vnQaGR4nVlJBByCK3SyQ/Y1p870+XnpjpoDnStYsbmeMsLeRnAxw2VK5U/WjcmuC87VG+K7IysVsi56IgxyfnmgGn6xb3Sxw3aovdrhWzjJ8yDUJbEklzG4Ajfcp9cc0o3KPB6mOPBqIub720bPGwZVI8xXdCtBunvNMtJ3yC6DrRCWUIDk9KfTtWfPckdknH6PXkCg80ra7rkdkjBXG8jgVxruvLZxuEbx4PmKzO81Ce/md5CTk9PKsNuXCBF691+6mLeM8+/Ffafb3eoycNyeSWPAFB3t3OCKs29/c6cpKcNjir20vj2S0OkFhbWQBmcNgckkAVcivtDJCExn7H+tZpda5qF0T3kjY88GoFvZBg7jn5mh/8AHk+WyVZsaafpN6uUCZI8sUqa72emhZ3gTjnGBQPSu0d1auoLkr86a07U206hZlJPqMEYrOycHwZfAjSwzx5DoeKq5bJxmm+9awvTuiGCfbGaGnTQT5cmjRnxyV7iXDK2iafc6xqdjp0Qb8eQGZlJXu4F5kfd8unzr9CWlvb2dvbWtvGscFvEkUSJwFRBgAUidg9HjtI73UXX8WdhbQ8DwxIckj5n+lPLP0A9OfkK0peQyVqyVpMnHrwP+9dxndyegz18/eqq5bPv/wDyOp+tW04UY8/6eQqk7ZpqjvGcE84ORXxCnrioZpdgAHU5x9OteJI3HJrW5XRNjas8lhRiSpHPPyPrUaJbz4juEjMiZKnBVwemVPX7GrYyRzmo5YN3Izkcj2IqNeUS/DOlR4eAxdPRz4l+tS8MP7Go4nLDa35x19/eop5mtvGRujPUAeIVq0lZmndFjoPYe/SlntV2dt9XtZp4oyb2NN4EYBacIOMA8bh5Hz6fJkWRJI1kQhkZQy48weajDBHCZ4Yb058vaqbKq+D8034eGeaFsZjkZeOhHkR7HyoczHn50/fxK0SPTtXjvLdFS21NHn2r0SdGxKACehyG/wCL24RjCNhbNa6KoijcqetWPiDjr+9USSDXp3EVqiNEkk8jcFjj3rgc5rkDnmrCKtQgfQjGAKhnTpnqTVqMKgAHJrh13N6n+lc1vng9xjxbofIKaUtu4WKYju5Iyh3eRNK+sae+n3k0ePwyxaJvIqeaLhZV2gEgE5GDjBq3dJHqtoIJcLcxD8Nj1NSE9kr8Cms0u6NwXQpRSMvnRPTbe91S7gsoAxMrL3hGcBAeSagt9G1Se8js44SZXbbn9IHqa2Ds32ctNBtgxAe7kUGWU9cnyFNNRl0cd6meKG0NWkEdjZ29uvAhjCfUCget6xFaI+W8XOBx6Vd1TUI7WJ2ZgMA4zWVazqMl3NIxfCkmo1fBym/sr6pqMl3IxZiQSaGKWU5FctMi+5qIzM35RRVGii6Ljb1rppEnUg4z5UMYSV2m8etXRODmaBlJIHGar8ijVvEkmBJ5+tfXWmsx/DXJ68VN6XDJaBCOUYGj9pLavENxAYY86ESadexjJibHyNQjvouoYfSo6l0y+xnjuURuGBFTreZZAuSSwAAGSSTgAClVLhwetNfYqzbVdds94DW1gDfXG7oSnEa/VsH6ViUaVsF7W5mx6TA1pp9jbt+dIFMnAGHIyRx6VcQko7HPiYgfIVCXxGSPNeOPWp4hnu48ZwoLfXmgp80ObaRIBhUH6pCFHsKtLySB0U7R9KrAjfJKfyxKdvuQPKpmbu7eRjxsjY/8WM0VccmXyVXKySsf0r4Rn29qsR+VUInzj0zRCMZAoWP5Ow01tVE4/wCldVyo/tXdNoVZDICpDjy6146pNGyMMq4qVgCMVWRijlD0zkf0NYlwbXPIM026eC9utJuGJdV7+0ckfixZ5H+oef3onMm5SQfFG29D7eYpf7TE2L6Zq6dbK8t+9IHWB22uCfTBNMZI3gg5VkyPQ4IIP2NL47VwfgPliuJryKvbzSBq/Zy7kiXN3poOoWxGNzCNfxU9eVyfmorAVlfBX6V+nbrf8DqaRrukFndCNem5u6YKM1+bJYkBJC7c84GePvzR4u+xSTplErzk1Kuzbg4zXkq4NSWyIxw3NbbKIHHpXAZqv3EaIvlQ8YyatOyxmguYZlAiYBsflPXNdgMGG8YoHPb3VjO0citHIh5zkfarCajMQFk5x0PnSUsXmJ63D6gn8cvDGaKEzINuMjnHnVyPSXnQyIxEsfOB54pZ0nUriO/TvDmFshgemK0S1aMqtxERtOCQKHKFcMahqvcg5xX6JOzyW3fneALmNdpJHOPnTFd3CRRu7HAAqr/Kre6tU1LTTi8iG50B4kxy0bD19P8AvSd2m7QgWojRiJGG1x0IPmDW8MXBbWea10VKbyQ6/wAA/aPX++leON/CpYcHik+W4ZyeetRSySSOzMSSSTzXiqTinVGjmnmSTRK2ji2crk4qmsL8cGjVjHbxrmVvLgDqazN8cFFJ4pCfAnFSQW0rHmMmr8s0bZCLtX96pyXfdnCsflyKGm30VQRW1KR5YKvt515EsokzGpyPbNUIbwuwB3EH1NMVpfWNvDuaPLgfSsSuJVUV59RiSNYpUXIHl1oVI9lODjAPPWo9Su0uJWKLgEmqaRux4FbhGuTVI4ltV3Er+1aT/DWx7iy1S+Oe8u7lbZeP93AOcE+pY5/00hx2z5HU+ta92ctjp+jWMG45SESN6d5Ke9bGeerGqyzpUFwq5DA3RRjqQMfUD/rVi3bPxL+h2L9OKqOxVoc9dpf/AJVz8+pFXLb/AGQHGSwLfPGaFF8h5LgkyARD1cxiUj2Eij/z5V7fN/8AH29A7gH5A5/tQ+4uhBqUTPnYTa2anjkylift1q7qGe5hI/TIQfrWnL4yKjH5RIYlRVXOAB1q5HcR48Ks2D1xgfvVGWO7a3c26hpApKoTjccdAax/tL2j7XwXr2c0dzYbdxjSfwb0x1BB2EenNTHa4SCTUXzJm1Tana2/M5KjzKEOR81U7v2qa1v7C9jMtpcQzxglWaJw21h5MByDWK6Tpvb7X9kEN/GgEE05+IH4AEbRhB3kKsPHkleP0t6U1dk7DUIEv3u7V4NY0+Zra8UE/iJ+ZWOOCCOVPII5B9CSlOHLBxhjnwnyaRkGql2SmyVf0MN/+k8Gu7djJCr8+IDApI7TdubXSjcWlrGbm8COxCAOIkUcvIoBwvz/APdzlcePJmMaf9DPrMCX+mXlrkZuraSOJs8CXB2ffyqbTZZJdO0qSTiRrK3MoPUP3QDD71madttOn0Wxtry9vI774a6NwkS7NzO7d0G8OCMbSMetaBpVyp03Tfxe8YWsEbvuDFpTGpOSPP1pe2p21XAWUU8dJhJWG6UZ4YlD8mGK/PWq2c1te38WOIrmZBtBAwHOMCt2u5+6tpH3YLFgpHUEAnP7Ujala6dI8s7smZMvzjqeta37RPNSZljQytxsNRL3iNwcU9ta6a+5Q6An0xQq80iIKXjOSCc/KirKn2B3oW52JUEkmqlX7mFkDDHAqhR4m49Gy9pOzdvqkLyxKFukBKkD82PKsmuIJbeWSGRSrxsVYe4rfWO1ZG8lVmP0GaxHWZhNqV+/GDM+MexxS0XTo6OF701IHxyMpHPI6U6dntZjCfDzHA9SaScZ5HlUsErROrA/OqnG+V2dXS53jeyf4s2LT9SaxlbupkNvPwysRjPkRSn2j0K4nSe+i/EiLNIWXnG45JoTDcyFFw7bTg9ac9Ns9disU7yLvdOu1JypLtCSOCV64NKLI26rlHczaHHHG5blUjJniKnGOQSD86tWtszNlhha0cfw8mvIprmGVYpcloo5BlGHofMUo31nc2E01pPE0UsXDhvP0IPoaeWS1R4PPjeObj9FKbukASMAt0JrmGJyw68+p4qNdobcx4HrUvxKLwOBUA2FreK3AAIDv7/lFVr2ziYs3hXHkuDUNn8bfymK1jd8YDMvCrzjBP8A0BPtTpadjtfaHvBaqvhLGW/kNnAmFzkghrk/8sdYpplqLEiGwDEMQUjUjMkjLGg/4pCBRMWWjbF77UkQMMqFjmkDc7fCyptP0NNll/DqC4dJdU7Q2jyOFkaCxjjkxxkgPM7HA4520xnsT2XMEO+e6kMTFlmHds/pjBQjHsBW2mzWz7ZncWkdm1JM18/HTagL59Chbr88VO+ndnBHmO9t48HaTcSZc54yI4zn9qcZuxXYcSJJLeX8YmZlVBKIotyjONojHP8AWh11/Dzsve5+C1l4WCo0Y7m2ZGUjO5gNjH3Of6Viv2X7aFyws9Glv7e0S4uJ2kmWMbIXSMkeLBLkH58VoLtttoAPEZplUKOPBu45P0oFo/ZGLQrh70ahFej4Z4oe5jkj/GduXIdiMYwBz60xXqKsumQpkqhti3XnDglsfagZexnCkui2fFdyLg7UQqf2Of6UQt8njqO8bp6Lgf2NDbRhJc6g+chGkA65BLnI/aitqDtQkYPOcepya3iV8knxwLHamb4SGCTOJO9mnTB5Z1GE+maOWN/BqljaOCM3UIliz/8AZHxJGfcHNLHbhkM+n2oA3zomcj9KF3AB+ZB+gqppPx1mGgJZrZ271QrYaCUHIkjPkfX1oMp+3Np+RyGH3cSa7RocPHhYYI4I96rapoej61CIdQtUmVTlGIxIh9VYc1HZXEkqp3p3MBjdjGfmBRZSDinsbUlwIZYyg+RQj/h72XiZzH8eiMiJ3UV5PHHhSzZIRgD18/78slpYWOnwiC0gSKMKqnaPE20YG9jyfqauZA/aomkBOFGcdaK6QK2z6JQqsoGBk4pG7S9jru+PxelywG5EfctDexRNEyDfjY6IGB8TA5Jzn2p8Tpn1rwFSSMeZrNF3zyZFd9kO1Ovahpi6rZ6ZYafptqlnGdM3Am3hGEQNIWkJ4GMnj68uWk6WumQWdtGGVIopdiuxcqu845PNM8wVVJx5VEYkZoGI6oE49yKDkg5PlhYz2x4Qidptajt7u609DhrO0jdyeveSQvKT9AVrMbzWJpCRvOM8jNSdp9Smn1rtJKSwNxqFxGoPUQxSFFGD7BftS27Fjk1uOLm2LSVhQaky85Oc+tXI9adl2Mcg8Uu18M+VF2IxsQwTGOaJ8YyeaAuu1mHvU8M0owOfrUzxiUhvOqXxNJUbhfyiGyvZM9InA+ZGKxW5id5JH5JZyx+pzWk6tqne6fPHjDScEe1KsNl3oHAPFc/3knZ6KPp2TCnHIuRV5Q4PSusDqOlFdS014cuF8NB1JGVJx86ajJTVoVT2S2TCljKR+Gx4PT2NO/Z/tXfaUYbWcG4sdwAQ/wC0iB/+tvT2NZ5E+0jyowl7aBF3viQDgAZ8Q6bieP60rOMlLdE9Lps2HLh9nPyjZbHtVpt7qsWnwo697Czoz8BmXkrigf8AEfSxLaRalDHmS2JExHnE3mx9qQez+ozjtBpUoU5FwEy3JCv4T14rcrmK2vbaS3nUPHMhRkYZ3AjmjRlKXEuzzXqGDDjmvZ6Z+a447y7njgtopJriVtsUUCNJI5/yqma0bQP4Xzzd1cdoZ2hQlW+BtWBlZeDiaYcD3A+9P+h9m9F0NZF0y1SF5f8Ab3BJe5kBOdveNyB7DH96PKEUAKKZRydtFCw0rTNMhS30+yhtokXaO5UBsf5nPiP3qrrGkRajbSRSxtKrlMh3zjxAE4Y46Zo1k1FM8gjlKfmCNj54OKqUU1TNRbT4FfTNLv8AR2te5WE27RLFPE8aoyMq8NC0Yxz+rPzo0ZnUOdhwQPThicc1fBJRQQCcAny5qOWK3lGHG1mI9OT9eKGse1fFhHO3yQSd3KrRkIVZcbTzkY59P60ldorS702G71C2N1dhldd9wqO1ojrsYjA3YHr15+tOzW8kCuYmIwWZcDcATyeGzSvrd7PcyWumvCpE89s0jITjuBJmQsvsB+4oOTj8gkOeifSo5vgdKjuMPJIglkIACYbG0bBwOMcYrq5w2owM2R+OIlBPGI1d2/tRG3CmZOMKO8frgYUYGP3NC7lf/kW0gyG7jULgtjjLCOJfuSaFPo3Ds702UBL52x4nXJHu5PT70bsmPdQ+56fIZINLUTLHp9wAcF76K1TkglzjOD1/90x2pHdQHI8TOR8ifKrwy8EyryJPbc41/RwTx8Msg54wJApP7UUtURguPKgP8Qpe513RJyPALGMHJ8jPMpH2Jx/2o1pMoZAc5GAfXyrGpj87GtO7xceArBI0b45x86Lx3UeB4h96FFV3q3k3FWzbnYXVGfahKxoVQytjhSx6Ct4XKPCB5tslbLqzGY4Q+EcM3l8hVC51C6sZbgNp95cRna0L2iI4YMB4WLMMEc5z/wBhxa61ZDdDPa6lazRYDxy6fc7FzwNskKvGR7hqvDUdNfKCYbiCQGUo2Pk+DTfa75F1Fxf42ijZdo9PnSZps2hidlaO7ZEkGDjopOfbGauLfRSPGUDBZE3KWUrkZIBweaGyW3ZqOYXEstmsved7ulkjU7vXLGpJ3jk5t2WRVfaGjIZMEc4Ycce1Bc5pcsK8cHLhNFjUdStrO0u7qdwsVtBJNIx8lUcD6nAFS292jXVtbnjdYR3UQ8nBYqxHy4+/vSVrKDULTVtPlmJZobZUjUnPe3E4jgyPmC30FNi2LwzdmQsmXs47iJ2OcvCYVUjk56hT1qQyOfJMmOMVX/ujCe2lhd2XaftDFMuO9vZryDb+UwXLGZCv3wfcGlsqw6itm/iRpL3WoadeouR8AYGwv/1zMwyf+KsxntlRirLtx6im96ujmXzQKVSR0r5vDiiLxwqnhxnHNDny7YAq07LO45UHBFd99gnbg+tQNGy9eteKcE1dIs0zVwBCvuR/WvdOiDKPpUesuAsS+rAVa0xhsX6V5+R9E9Qbcq/RPe6Yk9u67ckg81nGp2UlpM6kHGTgkVsVuquADzxSz2p0dXUyKBkgkECmMGTY+TzGaHuceTNkkIUjzzjJ8lPBqQLIcAMOenGK7a2kQuNvCnxE8ADOMkmr1vBLaqJTGO9kXckkoOYYxyZEV+ATwASM+mM5rpuSfKOdc48MM9ldOu5dUtcoSYyssrMNsiRgZxuY+HPHvz5Vt9qjlIwcbiBnbnA48s+Q8qQeyEDrbxTyKmxvDHGu7xySHqSRzx1J6lj6cPzTx2UKd4wa4mfu0Cj88rc8D0A/p70CDTblILnbdRiXNyoNq9R19TXa1ThYtgnknzxVtTR4ysUlHad1FJyMe/Py9Klrll61p9GEyPd9P7/KuHcFSD0PNSbAKrTeHkY54PyobbSCpJkEl/JaxySGNp40DMyxlRKAP8O4gH6kfOhE13oupS2d1aMpdnKsGDRSoWCnbIh8/P8A91LfRyYfu/05dceufQmlWzZoZAWUxzzS6hrNwPCT8MuLaAHPQNjf9fpSbySdp9DHtxStdjjaSq00oH/68+0+YAbaB+wri4ixHLJjJWBE444MhZs+XkKD2V6o1W0i3DDJNGpJ5bvgHIU+o8P3o7etjTrtwf8AKCf9QU/3q4vdF2VKLi0AJH22mgxtjM15JdMc8fh7ipP2FG7ecBbIZ4JUHHp3hXJwfal+/wALb9niMeFN/PHk5YY9eldw3W1rRd3lH+Y4/PNIQRSym4yGHDdEE/xMi76x0W+QeOMyQMR/hYkgN9Qao9kdaSVIoJGG9QF5PPGOpo32oMV9oMi5CiDUJ7R2P5UMjK8bHPlkj6Z+uRwT3Vhcb0ykkUhVl5GGU4IYdc044+9C/ILFL25U+mfoqNEdVxjyNEIgVArO+y/bG2u0jt7pwk6gLhv1eXFaFDNHIqspBU46e9axNdPsrPFrnwdsC3IJ49KgmeORHiuLdZo2BVxIiOpU8EMGq6oU16yIfIfamab6FFNLsDyWmm3ChPgLMoAEw9tCQFHAGCvSq17dQWwWLckUKmKEHhQC5CKi+5zgUZkRVBI4oE2n3dxqcd5LhoLeBzZQbM//AC23Bp5cgngYCdMcn9XC+RPoaxyT5YBtdE/m19q10txPBf22qW6uzMWtJGsWVkTuv8O3Azn38uXtIxLNHK4YPbK6AAnaWkCluvUcDFUdK0yS1DSuZFlm3SzqxDfjytvkbI9T0ovwBzWsMKVsHqMu50hO7V3kyXMcQgaSCCHLsoyd8h3EY9AAPvWe37aVebtu1ZOf8rA/I1ptw4lnnZ1DB3Ygew4AoHqPZnSNR3Ps7qbyePg/WguXybGZenKUE0+TJruzMZODlfUVxDZNgvjpz06033nZDWbct3W25h9B4X4+fFUkWOzbubqJkJ4YOMEfejrLxwc7LhnidSQo3ZJcLtwRxUSQseTTXf6Mkim4t+VPPFAJY5Ym2lTx7UaE0+EB3Gi6jpjXYXu5NrocgNyp+3NeWkE9tiOVcEY5HIPyNElbk5rvGRx9vWuM4buj6fqMCy/2XbMcA+WK41TxxMjIHU/pzjn/ACkcg19aXMcbrHKAqscLIfygk9G9KZ10K1mKPcStIMBgsR2ocjru61vFhnNUjyeqi9Lk/kMgvIbS3m2osz3Ab8oVHO4/piQDJPvj/rTpp3Za6urOITWXdZIfN4cMWKjxvHySR5Z9KerPStKsM/B2kETH80iqDK3+qRst+9TXEpijJUKZXIjhVjgPI35R/c+wp6OmpfJiD1zTagu/sB2ummylTc4KwRbYUHk78Fz7mqF0Z/54wlk3pHbJJEq8LFv8JUep6kn39qMMHRJi7lmijaSR+jPJwM49zQi+kjGsmJNu62tbeCUj/GcynGP9VDzJRhf7N6ZuWT/ph23JKrk+VXkPH2qja8ovyq8tHxdITy9kgr6vq9o4ucNiqk3Ix5e1W36CqkpGCc0HIGxg+ZzjuwCSw2DJH6vCM/tSdr8UZl1q5IysFtYwoQWzneMYIOMYDce5p0Y8u2Blcsuf8eMAilPX4Yv5ZdTd5zcamsHBwNsETRMOTzgs1KPkbTFAapKlxoku8968EMrFich0drbI8uQo+9aP8X8T2dnuHPL3JDnGODNhj8uayRz3kvZYcDKSQ8nAAFwrgcelahuC9m7yEcnZdOvQcrMqjH14rFbXx5Rv8lz4aKN06z6fospIBgmCSEnkDBjPPTzz9KGRzuZ1VuAkajw+TRTHOfvmpdLKalpVxbb1xcLMtuWJG2cqJEz58A4NDopJJlN14RIyst1GCfwrpcLNG4+eGHqGFLzi6sYg10X9RnhksO2NvIAY1uNOuCMdBPbCNiPqOazWctPulJJuIxick8yovAlz6+T/ACz5nDdqN2Ei1/ceLi2slwDkEgBR/WkTvJFIIOGXoRT2l/EVz1FokWZ42V0cqynIK8EH5069nf4gXFgY7e/y8GQO8GTge4HNITuGOcAHzA6fSo6beKMuxVZ5R4XR+mdM7QaXqMSS21xHIrAfkYEg+hA5ombuDH51zjpmvzdoNlfXl0iWryqzkLmJnU4GMnwmts0Ps2lrBE95c31xMQGKzXUzRDzAC5pdzlGWyLsY9vHKHuPgZEIuSccxg+I+RPpVsKo6ACuE2IgVVChRgAAAAewFcPOiAknAAOeeAAM0wqirYm7k+CYsAKHTX4GNmBCZO5kuGbChjnKxgck+/Qe+MUIvdae5nhsrEblkYCefoNnmqfP1r3W4dQbTIIbHTPjnM/eGMTiAxBB4WRiQOckdaC8u+1E2se2txRjsdR0kw2s8z3tmxf4K8YZn2DDCG6I4LgZ2sOoHrVxTnyHNVbW71TS0jttdt2Gn3EqW8NyXRjESoKd6VPDeXzX0OKKyQtFwdrjqHAHiU9G/60Bq3Z1dPqbWyZWyapX+madqKFLqFG64bHI+o5ogfpXJFVtHeH2L8XZ2K1V1tpmZDx3cp3DHsetAr3s7mUloW5P6RkftTyf715u9eazynwKZPTseTmPArZ967WQrjP0rnFfYHTBwfvS1s97w+yzuRhg+f9aMaVql3aju1Pewr/uXPT//ADY9Pl0pe5HI/wDYr5Lh42DL5HkUWGVwdoT1GijqIOElaNMtbu3u4+8ibpgOjYDxn0cV9MR3sJP5YleVhj18IOfbn70gR6jPbyLc2smyXjqMqwHVJB5imbTtesdWkjtCTBfS2s5eBs7cxsmWjfzBzkeeAeOK6WPNHJw+zxGu9Ky6X+SKuP8An9l5UJVnySPB3hU85wHyePlSQbmRu0Ouh8k/zS4RRkcIixoP2FNdvqAg0ztBN3Z7zTGvleNiOZLdMAfXAI/1VnFjeTz6nqc1xt7w6jKzbT4cPHGwZfY9frS+sX8fBfpa3ZWn9M1K0I7tfkKvqc0HsJA0afIH9qKqeBW8MrjYnqIuMmifivq4zXWaZTFGjiQ+E0Ie5VjMpZRsfu2IOcE8+VE5yAjHpgdaQPiX/nWro0hYC5iCA8qgSFRgDp1zSOqybKHtLi32MlxOiopJxGiSFs8ElRkHNKvaSVI9P7Oo5/EmWW42EjmW4dWLN9WUH5GiGtXEo01oYsGS8ljtVzngznZwB88/SgHaNhd9odMtYmBSytoYZBxjdlp5Dj2LKvT9PtQscrTkzc41SF20te81XQYlOY7OINk9dscQfOPpk/OtAOf5NeZ6xwXMh55ADSS/LPAoBaWSxS69cgFRaWkqErjCd7MkKqPfCsaOXrOmjarsIy0Maflzw0wVh9iaHKVtG0uKF3slPCs97ppz3qGwni3eavFtdSPXlaEWuqfA61dwTqWjkuIre7j4/EXYyLIpPAdcYz5g4qlol8Iu1KHO0XEjWykY8DbgU/8A5C/WvO0cRi127lRSN7xzKMY5U88H3BpjYt1PygW7yvDLPaCBMo9rL3tvdCJkKk5ARdu1gfMcZ/8ADSnclI2KLyfMijkj3GQ0O5tjMxjHRkPOVB4yOKFahbthblGDxy+IkdN3y/qKLp1XDK1FvlIG19XuDV3SbNr7UbC1AJ72ZA3+gHcadbSTYhFNtI17sBocVrZRXUsY76ZExkDITr+561oiIPpQzSrZbe2gjUYCoox6ADFFhgD70phXG59sZzS5peD5sAdCfL3rKu0faaTUdfTQNPl22VtMRqc0bczNFlniDDoq4O71I9BzqmQxA9T9R7ivzrpUHdG9k3l3vblrSOXJ3G2SQPNKD6v4VH+o1rLW1tmcV7qRqehKs07SKONqke2eAKdVUIqr6DH1pZ7MW3dWnxLjlgWzjqSfL28vpTKh3ICfPnpQtNGo2azO5FHWgDpWqZVG2Ws8u10jkU92hk5WQFfKgWg389zFdWVzy1qY3hPUfDyruVQfPb0PsRR/UyvwV+vA3206Ekf402f3pU7PEG917uV/AV4IYCSG/wBkGhcA++0GpN/JBcC4DhGCR0I6g+tckjn3qabayrIByQASPtzVb51TVHXxvcj4hD54rgqc8V8xrlWBJ8jWGMRTQtKQf/Oa6K8H09fMVEp5+Rqwhz58+dKnqpraRkYHsfT19aryjHiHTzq/3eQcDjPI/wClV5E8Jzn3qNExZFZT3lQflQ29mnHdS20rQ3drKk9tKpwUkT0P7GrsnhJU+XT5UOuyQuR09aynTsczYI5MbT6ZzqHbfUZnuDtWNb2zmh1O3DlUnuHt/hTKFxw2AhHOPB/m4j7P3sl6iNKmJIO6ikdR4pQqBQzDpkAAfSl7UFEjE7Rkcbsc/LIot2SYrcXSPkhhEQOpwMg4FO5pKeFs8Ji0z0+sqPXP+Gu6U34KN4ugGT14o6nlQfS4tsSg5weefejSf9KmmXwRydW7yMlGK9r4V1TqOeyCcZRh54rMHRo9W1ln4U3bkc9cAVqUgyprN9X0rUZ9bu1ZZYtPll7zvIDH8RMqopcRBjhRnK7iPXAOOEdXByo6Whmo2mcieSaK61ZxvttKE0VmD/v9XuCLdNoHURA5b3P+XhdtJO/7TN3sjPHaRTXN1IxzuZSVCk/M8fWmzUYxFpRyIreC2ksorSCLPdW8HfpyueSxJyzE5J5+QXstYvdXmoSBV23NxDFICpyIk3S4yR1JZc/P2oUarai8jb+TGS1spIOz1xK6H4i9VryRW68ndGn3INQ3a/8A4i+XCkulsBnJHikAJP3zTLqSRx2Vx5RxQtsHTiNTjp96XC3/AOIglbADx6Usmc8K88RHH1qssdsqB4pWrMa1BLix1O4XJjlgu2eM9MAMJEYfsRTrqcK6lb2epgD8aAM+39Eh5YE/PNSfxB7Pd1b2WswKfDIbG9AHRg2I2P7j7VV0G4VLJ1nDm0upGETKC3cyp4X2joQSM496PldwjJdlYV/JJFF4vg5LW5ORbsI8nGQm4Fct7edR67DbiBO727pptzbf1njJyOOmKbJLS2ntmgJAjePAGd8TqOjRtj9j+1Jl7azWk8cOSyJudVLeA+HGVyffpQ8UrY3lVRddMBSxBVQjzHp707fw10f4u/u9RkX8O2AgiJ85GwzY+Qx96T5wx4CklQXI5xhRuOfan3sbNeW2o2NpoMqyC6s47jVkv98dqbtmkcCAIpIAUKoIH3HFOTdwpnNSqVrwa/DGEUADoBUje1DNI1mHVIZ3WGaCS2aOO4SfYFV3GRskUlGB8iD5jjmrvfIRv3oFK7oyWC7x6rnyrdpID2xW7e60+k6M9tbvtvdVMlnAwODFDtzPN9AdoPq3tSB2c09bya1Qput4gkaqDguxJbYo9TySTwM5qx22uZ9W17O1P5dp8EdrE7zxIJpC3eSsoJLbckA4X9Pvye7LWa3SyQLhIZ7ae3EoVkZ2dcZiQcqgPXPLeeBxSmWTdRQ5iSinJjFbahE/cpabRaQSmDcuVWRlUqSoP6RjC/fz4Ys4VefLjmkuC2ngWRG/2sMwbaDhBMsTRuhHkNwBHz96P2F/DcoYmBS5hI3xSYDFTgFkPQrnzH7VWLJTaZmcLVoj1q6WO2PiP4rpCQvUhiWOPfihPZm2Ntbu8g8d1Nc3bnaVAEjtIAAeeM1xfzfF6/pmlK5DpDdX06AZRUBEcZcHz6kex96JyM0FybVzGqRRIqGMnc278xZCMg9AOaptuW4awxv4LssqwaJwP0uQc+jedVWPl5jOalgaFWjjTdiVXU56+EdaoGaTe4I5DMOfY4ojfB0cONttImY+9cjrXO73GfSvVYVgbUaQslcGu0Y12yZ9ajIIOR09qWao9Raki2jn6186hs8c+YPn8qro1WVIbAP09RUFJx2u0DLqAqNygkeXt7GhkyKysp/Kw/8ADTJIm5WU9DzwKB3ERjZh1HUcViSo6mjzb1tkK13CVd1Ycg/cetTaKyxXyjyZCD5eYNXb6EOm8DxKDn3WhVsxjvbYjjc237jFbTcoNHM1uBYcqf2bbpEm63j5ySoo4nOKWOz0m63hyRwBmmiPoKb0ruCPAa6OzK0SDiuq+FfU6c05boaEXFurSzEgHcQf2owRVK6wmG4wQQfnQ8kb7DYm0+BJ7WSC30lchcG+hcqeQVhV5en0FT9g7cdzcSsTujKAhjuPeMC7Nn5nH/B7UF7Z3HxM2kaagIEt05lbpw34ZYfIE039kVX+TrcKgX4qSSZQOeGZiOfrSuNLcmNZm1Ci5rZzpupkcZtpkVj+nwnJx8s0A1aJhoFwkQHefyW0uYxwPFbPHJgf8o+9MuqRiTTLtCOJIZI/f8TEfX60O1tLaNLSGYDupXntGGOO5MSqx9eOKvKuXIFifSJZ7a21rRZ4wqvDqdmlxD6CVkDA59jg1nOm2gh0VrOQkS215NvDAAhxL1X3wfrTX2M1ARRaj2duZD8XpM8rwBhtZ7V2LgqD6Zzjyz7cVtVt1ttRuCi4S4/F2geFnbhhjp6Ec1jN+KoNp+JgyGMxJlsqg5LA9WPPQ8Uv61cWu/Jt45NiFFk3FSCcn9JI9cUx3Fwncqgzk+oyQRnOQfMUjXSzatqdvptkB3txKI2ZANsa/qY49Bknn+tYwx3OxrUTSj+yfS9F1e+i/ndvZrLYWd0u+Ji5Myxnc7bVG4oOM4B8/SmnRbKOaPUtVuLpYtQ+Md0sopGto1gnZ5JVheD8VUxlgRuXHkc8aDo9hDpljZ2duu2O3iSNR58Dqfc9T86qXuirG0txZW8EqSBhPZygIrBmDObaYDchb9Q5U+Y5zTDtu/AgqpryUpjcW1voem6cTbXerXcF7PvhgmmhSfO1VyNgMaK7BgP9yP8AFSb27mnv9aEXdyw2u9LJbmW2dzHaWmZJGgCg53sW6YLbFHTq5SXsQ1XX76a2iTV9NtZINHSERSXFxBdRIVPcxqJW7sjnxNgM2MVlMshP8ydZYgQ40ywtVYqW2nfLe3B/MT1JLZJZ/SPFGi0+UA2NOmgnpmnSSzw311B3UVzO3wltIhR1hQhVeQnBPAJ/fzrTtHSOAxFRtVbeO5GOBsZjGwx7Zz/6pI0C2uNRn060D5MMCxsV3EQwAlnbDZPiJIX5e1Pl29tZapoKE7UuDLpjLxjZKm+Pd5/mUAfOk7bluHpxW3YvosX1qFubkjhLhe/46bsBW/pn61RM2nwiSa9EYtYWzcPMVCJE4XLkn0z86L3G5tPil8XeQK8R6bjkFOfsKzXtbeP8D8Llyty0a3QEbF8RtuEZIGPIH6VMkUsi/ZnCt2N2WtFs7iLtnryXklwJIbWe6dxLIFcCZI41DHxFMYI5o3NNClxK0QBPetJJg/nc4OSzZJNVohIdG0nXLle6v7zTLXS7kMoJYWssjxsdpzlvDn5VzawtOVKxzuzkEtgKM9ehqZHUtqOz6ZhWx5sj/Qag7191wQVVIZQg9Gfkf1qjLKyyyAeTHOeefOiBWVYEGUjijJdyxyzkDAyT6n2oM7ICSZA5JOcHjPn0rb4VDelipylIsiUkk9PlUqHOcelU1Z+qqPsTU6GY/pHSsjU4UUmTPSoWTFXCoBrlkUg1hoejkooEFeccedSIw4qR0GMVAV2nihsZT3otqwIwen71UvLYOhI544IqeMnpVjaCDnzxmo1wAUninaFKZCCyn7Ut3Q+GuYyeAsqOp9s056jEiEsOucUq6zGvdh/NSP34rON1Ovs6OvXv6N5V3Hk0rsxdKyKnXinaJtwFZN2SuJWFrk8mIE/TArUrQsyISeuKPpZbW4HgPVcSU1kXlWXwa9r4L717t966Z56zmqd+jPbT7c7lQsvzAzV3aK5ZAQR5Yxg9PrWZK1RqMqaZhOrXTS6ysm8squYkZskZBGTgGtS7KAx9m+zykHcbSMNnghjwelZr2psINN1K0t4MlG1iZk34LJHKkR7vPmBnjNaZ2Tjz2e0HLMSsTnLckkTScmlsca4HtQ1LkM3S7o7dNu5XuYFYDptDbuftSZ26vktdQ7ORuyi3aPUJLvc2PA5iQH9j/wCGntow3dZ8nVx8xmso/ituWaKQNkG10+02kAhVklup3ZT5EmNAfYUeUFJV9iUJbZJga01Ca5ukuB+BrVm4jWWPj4kW7FBvU8bsYHuOuQSQ2w6rY6xGsFwrQXCEAFQxC88gj823rjg46c9aytJpWa0kDENJGjE55DAAZBrQtH0jTL6GKa+jkuGZjG4MrRqWAB3/AIWGz/xUlki06OhFxcbfgLXCaDHG8eoBVgcZe5+KtliA5H5SRPn0wM1B2Y0vs38RLeaLHO1vl0a5vFYTzSb+QpfkIOPn1PsbubfT7C2lNrZWyGKBmU7Ax/KTyXyasdn7dFsbY58Uid85AA3O/iJwOPOouHsB3acg1GoAFetmu1THnXhXkc02uhfyC73RdL1Ehru2ilcY2syjcPdWHIpO7R6BBbW7fBG6ku7iaKBYxcHmIklgzyngeRPPHkc1o5Twkg+lDFtYri9Z5ACbcB4yQDhmyMil8kOVtGMWVpO+gb2b0RdFsipKPe3GHuXRW7tCBwq7/FgeWfnxmqXaKZUm0dU8U41rTmL9SGWZc59uSKcGQKjAHAUcfP1pI1PB1bRlIznUoXyc9VkQf3rGb4JRQbTfyScn9DZcKRpuqrGoZh8T3StnDPnwLxz1wKzV9MksLe2OomSfVd7oEhKiGGSYiZmkZ85IzjhD068VpOtSS2ujarNC5WVIZWRx1Vyc7h8qzCKIRz2zlmeaa1EskshLOc5YjLe9TUS2tIf9H0T1Tcm/imO8cinRLie7YSiK9DRiKPAA2ohRQOuOfKqTXbc7SI48DYoyGYEdWwP2z9qmuC0PZnSlhYoLho3k5yx37pCMmgduhmVWZ28JK4znIHPJNYlKqS+jraLSxnCc31uaCEs0lyRvkYooAWMHCDHsPOvAm3oqDPyzXiqq42ipDuOMkf8AKK1/Y5tUfjHojKzk8MPkDXyhwTlmH1NfZUnBUfMZFTKh8nYfPmpRbddn/9k="/>
        </div>
        <div class="card-cover-title love">
          <div class="card-cover-media-button"></div>
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title
            1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title
            1title 1 title 1
          </div>
        </div>
      </div>
    </div>
    <div class="card   ">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        </div>
        <div class="card-cover-title love linear to-info">
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title
            1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title
            1title 1 title 1
          </div>
        </div>
      </div>
    </div>
    <div class="card  ">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://tse2-mm.cn.bing.net/th/id/OIP-C.nW1yxAOXKGqlDLO_okvW0gHaE7?w=276&h=183&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div class="card-cover-title  ">
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title
            1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title
            1title 1 title 1
          </div>
        </div>
      </div>
    </div>
    <div class="card   ">
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://tse3-mm.cn.bing.net/th/id/OIP-C.xm1YV1tgZlMt5koW5lV9FQHaFj?w=241&h=181&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div class="card-cover-title love linear to-info top">
          <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title
            1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title
            1title 1 title 1
          </div>
        </div>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://tse3-mm.cn.bing.net/th/id/OIP-C.29n1ZJO8drUB05nYulfyzAHaE7?w=272&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>
      <div class="card-title">title 1 title 1 title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title
        1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1
      </div>
    </div>
    <div class="card    ">
      <div class="row-flex row-space-bottom">
        <img class="user-avatar small cir" alt=""
             src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
        <div class="row-align-middle row-flex row-space-left">
          <span class="middle-auto">Cascada</span>
        </div>
      </div>
      <div class="card-cover-box">
        <div class="card-cover-image-list">
          <img class="card-cover-image" alt=""
               src="https://tse1-mm.cn.bing.net/th/id/OIP-C.vxYKG47MtJZHnLyeACzM-QHaD7?w=335&h=180&c=7&r=0&o=5&pid=1.7"/>
        </div>
        <div class="card-cover-media-button"></div>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://tse1-mm.cn.bing.net/th/id/OIP-C.cYE8mxCgRRrktBbDzwdoMwHaE7?w=298&h=198&c=7&r=0&o=5&pid=1.7"/>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://tse2-mm.cn.bing.net/th/id/OIP-C.Gi9ACDar21iSZmxbkx1NtAHaE8?w=247&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://tse2-mm.cn.bing.net/th/id/OIP-C.Gi9ACDar21iSZmxbkx1NtAHaE8?w=247&h=180&c=7&r=0&o=5&pid=1.7"/>
        <img class="card-cover-image" alt=""
             src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
      </div>
      <div class="card-title">title 123</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
      <div class="card   ">
        <div class="card-cover-box">
          <div class="card-cover-image-list">
            <img class="card-cover-image" alt=""
                 src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
          </div>
          <div class="card-cover-title love linear to-info">
            <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title
              1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title
              1title 1 title 1
            </div>
          </div>
        </div>
      </div>
      <div class="card  perfect transparent ">
        <div class="card-cover-box">
          <div class="card-cover-image-list">
            <img class="card-cover-image" alt=""
                 src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
          </div>
          <div class="card-cover-title love linear to-info">
            <div class="card-cover-title-inner">title 1 title 1title 1 title 1title 1 title title 1 title 1title 1 title
              1title 1 title 11title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title 1title 1 title
              1title 1 title 1
            </div>
          </div>
        </div>
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you
        .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .Nice to meet you .
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
      <div class="card-footer-menu">
        <div class="card-footer-menu-item">add</div>
        <div class="card-footer-menu-item">add</div>
        <div class="card-footer-menu-item">add</div>
        <div class="card-footer-menu-item">add</div>
      </div>
    </div>
    <div class="card    ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image  " alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image  " alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
        <div class="card-cover-image-mask">+2</div>
      </div>
      <div class="card-title">title 1 title 1</div>
      <div class="card-desc">此处设计最多4张图片，超过的无需js隐藏，但是为了性能优化建议js隐藏。dark black mask info more
        picture numbers need js to use
      </div>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card">
      <div class="card-title"> Cascada - Everytime We Touch
      </div>
      <pre class="card-desc long">
Cascada - Everytime We Touch
I still hear your voice when you sleep next to me
I still feel your touch in my dreams my dreams
Forgive me my weakness
But I don't know why
Without you it's hard to survive
        'Cause everytime we touch
        I get this feeling
        And every time we kiss
        I swear I can fly
        Can't you feel my heart beat fast
        I want this to last
        Need you by my side
        'Cause everytime we touch
        I feel the static
        And everytime we kiss
        I reach for the sky
        Can't you hear my heart beat so

        I can't let you go

        Want you in my life

        Your arms are my castle

        Your heart is my sky

        They wipe away tears that I cry I cry

        The good and the bad times

        We've been through them all

        You make me rise when I fall
      </pre>
      <div class="row-flex row-space-top">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar mini cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card blank  ">
      此处适合多张图片横向滚动，大图展示其中一个。。
    </div>
    <div class="card">
      <div class="row-flex row-space-bottom ">
        <img class="user-avatar small cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-align-middle row-flex row-space-left">
          <span class="middle-auto">Cascada</span>
        </div>
      </div>
      <div class="card-goods">
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
        <div class="card-goods-item"></div>
      </div>
      <div class="card-info row-space-top">这只是一个测试~this is just a test~</div>
    </div>
    <div class="card       ">
      <div class="row-flex   ">
        <img class="user-avatar    " alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-align-middle row-flex row-space-left">
          <span class="middle-auto">Cascada</span>
        </div>
      </div>
    </div>
    <div class="card   ">
      <div class="card-cover-box">
        <img class="card-cover-image" alt=""
             src="https://img1.baidu.com/it/u=3614176013,2336739411&fm=253&fmt=auto&app=138&f=JPEG?w=448&h=252"/>
      </div>
      <div class="row-flex  row-space-top ">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar    " alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
      <div class="row-flex  row-space-top ">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar    " alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
      <div class="row-flex  row-space-top ">
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-right">
          <span class="middle-auto">Cascada</span>
        </div>
        <img class="user-avatar    " alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
      </div>
    </div>
    <div class="card">
      <div class="row-flex   ">
        <img class="user-avatar small cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-align-middle row-flex row-space-left">
          <span class="middle-auto">Cascada</span>
        </div>
        <div class="row-f1"></div>
        <div class="row-align-middle row-flex row-space-left">
          <button class="button cir auto small love">+</button>
        </div>
      </div>
    </div>
    <div class="card blank  ">
      我打算的设计，元素左滑动的时候，右边显示一些操作，
    </div>
    <div class="card-row">
      <div class="card">
        <div class="row-flex   ">
          <img class="user-avatar small cir" alt=""
               src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
          <div class="row-align-middle row-flex row-space-left">
            <span class="middle-auto">Cascada</span>
          </div>
          <div class="row-f1"></div>
        </div>
      </div>
      <div class="card-button row-align-middle">
        <button class="button auto cir error space">D</button>
        <button class="button auto cir warn space">P</button>
        <button class="button auto cir secondary space">C</button>
      </div>
    </div>
    <div class="card">
      row-flex 需要扩展，否则 后面的名字过长会导致样式崩坏
    </div>
    <div class="card">
      <div class="card-info  "> row-flex 需要扩展，否则 后面的名字过长会导致样式崩坏
      </div>
    </div>
    <div class="card blank  ">
      我打算的设计， 左滑动
    </div>
    <div class="blank card  ">
      添加好友：
    </div>
    <div class="card blank  ">
      我打算的设计， 左滑动
    </div>
    <div class="card-box">
      <div class="card inline">
        <div class="row-flex   ">
          <img class="user-avatar small cir" alt=""
               src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
          <div class="row-align-middle row-flex row-space-left">
            <span class="middle-auto">Cascada</span>
          </div>
          <div class="row-f1"></div>
          <div class="row-align-middle row-flex row-space-left">
            <button class="button cir auto small love">+</button>
          </div>
        </div>
      </div>
      <div class="card inline">
        <div class="row-flex   ">
          <img class="user-avatar small cir" alt=""
               src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
          <div class="row-align-middle row-flex row-space-left">
            <span class="middle-auto">Cascada</span>
          </div>
          <div class="row-f1"></div>
          <div class="row-align-middle row-flex row-space-left">
            <button class="button cir auto small love">+</button>
          </div>
        </div>
      </div>
      <div class="card inline">
        <div class="row-flex   ">
          <img class="user-avatar small cir" alt=""
               src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
          <div class="row-align-middle row-flex row-space-left">
            <span class="middle-auto">Cascada</span>
          </div>
          <div class="row-f1"></div>
          <div class="row-align-middle row-flex row-space-left">
            <button class="button cir auto small love">+</button>
          </div>
        </div>
      </div>
    </div>
    <div class="card blank  ">
      我打算的设计， 左滑动
    </div>
    <div class="blank card  ">
      添加好友：
    </div>
    <div class="card-box horizontal  ">
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card blank">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>


    </div>
    <div class="card-box horizontal tight ">
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>


    </div>
    <div class="card-box horizontal  ">
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>
      <div class="card  ">
        <img class="user-avatar big cir" alt=""
             src="https://img1.baidu.com/it/u=500910082,1497364170&fm=253&fmt=auto&app=138&f=JPEG?w=294&h=220"/>
        <div class="row-center row-space-vertical">我的好友</div>
        <div class="row-center row-space-vertical">
          <button class="button love small pill">Add</button>
        </div>
      </div>


    </div>
    <div class="card blank  ">
     计数器垃圾堆
    </div>
    <kl-number-box size="mini" v-model="num"/>
    <kl-number-box size="small" v-model="num"/>
    <kl-number-box input-type="glass" v-model="num"/>
    <kl-number-box size="big" v-model="num"/>
    <kl-number-box size="bigger" type="primary" input-type="pill white" role="cir" v-model="num"/>
    <kl-number-box size="huge" v-model="num"/>
    <kl-number-box size="large" v-model="num"/>

  </div>
</template>
<script>
import KlNumberBox from "@/components/klNumberBox";

export default {
  name: "cC",
  components: {KlNumberBox},
  data() {
    return {
      num: 0,
    }
  },
}
</script>