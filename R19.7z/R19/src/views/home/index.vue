<template>
  <div class="page-m">
    <div class="card blank font-size-mini">
      卡片组件Group
      <div  class="form-info error show">
       </div>
    </div>
    <div class="card-list">
      <div class="card">
        <div class="card-title">#你的推荐#</div>
        <div class="card-desc">你的推荐 你的推荐 你的推荐 你的推荐</div>
      </div>
      <div class="card">
        <div class="card-title">#你的推荐#</div>
        <div class="card-desc">你的推荐 你的推荐 你的推荐 你的推荐</div>
      </div>
      <div class="card">
        <div class="card-title">#你的推荐#</div>
        <div class="card-desc">你的推荐 你的推荐 你的推荐 你的推荐</div>
      </div>
      <div class="card">
        <div class="card-title">#你的推荐#</div>
        <div class="card-desc">你的推荐 你的推荐 你的推荐 你的推荐</div>
      </div>
      <div class="card ">
        <div class="card-title">你可能认识</div>
        <div class="card-box tight horizontal">
          <div class="card inline">
            <div class="row-flex">
              <div class="row-space-right">
                <img class="user-avatar small cir" alt=""
                     src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-align-middle row-flex  ">
                <span class="middle-auto">Cascada</span>
              </div>
              <div class="row-align-middle row-flex row-space-left">
                <button class="button cir auto small love">+</button>
              </div>
            </div>
          </div>
          <div class="card inline">
            <div class="row-flex">
              <div class="row-space-right">
                <img class="user-avatar small cir" alt=""
                     src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-align-middle row-flex  ">
                <span class="middle-auto">Cascada</span>
              </div>
              <div class="row-align-middle row-flex row-space-left">
                <button class="button cir auto small love">+</button>
              </div>
            </div>
          </div>
          <div class="card inline">
            <div class="row-flex">
              <div class="row-space-right">
                <img class="user-avatar small cir" alt=""
                     src="https://tse4-mm.cn.bing.net/th/id/OIP-C.ZNqmK6S5PUF5OxYm48wREAHaEL?w=309&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-align-middle row-flex  ">
                <span class="middle-auto">Cascada</span>
              </div>
              <div class="row-align-middle row-flex row-space-left">
                <button class="button cir auto small love">+</button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <div class="card blank font-size-mini">
      其实这个不是很科学，应该加上是纯的滚动不需要滚动条，让电脑端像手机一样。这一层要禁止拖拽才能实现伪拖拽效果。
      BUG：滚动过快会丢失，到顶端会选取全文。
      不适合在这种小的上弄。
      <div  class="form-info error show">
        此已经暂时弃坑,让我好好想一想，这个暂时用的v的自定义命令
      </div>
    </div>
    <kl-nav/>
    <div class="card blank font-size-mini">
      看到Youtube的设计是这样的，滚动滚轮的时候左右滚动一个标签单位，这个滚动使用变形像素实现的，看起来更加安全。如果更多信息还有就会有个渐变在后面，滚动最后一个格子是以最后一个为标准的。
    </div>
    <div class="card blank font-size-mini">

        打算改良让它像正常的原生一样，鼠标离开方块也不会停止滚动，停止滚动绑定到window.mouseup 上以及离开浏览器窗口。
     </div>
    <div class="card blank font-size-mini">
      聊天室，不过现实种不会这么花
      <div  class="form-info error show">
      </div>
    </div>
    <div class="glass-block info to-love linear" style="padding: 20px 0">
      <div class="chart-bubble-box me-say">
        <div class="chart-bubble success">Una cascada de noticias nos llegó a la redacción.
          大量消息纷纷传到我们编辑部。
          <button class="button  glass" @click="$router.push({ path: '/post/i' })"> post i
            <span class="badge right-top warn bigger glass">12</span>
            <i class="dot warn pulse small auto"></i>
          </button>
          <br/>
          <button class="button  glass" @click="$router.push({ path: '/login' })"> login
            <i class="dot warn pulse mini"></i>
            <span class="dot right-top warn bigger glass"></span>
          </button>
          2.En la fiestas se divisaban cascadas de fuegos artificiales.
          在晚上的庆祝活动里，人们看到烟火像瀑布那样倾斜下来。
          3.En este sentido, resulta oportuno adoptar salvaguardias adecuadas para contrarrestar el efecto de cascada
          con
          vistas a su eventual eliminación.
          在这一方面，我们应该采取充分的障措施来抵消“连带效应”，以期最终消除它。
          4.La adición de miembros permanentes también tendría consecuencias indirectas importantes y adversas por medio
          de lo que se denomina el efecto de cascada.
          增加事国会通过所谓连串效应而产生重大、不利的间后果。
        </div>
      </div>
      <div class="chart-bubble-box other-say">
        <div class="chart-bubble love ">sdfsdfsdf</div>
      </div>
      <div class="chart-bubble-box other-say">
        <div class="chart-bubble secondary ">sdfsdfsdf</div>
      </div>
      <div class="chart-bubble-box other-say">
        <div class="chart-bubble warn ">sdfsdfsdf</div>
      </div>
      <div class="chart-bubble-box other-say">
        <div class="chart-bubble error ">sdfsdfsdf</div>
      </div>
      <div class="chart-bubble-box other-say">
        <div class="chart-bubble primary ">sdfsdfsdf</div>
      </div>
      <div class="chart-bubble-box other-say">
        <div class="chart-bubble primary  linear to-love">sdfsdfsdf</div>
      </div>
      <div class="chart-bubble-box me-say  ">
        <div class="chart-bubble  ">sdfsdfsdf</div>
      </div>
    </div>
    <!-- 这个注释写道外面导致动画混乱
       <auto-mini-menu v-show="false"/>-->
  </div>

</template>
<script>
import AutoMiniMenu from "@/views/cop/autoMiniMenu";
import KlButtonWave from "@/components/klButtonWave";
import KlNav from "@/components/klNav";

export default {
  name: "aA",
  // eslint-disable-next-line vue/no-unused-components
  components: {KlNav, KlButtonWave, AutoMiniMenu}
}
</script>