<template>
  <div class="page-m row-flex row-column"   style="overflow: hidden;padding-bottom: 0">
    <div class='row-flex row-f1' style="overflow: hidden">
      <div class="goods-filter short" style="overflow: scroll">
        <div class="goods-filter-item">drink</div>
        <div class="goods-filter-item active">fruit</div>
        <div class="goods-filter-item">breadbreadbreadbread</div>
        <div class="goods-filter-item">food</div>        <div class="goods-filter-item">drink</div>
        <div class="goods-filter-item active">fruit</div>
        <div class="goods-filter-item">breadbreadbreadbread</div>
        <div class="goods-filter-item">food</div>
        <div class="goods-filter-item">drink</div>
        <div class="goods-filter-item active">fruit</div>
        <div class="goods-filter-item">breadbreadbreadbread</div>
        <div class="goods-filter-item">food</div>
        <div class="goods-filter-item">drink</div>
        <div class="goods-filter-item active">fruit</div>
        <div class="goods-filter-item">breadbreadbreadbread</div>
        <div class="goods-filter-item">food</div>
        <div class="goods-filter-item">drink</div>
        <div class="goods-filter-item active">fruit</div>
        <div class="goods-filter-item">breadbreadbreadbread</div>
        <div class="goods-filter-item">food</div>

      </div>
      <div class="row-f1"  style="overflow: scroll">
        <div class="card-list">
          <div class="card">
            <div class="row-flex">
              <div class="">
                <img class="user-avatar big round" alt=""
                     src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-f1 row-space-left row-column row-flex ">
                <div class="card-title">商品名称1</div>
                <div class="card-desc r2">商品名称1商品名称1商品名称1商品名称1商品名称1商品名称1</div>
                <div class="row-f1"></div>

                <div class="row-flex">
                  <div class="row-f1"></div>
                  <div class="row-align-middle">
                    <button class="cir small auto button primary">+</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="row-flex">
              <div class="">
                <img class="user-avatar big round" alt=""
                     src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-f1 row-space-left row-column row-flex ">
                <div class="card-title">商品名称1</div>
                <div class="card-desc r2">商品名称1商品名称1商品名称1商品名称1商品名称1商品名称1</div>
                <div class="row-f1"></div>

                <div class="row-flex">
                  <div class="row-f1"></div>
                  <div class="row-align-middle">
                    <button class="cir small auto button primary">+</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="row-flex">
              <div class="">
                <img class="user-avatar big round" alt=""
                     src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-f1 row-space-left row-column row-flex ">
                <div class="card-title">商品名称1</div>
                <div class="card-desc r2">商品名称1商品名称1商品名称1商品名称1商品名称1商品名称1</div>
                <div class="row-f1"></div>

                <div class="row-flex">
                  <div class="row-f1"></div>
                  <div class="row-align-middle">
                    <button class="cir small auto button primary">+</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="row-flex">
              <div class="">
                <img class="user-avatar big round" alt=""
                     src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-f1 row-space-left row-column row-flex ">
                <div class="card-title">商品名称1</div>
                <div class="card-desc r2">商品名称1商品名称1商品名称1商品名称1商品名称1商品名称1</div>
                <div class="row-f1"></div>

                <div class="row-flex">
                  <div class="row-f1"></div>
                  <div class="row-align-middle">
                    <button class="cir small auto button primary">+</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="row-flex">
              <div class="">
                <img class="user-avatar big round" alt=""
                     src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-f1 row-space-left row-column row-flex ">
                <div class="card-title">商品名称1</div>
                <div class="card-desc r2">商品名称1商品名称1商品名称1商品名称1商品名称1商品名称1</div>
                <div class="row-f1"></div>

                <div class="row-flex">
                  <div class="row-f1"></div>
                  <div class="row-align-middle">
                    <button class="cir small auto button primary">+</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="row-flex">
              <div class="">
                <img class="user-avatar big round" alt=""
                     src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-f1 row-space-left row-column row-flex ">
                <div class="card-title">商品名称1</div>
                <div class="card-desc r2">商品名称1商品名称1商品名称1商品名称1商品名称1商品名称1</div>
                <div class="row-f1"></div>

                <div class="row-flex">
                  <div class="row-f1"></div>
                  <div class="row-align-middle">
                    <button class="cir small auto button primary">+</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="row-flex">
              <div class="">
                <img class="user-avatar big round" alt=""
                     src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-f1 row-space-left row-column row-flex ">
                <div class="card-title">商品名称1</div>
                <div class="card-desc r2">商品名称1商品名称1商品名称1商品名称1商品名称1商品名称1</div>
                <div class="row-f1"></div>

                <div class="row-flex">
                  <div class="row-f1"></div>
                  <div class="row-align-middle">
                    <button class="cir small auto button primary">+</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="row-flex">
              <div class="">
                <img class="user-avatar big round" alt=""
                     src="https://tse3-mm.cn.bing.net/th/id/OIP-C.x_am85nlZML9vPWCsYGSzwHaLh?w=115&h=180&c=7&r=0&o=5&pid=1.7"/>
              </div>
              <div class="row-f1 row-space-left row-column row-flex ">
                <div class="card-title">商品名称1</div>
                <div class="card-desc r2">商品名称1商品名称1商品名称1商品名称1商品名称1商品名称1</div>
                <div class="row-f1"></div>

                <div class="row-flex">
                  <div class="row-f1"></div>
                  <div class="row-align-middle">
                    <button class="cir small auto button primary">+</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

</template>
<script>
import AutoMiniMenu from "@/views/cop/autoMiniMenu";
import KlButtonWave from "@/components/klButtonWave";

export default {
  name: "hShop",
  // eslint-disable-next-line vue/no-unused-components
  components: {KlButtonWave, AutoMiniMenu}
}
</script>
