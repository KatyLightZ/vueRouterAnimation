<template>
  <div class="cover glass">
    <div @click="$router.go(-1)" class="back">back</div>


    <div class="row-flex  ">
      <div class="row-flex-label white">搜索</div>
      <div class="row-f1">
        <div class="form-input-box">
          <input class="form-input glass" v-model="queryString"/>
          <div class="form-input-suf">
            <button class="button love"  @click="$router.replace({ path: '/search/'+queryString })">query</button>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>
<script>
export default {
  name: "bB",
  data(){
    return{
      queryString:''
    }
  }
}
</script>
