<template>
<!--  <keep-alive>  </keep-alive>-->
    <transition :name="$route.meta.transition">
      <router-view class="page"
                   :key="$route.meta.mutter"/>
    </transition>
</template>
<script>
export default {
  name: 'App',
  components: {},
  data() {
    return {
      pageKey: "",
      pastParam: {}
    }
  },
  mounted() {
    const resize = () => {
      document.body.style.height = window.innerHeight + "px";
      if (window.innerWidth > 502) {
        document.body.classList.add('glass')
      } else {
        document.body.classList.remove('glass')
      }
    }
    resize();
    window.onresize = () => {
      resize();
    }
  },
}
</script>
<style lang="scss">
@import "assets/scss/basic.scss";
@import "assets/scss/ani.scss";
</style>
