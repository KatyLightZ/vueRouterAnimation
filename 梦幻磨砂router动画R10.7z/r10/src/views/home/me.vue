<template>
  <div class="page-m">
    <div>
<input v-model="text"/>
      <div>
        <button
            :style="{
          opacity:index===buttonHollow?1:.5
            }"
            :class="['button small',item]" v-for="(item,index) in buttonHollowArr" :key="index"
            @click="buttonHollow=index">{{ item }}
        </button>
      </div>

      <div>
        <button
            :style="{
          opacity:index===buttonRole?1:.5
            }"
            :class="['button small  ',item]" v-for="(item,index) in buttonRoleArr" :key="index"
            @click="buttonRole=index">{{ item }}
        </button>
      </div>
      <div>
        <button :style="{
          opacity:index===buttonType?1:.5
            }" :class="['button small  ',item]" v-for="(item,index) in buttonTypeArr" :key="index"
                @click="buttonType=index">{{ item }}
        </button>

      </div>
      <div>
        <button :style="{
          opacity:index===buttonWidth?1:.5
            }" :class="['button small hollow ',item]" v-for="(item,index) in buttonWidthArr" :key="index"
                @click="buttonWidth=index">{{ item }}
        </button>
      </div>
      <div>
        <button :style="{
          opacity:index===buttonSize?1:.5
            }" :class="['button   hollow ',item]" v-for="(item,index) in buttonSizeArr" :key="index"
                @click="buttonSize=index">{{ item }}
        </button>

      </div>
      <div>
        <button :style="{
          opacity:index===buttonS?1:.5
            }" :class="[' ',item]" v-for="(item,index) in buttonSArr" :key="index" @click="buttonS=index">{{
            item
          }}
        </button>

      </div>
      <div>
        <button :style="{
          opacity:index===buttonFull?1:.5
            }" :class="['button',item]" v-for="(item,index) in buttonFullArr" :key="index" @click="buttonFull=index">{{
            item
          }}
        </button>

      </div>

    </div>
    <div>
      <div>show you</div>
      <div  :style="{
        display:buttonFull>1?'flex':''
      }">
        <button :class="[

          buttonHollowArr[buttonHollow],buttonSArr[buttonS],
          buttonRoleArr[buttonRole],
          buttonTypeArr[buttonType],
          buttonWidthArr[buttonWidth],
          buttonSizeArr[buttonSize],
         buttonFullArr[buttonFull],
      ]">{{text}}
        </button>
        <div style="flex: 1">f1</div>
        <button :class="[

          buttonHollowArr[buttonHollow],buttonSArr[buttonS],
          buttonRoleArr[buttonRole],
          buttonTypeArr[buttonType],
          buttonWidthArr[buttonWidth],
          buttonSizeArr[buttonSize],
         buttonFullArr[buttonFull],
      ]">{{text}}
        </button>


      </div>
    </div>
    <div class="box">avatar account</div>
    <div class="title">i have to do something</div>
    <div class="box">need to do something</div>
    <div class="title">my date</div>
    <div class="box">date</div>
    <swiper-nav/>
    <auto-mini-menu title="更多应用"
                    :list="[
      {
        label:'电脑版'
      },
            {
        label:'电脑版'
      },
            {
        label:'电脑版'
      },
            {
        label:'电脑电脑版电脑版电脑版电脑版电脑版电脑版版'
      },
            {
        label:'电脑版'
      },
            {
        label:'电脑版'
      },
  ]"
    ></auto-mini-menu>
  </div>
</template>
<script>
import AutoMiniMenu from "@/views/cop/autoMiniMenu";
import SwiperNav from "@/views/cop/swiperNav";

export default {
  name: "dD",
  components: {SwiperNav, AutoMiniMenu},
  data() {
    return {
      buttonTypeArr: ['normal', 'info', 'love', 'error', 'warn', 'success', 'primary'],
      buttonSizeArr: ['mini', 'small', 'normal', 'big', 'bigger', 'huge', 'large'],
      buttonRoleArr: ['normal', 'cube', 'cir', 'round', 'pill'],
      buttonHollowArr: ['normal', 'hollow'],
      buttonWidthArr: ['thin', 'normal', 'stronger'],
      buttonSArr: ['button', 'button-text'],
      buttonFullArr: ['normal', 'full','f1','f2','f3','f4','f5'],
      buttonType: 0,
      buttonSize: 0,
      buttonRole: 0,
      buttonHollow: 0,
      buttonWidth: 0,
      buttonS: 0,
      buttonFull: 0,
      text: '0',
    }
  },

}
</script>