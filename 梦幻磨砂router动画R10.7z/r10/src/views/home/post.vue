<template>
  <div class="page-m">

    <div class="title">something not only</div>
    <div class="box">
      <div @click="$router.push({ path: '/post/i' })">this is a child to new post i</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/asdfdfs' })">asdfdfs</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/fdsf' })">sdf</div>
    </div>
    <div class="box">
      <div @click="$router.push({ path: '/post/i' })">this is a child to new post i</div>
    </div>

  </div>
</template>
<script>
export default {
  name: "cC"
}
</script>