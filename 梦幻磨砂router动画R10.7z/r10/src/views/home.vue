<template>
  <div>

    <glass-table v-model:visible="leftShow"/>
    <div class="nav-header">
      <div class="nav-header-icon left" @click="showT">12</div>
      {{$route.meta.title}}
      <div class="nav-header-icon right" ref="rightPup">
        <span @click="rightShow=true">s</span>
        <pup-set v-model:visible="rightShow" ref="popSet"/>
      </div>
    </div>
    <transition :name="$route.meta.transition">
      <router-view   :key="$route.fullPath"/>
    </transition>
    <div class="menu-ball"  v-show="$route.meta.addBtn"
         @click="switchBall($route.meta.addBtn)">{{$route.meta.addBtn}}</div>
<!--    <tab-bar :list="list"/> $router.push({ path: '/send' })-->
    <tab-ball :list="list"/>
  </div>
</template>
<script>
import GlassTable from "@/views/glassTable";
import TabBar from "@/views/layout/tabbar";
import TabBall from "@/views/layout/tabBall";
import PupSet from "@/views/layout/pupSet";
import menuBall from "@/views/enum/set/menuBall";
 export default {
  name: "homeA",
  // eslint-disable-next-line vue/no-unused-components
  components: {  PupSet, TabBall, TabBar, GlassTable},
  data() {
    return {
      leftShow: false,
      rightShow: false,
      list: [
        {
          name: "home",
          path: '/home/index',
        },
        {
          name: "search",
          path: '/home/search',
        },
        {
          name: "post",
          path: '/home/post',
        },
        {
          name: "myInfo",
          path: '/home/me',
        },
      ]
    }
  },
  methods: {
    showT() {
      this.leftShow = true;
    },
    switchBall(e){
      menuBall[e].do();
    }
  },
  mounted() {
    this.$refs.popSet.setMe(this.$refs.rightPup)
  }
}
</script>
