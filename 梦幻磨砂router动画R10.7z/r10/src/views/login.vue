<template>
<div>
  登录页面：
  <button  @click="$router.push({ path: '/home/index' })">登录</button>
  <button  @click="$router.push({ path: '/register' })">注册</button>
  <div style="height: 400px;background-color: rgba(255,255,255,0.65)"></div>
</div>
</template>
<script>
export default {
  name: "loginC"
}
</script>
