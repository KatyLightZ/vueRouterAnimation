<template>
  <div class="cover">
    <div @click="$router.go(-1)" class="back">back</div>
    <div class="title">title</div>
    <div class="caption">
      <p>
        postId :{{ $route.params.i }}</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "postA"
}
</script>
