<template>
<div class="swiper-nav-back">
  <div class="swiper-nav-box">
    <div class="swiper-nav-item">

      <span>这是一个swiper，用来回显用户订阅消息更具群体，可以是文字模板或者单张图片
    大小自动大小，是100：40的，js操作</span>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: "swiperNav"
}
</script>

<style>
.swiper-nav-back{
  width: 100%;
  padding-bottom:40%;
  position: relative;
}
.swiper-nav-box{
  position: absolute;
  left: 0;
  bottom: 0;
  right: 0;
  top: 0;
  background-color: rgba(255, 255, 255, 0.21);
}
.swiper-nav-item{
  border-radius: 10px;
  position: absolute;
  left: 10px;
  bottom: 10px;
  right:10px;
  top:10px;
  justify-items: center;
  display: grid;
  align-items: center;
  padding: 10px;
  background-color: rgba(255, 255, 255, 0.66);
}
</style>