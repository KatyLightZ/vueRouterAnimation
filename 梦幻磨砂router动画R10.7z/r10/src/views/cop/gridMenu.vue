<template>

  <div class="container">
    <div class="containerZ">
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
      <div class="i"></div>
    </div>
  </div>
<!--       <div class="r">
        <div class="i"></div>
        <div class="i"></div>
        <div class="i"></div>
      </div>
      <div class="r">
        <div class="i"></div>
        <div class="i"></div>
        <div class="i"></div>
      </div>
      <div class="r">
        <div class="i"></div>
        <div class="i"></div>
        <div class="i"></div>
      </div> -->
</template>
<script>
export default {
  name: "gridMenu"
}
</script>
<style scoped>
.container {
  width: 100%;
  padding-bottom: 100%; /* padding百分比相对父元素宽度计算 */
  height: 0;


  position: relative;
}
.containerZ {

  flex-flow: column;
  overflow: hidden;
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  background: lightseagreen;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: repeat(3, 1fr);
  gap: 10px 10px;
  /* justify-items/align-items设置单元格内容的水平/垂直位置 */
  /* justify-items: center; */
  /* align-items: center; */
  /* justify-content/align-content设置的是内容区域在整个Grid容器中的位置 */
  /* justify-content: space-between ; */
  grid-template-areas: 'a b c'
            'd e f'
            'g h i';
}
.i {
  background-color: white;
}
/*.containerZ {
  display: flex;
  flex-flow: column;
  overflow: hidden;
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
}

.i {
  flex: 1;
  background-color: white;
  margin-left: 10px;
}

.r > .i:first-child {
  margin-left: 0;
}

.r:first-child {
  margin-top: 10px;
}

.r:last-child {
  margin-bottom: 10px;
}

.r {
  margin: 5px 10px;
  overflow: hidden;
  flex: 1;
  display: flex;
}*/


</style>