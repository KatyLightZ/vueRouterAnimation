<template>
  <div class="auto-mini-menu-title">
    {{title}}
  </div>
  <div class="auto-mini-menu">
<!--    <div v-for="(item,index) in list" :key="index" class="auto-mini-menu-item" :style="{
      width:cubeSide,
      height:cubeSide,
         }">
      <div class="auto-mini-menu-item-cube"
           :style="{
      width:cirSide,
      height:cirSide,
      lineHeight:cirSide,
         }"
      >{{ item.label }}
      </div>
    </div>-->
    <div class="auto-mini-menu-t" :style="{
      width:nSide,

         }"  v-for="(item,index) in list" :key="index">
      <div class="auto-mini-menu-item-t" :style="{
      width:cubeSide,
      height:cubeSide,
         }">
        <div class="auto-mini-menu-item-cube-t"
             :style="{
      width:cirSide,
      height:cirSide,
      lineHeight:cirSide,
         }"
        >
        </div>
      </div>
      <div class="auto-mini-menu-name" >
        {{ item.label }}
      </div>
    </div>

  </div>
</template>
<script>
import {onBeforeUnmount, ref, watch} from "vue";
export default {
  name: "autoMiniMenu",
  props: {
    title:{default: "我的应用"},
    /*这里的自定义菜单其实是根据功能跳转到自定义活页面，但是我暂时没有写，一般只有8个左右。*/
    /*定义功能：
    * 1跳转到指定外链
    * 2跳转到内部广告功能（一些自由页面）
    * 3跳转到一些奇怪的表单操作
    * */
    list: {
      default: [
        {
          label: "item"
        },
        {
          label: "item"
        },
        {
          label: "item"
        },
      ]
    }
  },
  setup() {
    const smartWidth = ref(0);
    const cubeSide = ref('0');
    const cirSide = ref('0');
    const nSide = ref('0');
    const resize = () => {
      let c = 0;
      if (window.innerWidth > 502) {
        c = 500;
      } else {
        c = window.innerWidth
      }
      if (c !== smartWidth.value) {
        smartWidth.value = c;
      }
    }
    // eslint-disable-next-line no-unused-vars
    watch(smartWidth, (n, o) => {

      autoSizeData();
    })
    resize();
    window.addEventListener('resize', resize);
    onBeforeUnmount(() => {
      window.removeEventListener('resize', resize);
    })
    const autoSizeData = () => {
      let a = smartWidth.value;
      let b = ((a - 5 * 10) / 4);
      cubeSide.value = b + 'px';
      nSide.value = (b+10) + 'px';
      cirSide.value = (b - 20) + 'px';
      /*4分，然后正方形，每个间隔10，5个10，此控件100%窗口不嵌套正确显示。*/
    }
    return {
      cubeSide,
      nSide,
      cirSide
    }
  },
  mounted() {
  },
}
</script>
